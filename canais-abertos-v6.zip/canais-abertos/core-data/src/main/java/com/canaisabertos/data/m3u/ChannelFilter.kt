package com.canaisabertos.data.m3u

import com.canaisabertos.data.model.Channel

object ChannelFilter {
    private val IGNORED_GROUPS = setOf("undefined", "undefinied")

    /** "News;Sports" -> ["News", "Sports"]. */
    fun groupsOf(channel: Channel): List<String> =
        channel.groupTitle.orEmpty().split(';').map { it.trim() }.filter { it.isNotEmpty() }

    /** Categorias para os chips: mais canais primeiro, no máximo [limit]; "Undefined" fica só em TODOS. */
    fun availableGroups(channels: List<Channel>, limit: Int = 40): List<String> =
        channels.flatMap { groupsOf(it) }
            .filter { it.lowercase() !in IGNORED_GROUPS }
            .groupingBy { it }.eachCount()
            .entries.sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key })
            .take(limit).map { it.key }

    /**
     * Busca por nome (sem acento, sem caixa, ignorando "HD" etc.), filtro opcional só de favoritos
     * e, na lista completa, favoritos fixados no topo (ordem original preservada dentro de cada grupo).
     */
    fun apply(
        channels: List<Channel>,
        query: String,
        favorites: Set<String>,
        onlyFavorites: Boolean,
        group: String? = null,
    ): List<Channel> {
        val q = query.trim().takeIf { it.isNotEmpty() }?.let { ChannelKeys.normalize(it) }
        var out = channels
        if (onlyFavorites) out = out.filter { it.dedupeKey in favorites }
        if (group != null) out = out.filter { group in groupsOf(it) }
        if (q != null) out = out.filter { it.normalizedName.contains(q) }
        if (!onlyFavorites && favorites.isNotEmpty()) out = out.sortedByDescending { it.dedupeKey in favorites }
        return out
    }
}
