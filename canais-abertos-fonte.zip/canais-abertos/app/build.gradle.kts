name: Android Build - Canais Abertos

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    timeout-minutes: 30

    steps:
      - name: Checkout código
        uses: actions/checkout@v4

      - name: Configurar JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: 'zulu'
          java-version: '17'

      - name: Configurar Android SDK
        uses: android-actions/setup-android@v4
        with:
          packages: 'platform-tools'

      - name: Configurar Gradle
        uses: gradle/actions/setup-gradle@v4

      - name: Localizar e extrair zip do projeto
        id: extract
        run: |
          set -e
          ZIP=$(find . -maxdepth 2 -name "*.zip" -not -path "./.git/*" | head -n1)
          if [ -z "$ZIP" ]; then
            echo "::error::Nenhum .zip encontrado na raiz do repositório"
            exit 1
          fi
          echo "Zip encontrado: $ZIP"
          mkdir -p _work
          unzip -q "$ZIP" -d _work

          # Se houver uma única pasta dentro de _work e ela tiver o settings.gradle, entra nela
          cd _work
          COUNT=$(ls -1 | wc -l)
          if [ "$COUNT" -eq 1 ] && [ -d "$(ls -1)" ]; then
            cd "$(ls -1)"
          fi
          
          if [ -f "settings.gradle.kts" ] || [ -f "settings.gradle" ]; then
            ROOT=$(pwd)
          else
            echo "::error::settings.gradle(.kts) não encontrado"
            find . -maxdepth 3 -type d
            exit 1
          fi
          
          cd "$GITHUB_WORKSPACE"
          ROOT_REL=$(echo "$ROOT" | sed "s|$GITHUB_WORKSPACE/||")
          echo "Raiz do projeto: $ROOT_REL"
          echo "root=$ROOT_REL" >> $GITHUB_OUTPUT

      - name: Dar permissão ao gradlew
        run: |
          cd "${{ steps.extract.outputs.root }}"
          chmod +x gradlew

      - name: Rodar testes unitários do core-data
        id: tests
        continue-on-error: true
        run: |
          cd "${{ steps.extract.outputs.root }}"
          set +e
          ./gradlew :core-data:testDebugUnitTest --stacktrace --no-daemon 2>&1 | tee build-tests.log
          echo "exit_code=${PIPESTATUS[0]}" >> $GITHUB_OUTPUT

      - name: Gerar APK de debug
        id: build
        continue-on-error: true
        run: |
          cd "${{ steps.extract.outputs.root }}"
          set +e
          ./gradlew assembleDebug --stacktrace --no-daemon 2>&1 | tee build-apk.log
          echo "exit_code=${PIPESTATUS[0]}" >> $GITHUB_OUTPUT

      - name: Upload do log de build (sempre, mesmo falhando)
        if: always()
        uses: actions/upload-artifact@v4
        with:
          name: build-logs
          path: |
            ${{ steps.extract.outputs.root }}/build-tests.log
            ${{ steps.extract.outputs.root }}/build-apk.log
          if-no-files-found: warn
          retention-days: 14

      - name: Localizar e enviar APK de debug
        if: steps.build.outcome == 'success'
        run: |
          cd "${{ steps.extract.outputs.root }}"
          echo "Procurando arquivos .apk no projeto..."
          find . -name "*.apk" -type f
          
          # Copia qualquer APK encontrado para a raiz do _work para facilitar o upload
          find . -name "*.apk" -type f -exec cp {} /tmp/ \;

      - name: Upload do APK de debug
        if: steps.build.outcome == 'success'
        uses: actions/upload-artifact@v4
        with:
          name: canais-abertos-debug
          path: /tmp/*.apk
          if-no-files-found: error
          retention-days: 14

      - name: Falhar explicitamente se o build falhou
        if: steps.build.outcome != 'success'
        run: |
          echo "::error::O build falhou. Baixe o artifact 'build-logs' e verifique build-apk.log"
          exit 1