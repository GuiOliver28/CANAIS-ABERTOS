plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.canaisabertos"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.canaisabertos"
        minSdk = 22
        targetSdk = 35
        versionCode = 1
        versionName = "0.2.0"
    }

    // ABIs: arm64-v8a, armeabi-v7a, x86_64. Não usar ndk.abiFilters junto com splits.abi (o AGP recusa).
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a", "x86_64")
            isUniversalApk = true   // APK universal + um por ABI
        }
    }

    // Assinatura: lê keystore.properties (não versionado). Sem ele, o release sai assinado com a chave debug.
    val keystoreProps = java.util.Properties().apply {
        val f = rootProject.file("keystore.properties")
        if (f.exists()) f.inputStream().use { load(it) }
    }
    signingConfigs {
        if (keystoreProps.containsKey("storeFile")) {
            create("release") {
                storeFile = rootProject.file(keystoreProps.getProperty("storeFile"))
                storePassword = keystoreProps.getProperty("storePassword")
                keyAlias = keystoreProps.getProperty("keyAlias")
                keyPassword = keystoreProps.getProperty("keyPassword")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.findByName("release") ?: signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.11.00"))
    implementation(project(":ui-common"))
    implementation(project(":ui-tv"))
    implementation(project(":ui-mobile"))
    implementation(project(":core-data"))
    implementation("androidx.activity:activity-compose:1.9.3")
}
