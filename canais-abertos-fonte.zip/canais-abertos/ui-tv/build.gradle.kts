plugins {
    id("com.android.library")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.canaisabertos.ui.tv"
    compileSdk = 35

    defaultConfig {
        minSdk = 22
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(project(":ui-common"))
    implementation(project(":core-player"))
    implementation(platform("androidx.compose:compose-bom:2024.11.00"))
    implementation("androidx.tv:tv-material:1.0.0") // ou 1.1.0
    implementation("androidx.compose.ui:ui")
    // ... outras dependências do Compose
}