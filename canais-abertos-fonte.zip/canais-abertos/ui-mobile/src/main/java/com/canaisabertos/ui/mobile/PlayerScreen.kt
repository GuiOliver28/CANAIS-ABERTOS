package com.canaisabertos.ui.mobile

import android.content.pm.ActivityInfo
import android.view.LayoutInflater
import android.view.View
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.ui.PlayerView
import com.canaisabertos.player.PlaybackStatus
import com.canaisabertos.player.PlayerViewModel
import com.canaisabertos.ui.common.ErrorMark
import com.canaisabertos.ui.common.LiveBadge
import com.canaisabertos.ui.common.Mono

@Composable
fun MobilePlayerScreen(vm: PlayerViewModel) {
    val state by vm.state.collectAsState()
    val activity = LocalContext.current.findActivity()

    BackHandler { vm.stop() }

    // No player: landscape automático + tela cheia; ao sair, volta ao normal.
    DisposableEffect(activity) {
        val window = activity.window
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
        onDispose {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            controller.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    Box(Modifier.fillMaxSize().background(Mono.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val view = LayoutInflater.from(ctx).inflate(R.layout.mono_player_view, null) as PlayerView
                view.player = vm.player
                view.keepScreenOn = true
                view.findViewById<View>(R.id.mono_prev).setOnClickListener { vm.previous() }
                view.findViewById<View>(R.id.mono_next).setOnClickListener { vm.next() }
                view
            },
            onRelease = { it.player = null },
        )

        // Cabeçalho: voltar + nome do canal.
        Row(
            Modifier.fillMaxWidth().background(Color(0xB3000000)).padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            SecondaryButton("VOLTAR", onClick = vm::stop)
            Column(Modifier.weight(1f)) {
                Text(
                    state.channel?.name.orEmpty(),
                    style = MaterialTheme.typography.titleLarge,
                    color = Mono.White,
                    maxLines = 1,
                )
                LiveBadge()
            }
        }

        when (state.status) {
            PlaybackStatus.PLAYING -> Unit
            PlaybackStatus.LOADING -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("CARREGANDO…", style = MaterialTheme.typography.headlineMedium, color = Mono.White)
            }
            PlaybackStatus.UNAVAILABLE -> Box(
                Modifier.fillMaxSize().background(Color(0xB3000000)),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    ErrorMark()
                    Text(
                        "CANAL INDISPONÍVEL",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Mono.White,
                        textAlign = TextAlign.Center,
                    )
                    state.suggestedNext?.let {
                        PrimaryButton("PRÓXIMO: ${it.name.uppercase()}", onClick = vm::next)
                    }
                    SecondaryButton("VOLTAR À LISTA", onClick = vm::stop)
                }
            }
        }
    }
}
