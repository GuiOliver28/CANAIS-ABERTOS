// Port fiel de M3uParser.kt / ChannelKeys.kt / ChannelFilter.kt. Sem dependências; roda no browser e no Node.
const ATTR = /([A-Za-z0-9_\-]+)=(?:"([^"]*)"|([^\s",]+))/g;

const blank = (v) => { const t = (v ?? '').trim(); return t ? t : null; };
const isHttp = (u) => /^https?:\/\//i.test(u);

function parseExtInf(line) {
  const body = line.includes(':') ? line.slice(line.indexOf(':') + 1) : '';
  let inQuote = false, comma = -1;
  for (let i = 0; i < body.length; i++) {
    const c = body[i];
    if (c === '"') inQuote = !inQuote;
    else if (c === ',' && !inQuote) { comma = i; break; }
  }
  const header = comma >= 0 ? body.slice(0, comma) : body;
  const name = comma >= 0 ? body.slice(comma + 1).trim() : '';
  const attrs = {};
  for (const m of header.matchAll(ATTR)) attrs[m[1].toLowerCase()] = m[2] ?? m[3] ?? '';
  return { name, attrs, userAgent: null, referrer: null, extGrp: null };
}

export function parseM3u(text) {
  const out = [];
  let pending = null;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.replace(/^﻿/, '').trim();
    if (!line) continue;
    const up = line.toUpperCase();
    if (up.startsWith('#EXTINF')) {
      pending = parseExtInf(line);
    } else if (up.startsWith('#EXTVLCOPT:')) {
      pending ??= { name: null, attrs: {}, userAgent: null, referrer: null, extGrp: null };
      const opt = line.slice('#EXTVLCOPT:'.length);
      const key = opt.split('=')[0].trim().toLowerCase();
      const value = blank(opt.includes('=') ? opt.slice(opt.indexOf('=') + 1) : '');
      if (key === 'http-user-agent') pending.userAgent = value;
      else if (key === 'http-referrer' || key === 'http-referer') pending.referrer = value;
    } else if (up.startsWith('#EXTGRP:')) {
      pending ??= { name: null, attrs: {}, userAgent: null, referrer: null, extGrp: null };
      pending.extGrp = line.slice('#EXTGRP:'.length).trim();
    } else if (line.startsWith('#')) {
      // #EXTM3U, #KODIPROP, comentários
    } else {
      const p = pending;
      pending = null;
      if (p && isHttp(line)) {
        const name = blank(p.name) ?? blank(p.attrs['tvg-name']);
        if (name) {
          out.push({
            tvgId: blank(p.attrs['tvg-id']),
            name,
            logoUrl: blank(p.attrs['tvg-logo']),
            groupTitle: blank(p.attrs['group-title']) ?? blank(p.extGrp),
            streamUrl: line,
            userAgent: p.userAgent,
            referrer: p.referrer,
          });
        }
      }
    }
  }
  return out;
}

/** "TV Brasil HD (720p) [Geo-blocked]" -> "tv brasil". */
export function normalize(name) {
  let s = name.normalize('NFD').replace(/\p{M}+/gu, '').toLowerCase();
  s = s.replace(/\(.*?\)|\[.*?\]/g, ' ');
  s = s.replace(/[^a-z0-9]+/g, ' ').trim();
  s = s.replace(/\s(hd|fhd|sd|uhd|4k)$/, '');
  return s || name.trim().toLowerCase();
}

export function dedupeKey(tvgId, normalizedName) {
  const id = (tvgId ?? '').trim().toLowerCase();
  return id ? `id:${id}` : `name:${normalizedName}`;
}

export function toChannel(parsed, sourceId) {
  const normalizedName = normalize(parsed.name);
  return { ...parsed, sourceId, normalizedName, dedupeKey: dedupeKey(parsed.tvgId, normalizedName) };
}

/** Funde as fontes na ordem recebida; o primeiro canal de cada dedupeKey vence. */
export function mergeChannels(lists) {
  const seen = new Set();
  const out = [];
  for (const list of lists) {
    for (const c of list) {
      if (seen.has(c.dedupeKey)) continue;
      seen.add(c.dedupeKey);
      out.push(c);
    }
  }
  return out;
}

export function filterChannels(channels, query, favorites, onlyFavorites) {
  const q = query.trim() ? normalize(query) : null;
  let out = channels;
  if (onlyFavorites) out = out.filter((c) => favorites.has(c.dedupeKey));
  if (q) out = out.filter((c) => c.normalizedName.includes(q));
  if (!onlyFavorites && favorites.size) {
    // sort estável: favoritos primeiro, ordem original dentro de cada grupo
    out = out.map((c, i) => [c, i]).sort((a, b) =>
      (favorites.has(b[0].dedupeKey) - favorites.has(a[0].dedupeKey)) || a[1] - b[1]).map((x) => x[0]);
  }
  return out;
}
