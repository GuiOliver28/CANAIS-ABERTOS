import { filterChannels, normalize } from './m3u.js';
import { SourceManager } from './sources.js';
import { store } from './store.js';
import { Player } from './player.js';
import { dirOf, isBack, move } from './nav.js';

const PAGE = 120; // limita o DOM em TVs de pouca memória; "MOSTRAR MAIS" amplia

const $ = (sel) => document.querySelector(sel);
function el(tag, props = {}, ...children) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') n.className = v;
    else if (k === 'text') n.textContent = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2), v);
    else if (k === 'focus') n.dataset.focus = '';
    else n.setAttribute(k, v);
  }
  n.append(...children);
  return n;
}

const state = { all: [], errors: {}, loading: true, query: '', onlyFav: false, limit: PAGE, view: 'list' };
let sources, favorites, player;

async function boot() {
  const defaults = await (await fetch('sources.json')).json();
  sources = new SourceManager(defaults);
  favorites = store.getFavorites();
  player = new Player($('#player'), { onClose: () => show('list') });
  document.addEventListener('keydown', onKey);
  render();
  await reload();
}

async function reload(force = false) {
  state.loading = true; render();
  const { channels, errors } = await sources.loadActive({ force });
  state.all = channels; state.errors = errors; state.loading = false;
  render();
}

function visible() { return filterChannels(state.all, state.query, favorites, state.onlyFav); }

function show(view) {
  state.view = view; render();
}

function onKey(e) {
  if (!$('#player').classList.contains('hidden')) return; // o player trata as próprias teclas
  const dir = dirOf(e.keyCode);
  const inField = document.activeElement?.tagName === 'INPUT';
  if (dir && !(inField && (dir === 'left' || dir === 'right'))) { e.preventDefault(); move(dir, $('#app')); }
  else if (isBack(e) && state.view !== 'list') { e.preventDefault(); show('list'); }
}

function logo(ch) {
  const box = el('div', { class: 'logo' });
  const initials = () => {
    box.className = 'logo initials';
    box.replaceChildren(document.createTextNode(ch.name.split(' ').filter(Boolean).slice(0, 2).map((w) => w[0].toUpperCase()).join('')));
  };
  if (!ch.logoUrl) { initials(); return box; }
  const img = el('img', { alt: '', loading: 'lazy', referrerpolicy: 'no-referrer' });
  img.addEventListener('error', initials);
  img.src = ch.logoUrl;
  box.append(img);
  return box;
}

function card(ch, list, index) {
  const fav = favorites.has(ch.dedupeKey);
  return el('div', { class: 'row' },
    el('button', { class: 'card grow', focus: '', onclick: () => player.open(list, index) },
      logo(ch),
      el('div', { class: 'meta' },
        el('div', { class: 'name', text: ch.name }),
        ...(ch.groupTitle ? [el('div', { class: 'group', text: ch.groupTitle })] : []),
        el('div', { class: 'live' }, el('i'), document.createTextNode('AO VIVO')))),
    el('button', { class: 'star' + (fav ? ' on' : ''), focus: '', 'aria-label': 'Favoritar', text: fav ? '★' : '☆',
      onclick: () => { fav ? favorites.delete(ch.dedupeKey) : favorites.add(ch.dedupeKey); store.saveFavorites(favorites); render(); } }));
}

function listView() {
  const vis = visible();
  const total = state.all.length;
  const root = el('div', { class: 'screen' },
    el('div', { class: 'row' },
      el('div', { class: 'grow' }, el('h1', { text: 'CANAIS ABERTOS' }),
        el('div', { class: 'sub', text: vis.length === total ? `${total} canais` : `${vis.length} de ${total} canais` })),
      el('button', { class: 'btn outline', focus: '', text: 'FONTES', onclick: () => show('sources') })));

  if (total) {
    const q = el('input', { class: 'field', focus: '', placeholder: 'Buscar canal', value: state.query, 'aria-label': 'Buscar canal' });
    q.addEventListener('input', () => { state.query = q.value; state.limit = PAGE; renderKeep(q); });
    root.append(el('div', { class: 'row' }, el('div', { class: 'grow' }, q),
      el('button', { class: 'btn ' + (state.onlyFav ? 'primary' : 'outline'), focus: '',
        text: (state.onlyFav ? '★' : '☆') + ' FAVORITOS', onclick: () => { state.onlyFav = !state.onlyFav; state.limit = PAGE; render(); } })));
  }

  if (!total && state.loading) root.append(center('CARREGANDO CANAIS…'));
  else if (!total) root.append(center('NENHUM CANAL', 'Nenhuma fonte ativa carregou. Ative, adicione ou atualize uma fonte.', 'GERENCIAR FONTES', () => show('sources')));
  else if (!vis.length) root.append(center(state.onlyFav && !state.query.trim() ? 'SEM FAVORITOS' : 'NADA ENCONTRADO',
    state.onlyFav && !state.query.trim() ? 'Selecione a estrela de um canal para favoritar.' : 'Nenhum canal combina com a busca.'));
  else {
    const grid = el('div', { class: 'grid' });
    vis.slice(0, state.limit).forEach((ch, i) => grid.append(card(ch, vis, i)));
    if (vis.length > state.limit) grid.append(el('button', { class: 'btn outline', focus: '', text: 'MOSTRAR MAIS', onclick: () => { state.limit += PAGE; render(); } }));
    root.append(grid);
  }
  return root;
}

function center(title, body, cta, onCta) {
  return el('div', { class: 'center' }, el('h1', { text: title }),
    ...(body ? [el('p', { text: body })] : []),
    ...(cta ? [el('button', { class: 'btn primary', focus: '', text: cta, onclick: onCta })] : []));
}

function sourcesView() {
  const name = el('input', { class: 'field', focus: '', placeholder: 'Nome', 'aria-label': 'Nome da fonte' });
  const url = el('input', { class: 'field', focus: '', placeholder: 'URL da lista M3U (https://…)', 'aria-label': 'URL da fonte' });
  const msg = el('div', { class: 'sub' });
  const add = el('button', { class: 'btn primary', focus: '', text: 'ADICIONAR', onclick: async () => {
    msg.textContent = 'Testando a lista…';
    try {
      const n = await sources.add(name.value.trim(), url.value.trim());
      msg.textContent = `Adicionada: ${n} canais.`; await reload(true); show('sources');
    } catch (e) { msg.textContent = 'Falhou: ' + (e.message || e) + ' (a fonte precisa permitir acesso CORS).'; }
  } });
  const items = sources.sources.map((s) => el('div', { class: 'row' },
    el('button', { class: 'src grow', focus: '', onclick: async () => { sources.toggle(s.id); await reload(); show('sources'); } },
      el('div', { class: 'grow', style: 'min-width:0' },
        el('div', { class: 'name', text: s.name }),
        el('div', { class: 'url', text: s.url }),
        ...(state.errors[s.id] ? [el('div', { class: 'err', text: 'Erro: ' + state.errors[s.id] })] : [])),
      el('div', { text: s.enabled ? 'ATIVA' : 'INATIVA' })),
    ...(s.builtin ? [] : [el('button', { class: 'btn outline', focus: '', text: 'REMOVER', onclick: async () => { sources.remove(s.id); await reload(); show('sources'); } })])));
  return el('div', { class: 'screen' },
    el('div', { class: 'row' }, el('h1', { class: 'grow', text: 'FONTES' }),
      el('button', { class: 'btn outline', focus: '', text: 'ATUALIZAR TUDO', onclick: () => { reload(true); show('list'); } }),
      el('button', { class: 'btn outline', focus: '', text: 'VOLTAR', onclick: () => show('list') })),
    el('div', { class: 'list' }, ...items),
    el('div', { class: 'form' }, name, url, add), msg);
}

function render() {
  const app = $('#app');
  app.replaceChildren(state.view === 'sources' ? sourcesView() : listView());
  if (!document.activeElement || document.activeElement === document.body) move('down', app);
}

// Re-render da busca preservando o foco/cursor do campo.
function renderKeep(input) {
  const pos = input.selectionStart;
  render();
  const q = $('#app input.field');
  if (q) { q.focus(); q.setSelectionRange(pos, pos); }
}

boot();
