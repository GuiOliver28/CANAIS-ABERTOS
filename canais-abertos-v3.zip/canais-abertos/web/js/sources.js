import { parseM3u, toChannel, mergeChannels } from './m3u.js';
import { store } from './store.js';

const FRESH_MS = 7 * 24 * 3600 * 1000; // mesmo frescor de 7 dias do app Android

export class SourceManager {
  constructor(defaults) {
    this.defaults = defaults;
    this.sources = store.getSources(defaults);
  }
  save() { store.saveSources(this.sources); }

  async fetchOne(source, { force = false } = {}) {
    const cached = store.getCache(source.id);
    if (!force && cached && Date.now() - cached.at < FRESH_MS) return cached.channels;
    try {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), 20000);
      const res = await fetch(source.url, { signal: ctrl.signal });
      clearTimeout(timer);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const channels = parseM3u(await res.text()).map((p) => toChannel(p, source.id));
      if (!channels.length) throw new Error('lista sem canais');
      store.saveCache(source.id, channels);
      return channels;
    } catch (e) {
      if (cached) return cached.channels; // offline/falha: usa o cache velho
      throw e;
    }
  }

  /** Canais fundidos das fontes ativas; fontes que falham não derrubam as outras. */
  async loadActive({ force = false } = {}) {
    const active = this.sources.filter((s) => s.enabled);
    const results = await Promise.allSettled(active.map((s) => this.fetchOne(s, { force })));
    const errors = {};
    const lists = results.map((r, i) => {
      if (r.status === 'fulfilled') return r.value;
      errors[active[i].id] = String(r.reason?.message ?? r.reason);
      return [];
    });
    return { channels: mergeChannels(lists), errors };
  }

  /** Testa a URL antes de adicionar (como no app). Lança erro se falhar ou vier vazia. */
  async add(name, url) {
    if (!/^https?:\/\//i.test(url)) throw new Error('A URL precisa começar com http:// ou https://');
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const n = parseM3u(await res.text()).length;
    if (!n) throw new Error('A lista não tem canais válidos');
    const id = 'u-' + Date.now().toString(36);
    this.sources.push({ id, name: name || url, url, enabled: true, builtin: false });
    this.save();
    return n;
  }

  toggle(id) {
    const s = this.sources.find((x) => x.id === id);
    if (s) { s.enabled = !s.enabled; this.save(); }
  }
  remove(id) {
    this.sources = this.sources.filter((s) => s.id !== id || s.builtin);
    store.dropCache(id);
    this.save();
  }
}
