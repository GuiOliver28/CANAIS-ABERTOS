import { KEYS, isBack } from './nav.js';

const TIMEOUT_MS = 5000; // mesmo timeout do app Android

/** Player em tela cheia sobre <video>. Samsung/LG tocam HLS nativamente; no desktop, ponha hls.min.js em web/vendor/. */
export class Player {
  constructor(root, { onClose }) {
    this.root = root;
    this.onClose = onClose;
    this.video = root.querySelector('video');
    this.overlay = root.querySelector('#overlay');
    this.status = root.querySelector('#status');
    this.list = []; this.index = 0; this.timer = null; this.overlayTimer = null; this.hls = null;

    this.video.addEventListener('playing', () => { clearTimeout(this.timer); this.setStatus('ok'); });
    this.video.addEventListener('error', () => this.unavailable());
    this.video.addEventListener('stalled', () => {});
    root.addEventListener('keydown', (e) => this.onKey(e));
    root.querySelector('#p-back').addEventListener('click', () => this.close());
    root.addEventListener('click', () => this.showOverlay());
  }

  open(list, index) {
    this.list = list; this.index = index;
    this.root.classList.remove('hidden');
    this.root.querySelector('#p-back').focus();
    this.play();
  }

  close() {
    clearTimeout(this.timer);
    this.teardown();
    this.root.classList.add('hidden');
    this.onClose();
  }

  teardown() {
    if (this.hls) { this.hls.destroy(); this.hls = null; }
    this.video.removeAttribute('src');
    this.video.load();
  }

  get current() { return this.list[this.index]; }

  play() {
    const ch = this.current;
    if (!ch) return this.close();
    this.root.querySelector('#p-name').textContent = ch.name;
    this.setStatus('loading');
    this.showOverlay();
    this.teardown();
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.unavailable(), TIMEOUT_MS);
    const native = this.video.canPlayType('application/vnd.apple.mpegurl');
    if (!native && window.Hls && window.Hls.isSupported()) {
      this.hls = new window.Hls();
      this.hls.on(window.Hls.Events.ERROR, (_e, data) => { if (data.fatal) this.unavailable(); });
      this.hls.loadSource(ch.streamUrl);
      this.hls.attachMedia(this.video);
    } else {
      this.video.src = ch.streamUrl;
    }
    this.video.play?.().catch(() => {});
  }

  step(delta) {
    if (!this.list.length) return;
    this.index = (this.index + delta + this.list.length) % this.list.length;
    this.play();
  }

  unavailable() {
    clearTimeout(this.timer);
    const next = this.list[(this.index + 1) % this.list.length];
    this.setStatus('bad', next && next !== this.current ? next.name : null);
  }

  setStatus(kind, nextName) {
    const el = this.status;
    el.className = kind === 'bad' ? 'bad' : '';
    el.replaceChildren();
    if (kind === 'ok') return;
    if (kind === 'loading') { el.textContent = 'CARREGANDO…'; return; }
    const mark = document.createElement('div'); mark.className = 'mark'; mark.textContent = '!';
    const t = document.createElement('div'); t.textContent = 'CANAL INDISPONÍVEL';
    el.append(mark, t);
    if (nextName) {
      const b = document.createElement('button');
      b.className = 'btn primary'; b.dataset.focus = ''; b.textContent = 'PRÓXIMO: ' + nextName.toUpperCase();
      b.addEventListener('click', (e) => { e.stopPropagation(); this.step(1); });
      el.append(b); b.focus();
    }
  }

  showOverlay() {
    this.overlay.classList.remove('off');
    clearTimeout(this.overlayTimer);
    this.overlayTimer = setTimeout(() => this.overlay.classList.add('off'), 3000);
  }

  onKey(e) {
    if (isBack(e)) { e.preventDefault(); return this.close(); }
    const code = e.keyCode;
    if (KEYS.CH_UP.includes(code) || code === KEYS.UP) { e.preventDefault(); this.step(-1); }
    else if (KEYS.CH_DOWN.includes(code) || code === KEYS.DOWN) { e.preventDefault(); this.step(1); }
    else this.showOverlay();
  }
}
