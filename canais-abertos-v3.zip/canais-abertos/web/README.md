# Canais Abertos Web (base para LG webOS e Samsung Tizen)

HTML + CSS + JS puro (módulos ES), sem build e sem dependências. Mesmo design do app Android
(preto/branco/cinzas, Inter bold, foco com borda branca de 3 px e escala 1,05).

Reaproveita do app: parser M3U (`js/m3u.js`, port de `M3uParser.kt`/`ChannelKeys.kt`/`ChannelFilter.kt`),
fontes padrão (`sources.json`), gerenciador de fontes com cache de 7 dias (`js/sources.js`, localStorage no lugar do Room),
favoritos, busca sem acento, player com timeout de 5 s e sugestão do próximo canal.

## Rodar no navegador
    cd web && python3 -m http.server 8080      # abra http://localhost:8080
    node test/m3u.test.mjs                      # testes do parser
Setas = D-pad, Enter = selecionar, Esc/Backspace = voltar. No player: setas cima/baixo ou CH+/CH- trocam de canal.
Chrome não toca HLS nativamente: coloque `hls.min.js` em `web/vendor/` e descomente a linha no `index.html`.

## TVs
- **webOS**: `platform/webos/appinfo.json` (+ `icon.png` 80x80). `ares-package web/` e `ares-install` (webOS TV CLI).
- **Tizen**: `platform/tizen/config.xml` (copie para a raiz do projeto Tizen Studio, + `icon.png`).
  Em ambos, `video.src` com HLS funciona nativamente; AVPlay (nativo) é um refinamento futuro.

## Limitações conhecidas (não testado em TV real)
- Fontes precisam enviar CORS (`iptv-org` e `raw.githubusercontent.com` enviam). Listas de terceiros sem CORS falham ao adicionar.
- Streams `http://` dentro de app `https://` sofrem bloqueio de conteúdo misto no navegador; em apps empacotados de TV isso não se aplica.
- `user-agent`/`referrer` por canal do M3U não podem ser definidos pelo `<video>`; esses canais podem falhar.
- Navegação espacial simples (`js/nav.js`); a ordem de foco em telas muito diferentes pode precisar de ajustes na TV real.
