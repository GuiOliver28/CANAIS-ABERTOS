package com.canaisabertos.cast

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/**
 * Lado da TV. Enquanto estiver iniciado, aceita `POST /play` na rede local e chama [onPlay]
 * na main thread. Ligue em ON_START e desligue em ON_STOP (a TV só recebe com o app aberto).
 * Só aceita URLs http/https; qualquer aparelho da mesma rede pode enviar (ver README).
 */
class CastReceiver(
    context: Context,
    private val onPlay: (CastRequest) -> Unit,
) {
    private val nsd = context.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val main = Handler(Looper.getMainLooper())
    private var server: ServerSocket? = null
    private var registration: NsdManager.RegistrationListener? = null

    @Synchronized
    fun start() {
        if (server != null) return
        val ss = try { ServerSocket(0) } catch (_: Exception) { return }
        server = ss
        thread(name = "cast-accept", isDaemon = true) {
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (_: Exception) { break }
                thread(name = "cast-client", isDaemon = true) { handle(s) }
            }
        }
        val info = NsdServiceInfo().apply {
            serviceName = "Canais Abertos (${Build.MODEL})"
            serviceType = CastProtocol.SERVICE_TYPE
            port = ss.localPort
        }
        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) {}
            override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
            override fun onServiceUnregistered(info: NsdServiceInfo) {}
            override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
        }
        registration = listener
        try { nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener) } catch (_: Exception) {}
    }

    @Synchronized
    fun stop() {
        registration?.let { try { nsd.unregisterService(it) } catch (_: Exception) {} }
        registration = null
        try { server?.close() } catch (_: Exception) {}
        server = null
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            s.soTimeout = 5_000
            val request = try { CastHttp.parsePlay(s.getInputStream()) } catch (_: Exception) { null }
            val status = if (request != null) "200 OK" else "400 Bad Request"
            try {
                s.getOutputStream().apply {
                    write("HTTP/1.1 $status\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
                    flush()
                }
            } catch (_: Exception) {}
            if (request != null) main.post { onPlay(request) }
        }
    }
}
