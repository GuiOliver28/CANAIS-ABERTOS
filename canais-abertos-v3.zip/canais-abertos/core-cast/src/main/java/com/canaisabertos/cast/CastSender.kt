package com.canaisabertos.cast

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import com.canaisabertos.data.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

data class CastTarget(val name: String, val host: String, val port: Int)

/** Lado do celular: descobre TVs por NSD e envia o canal. Use start/stopDiscovery com o ciclo da tela. */
class CastSender(context: Context) {
    private val nsd = context.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val _targets = MutableStateFlow<List<CastTarget>>(emptyList())
    val targets: StateFlow<List<CastTarget>> = _targets.asStateFlow()

    private var discovery: NsdManager.DiscoveryListener? = null
    private val pending = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    @Synchronized
    fun startDiscovery() {
        if (discovery != null) return
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onServiceFound(info: NsdServiceInfo) = enqueue(info)
            override fun onServiceLost(info: NsdServiceInfo) {
                _targets.update { list -> list.filterNot { it.name == info.serviceName } }
            }
        }
        discovery = listener
        try { nsd.discoverServices(CastProtocol.SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener) } catch (_: Exception) { discovery = null }
    }

    @Synchronized
    fun stopDiscovery() {
        discovery?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        discovery = null
        pending.clear()
        resolving = false
    }

    // NsdManager só resolve um serviço por vez; serializa.
    @Synchronized
    private fun enqueue(info: NsdServiceInfo) {
        pending.addLast(info)
        resolveNext()
    }

    @Synchronized
    private fun resolveNext() {
        if (resolving) return
        val next = pending.removeFirstOrNull() ?: return
        resolving = true
        val done = {
            synchronized(this) { resolving = false; resolveNext() }
        }
        try {
            @Suppress("DEPRECATION")
            nsd.resolveService(next, object : NsdManager.ResolveListener {
                override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) = done()
                override fun onServiceResolved(info: NsdServiceInfo) {
                    @Suppress("DEPRECATION")
                    val host = info.host?.hostAddress
                    if (host != null) {
                        val target = CastTarget(info.serviceName, host, info.port)
                        _targets.update { list -> list.filterNot { it.name == target.name } + target }
                    }
                    done()
                }
            })
        } catch (_: Exception) {
            resolving = false
        }
    }

    /** Envia o canal para a TV. Retorna true se a TV confirmou (HTTP 200). */
    suspend fun send(target: CastTarget, channel: Channel): Boolean = withContext(Dispatchers.IO) {
        val body = CastHttp.encode(
            CastRequest(channel.name, channel.streamUrl, channel.userAgent, channel.referrer),
        ).toByteArray()
        val host = if (target.host.contains(':')) "[${target.host}]" else target.host
        var conn: HttpURLConnection? = null
        try {
            conn = (URL("http://$host:${target.port}${CastProtocol.PATH_PLAY}").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 4_000
                readTimeout = 4_000
                doOutput = true
                setFixedLengthStreamingMode(body.size)
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            }
            conn.outputStream.use { it.write(body) }
            conn.responseCode == 200
        } catch (_: Exception) {
            false
        } finally {
            conn?.disconnect()
        }
    }
}
