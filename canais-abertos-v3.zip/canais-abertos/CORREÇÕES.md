# CORREÇÕES — rodada de 12/11/2026

Baseline: o build verde do GitHub Actions (run #21): `app/build.gradle.kts`, `ui-tv/build.gradle.kts` e
`ui-mobile/.../PlayerScreen.kt` do seu v2 foram incorporados. Estado: **nada abaixo foi compilado por mim**
(sem SDK na sessão); valide no Actions.

## 1. Bug da lista no mobile (nomes somem depois do player)
Não consegui reproduzir sem aparelho, então não afirmo a causa exata. Mudanças que removem as causas prováveis:
- `ChannelListViewModel`: `channels`, `favoriteKeys` e `visible` agora usam `SharingStarted.Eagerly`
  (cache vivo enquanto o ViewModel viver, nunca reinicia ao voltar do player). `isRefreshing` continua `WhileSubscribed`.
- `MobileRoot` guarda o `LazyGridState` e o repassa à lista: a posição de rolagem sobrevive ao player.
- Grade `GridCells.Adaptive(340.dp)` no lugar de `calculateWindowSizeClass(...)` + colunas fixas
  (o cálculo dependia da Activity e do tamanho da janela logo após sair do player em paisagem).
- Card: coluna e texto do nome com `fillMaxWidth()` explícito.
Se o bug persistir, mande um print e a versão do Android; o próximo suspeito é o `SubcomposeAsyncImage` do logo.

## 2. Cast (celular → Fire TV), **sem Google Cast**
O Media3 Cast exige Google Play Services e a Fire TV **não é um receptor Google Cast**; então não é possível
transmitir para ela com esse caminho, e usá-lo quebraria a regra "sem GMS". Alternativa implementada (módulo `core-cast`):
- A TV (`TvRoot`) abre um servidor HTTP mínimo na rede local e se anuncia por NSD/mDNS (`_canaisabertos._tcp`) enquanto o app está visível.
- No player do celular, o botão **TV** lista as TVs achadas e envia o canal (`POST /play`); a TV toca e o celular volta à lista.
- Permissões novas: `ACCESS_WIFI_STATE`, `CHANGE_WIFI_MULTICAST_STATE`.
- Limites: celular e TV na mesma rede (Wi-Fi com "isolamento de clientes" bloqueia); só envia a URL, a TV baixa o stream por conta própria;
  **qualquer aparelho da rede pode mandar um stream http/https para a TV aberta** (sem pareamento/PIN ainda).
- Testes JVM do protocolo: `core-cast/src/test`.

## 3. Versão Web (`web/`)
Base para webOS/Tizen em JS puro, mesmo design, mesmo parser (testado em Node), fontes com localStorage, D-pad, player.
Conferido no Chromium com lista simulada (12 canais, foco, sem erros de JS). Ver `web/README.md`.

## Arquivos
Novos: `core-cast/`, `web/`, `ui-mobile/.../CastDialog.kt`. Alterados: `ChannelListViewModel.kt`, `ListScreen.kt`, `MobileRoot.kt`,
`PlayerScreen.kt` (botão TV), `TvRoot.kt`, `AndroidManifest.xml`, `settings.gradle.kts`, `ui-tv`/`ui-mobile` `build.gradle.kts`.
