package com.canaisabertos.ui.mobile

import android.content.pm.ActivityInfo
import android.view.LayoutInflater
import android.view.View
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.ui.PlayerView
import com.canaisabertos.player.PlaybackStatus
import com.canaisabertos.player.PlayerViewModel
import com.canaisabertos.ui.common.ErrorMark
import com.canaisabertos.ui.common.LiveBadge
import com.canaisabertos.ui.common.Mono
import kotlinx.coroutines.delay

@Composable
fun MobilePlayerScreen(vm: PlayerViewModel) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val activity = context.findActivity()

    BackHandler { vm.stop() }

    // Controle de visibilidade do overlay (cabeçalho)
    var overlayVisivel by remember { mutableStateOf(true) }
    var mostrarCast by remember { mutableStateOf(false) }

    // Esconde o overlay automaticamente após 4 segundos
    LaunchedEffect(overlayVisivel, mostrarCast) {
        if (overlayVisivel && !mostrarCast) {
            delay(4000)
            overlayVisivel = false
        }
    }

    // No player: landscape automático + tela cheia; ao sair, volta ao normal.
    DisposableEffect(activity) {
        if (activity != null) {
            val window = activity.window
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
        onDispose {
            if (activity != null) {
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                val window = activity.window
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Mono.Black)
            .pointerInput(Unit) {
                detectTapGestures(onTap = { overlayVisivel = !overlayVisivel })
            }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val view = LayoutInflater.from(ctx).inflate(R.layout.mono_player_view, null) as PlayerView
                view.player = vm.player
                view.keepScreenOn = true
                view.findViewById<View>(R.id.mono_prev)?.setOnClickListener { vm.previous() }
                view.findViewById<View>(R.id.mono_next)?.setOnClickListener { vm.next() }
                view
            },
            onRelease = { it.player = null },
        )

        // Cabeçalho só aparece se overlayVisivel for true
        if (overlayVisivel) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0xB3000000))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                TextButton(onClick = { vm.stop() }) {
                    Text("VOLTAR", color = Mono.White, style = MaterialTheme.typography.titleMedium)
                }
                
                Column(Modifier.weight(1f)) {
                    Text(
                        state.channel?.name.orEmpty(),
                        style = MaterialTheme.typography.titleLarge,
                        color = Mono.White,
                        maxLines = 1,
                    )
                    LiveBadge()
                }
                TextButton(onClick = { mostrarCast = true }) {
                    Text("TV", color = Mono.White, style = MaterialTheme.typography.titleMedium)
                }
            }
        }

        val atual = state.channel
        if (mostrarCast && atual != null) {
            CastDialog(
                channel = atual,
                onDismiss = { mostrarCast = false },
                onSent = {
                    mostrarCast = false
                    vm.stop() // a TV assume; o celular volta para a lista
                },
            )
        }

        when (state.status) {
            PlaybackStatus.PLAYING -> Unit
            PlaybackStatus.LOADING -> Box(
                Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "CARREGANDO...",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Mono.White
                )
            }
            PlaybackStatus.UNAVAILABLE -> Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xB3000000)),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    ErrorMark()
                    Text(
                        "CANAL INDISPONÍVEL",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Mono.White,
                        textAlign = TextAlign.Center,
                    )
                    state.suggestedNext?.let {
                        Button(onClick = { vm.next() }) {
                            Text("PRÓXIMO: ${it.name.uppercase()}")
                        }
                    }
                    OutlinedButton(onClick = { vm.stop() }) {
                        Text("VOLTAR À LISTA", color = Mono.White)
                    }
                }
            }
        }
    }
}