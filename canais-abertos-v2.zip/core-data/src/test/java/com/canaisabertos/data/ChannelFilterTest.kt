package com.canaisabertos.data

import com.canaisabertos.data.db.FavoriteDao
import com.canaisabertos.data.m3u.ChannelFilter
import com.canaisabertos.data.m3u.ParsedChannel
import com.canaisabertos.data.m3u.toChannel
import com.canaisabertos.data.model.Favorite
import com.canaisabertos.data.repo.FavoriteRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChannelFilterTest {
    private fun ch(name: String) = ParsedChannel(null, name, null, null, "https://x.test/$name", null, null).toChannel("s")

    private val all = listOf(ch("TV Brasil"), ch("TV Câmara"), ch("Band HD"), ch("SBT"), ch("Record"))
    private fun key(name: String) = all.first { it.name == name }.dedupeKey

    @Test fun blankQueryReturnsEverythingInOrder() {
        assertEquals(all.map { it.name }, ChannelFilter.apply(all, "   ", emptySet(), false).map { it.name })
    }

    @Test fun searchIgnoresAccentsCaseAndQualityTag() {
        assertEquals(listOf("TV Câmara"), ChannelFilter.apply(all, "CAMARA", emptySet(), false).map { it.name })
        assertEquals(listOf("TV Câmara"), ChannelFilter.apply(all, "tv câm", emptySet(), false).map { it.name })
        assertEquals(listOf("Band HD"), ChannelFilter.apply(all, "band hd", emptySet(), false).map { it.name })
    }

    @Test fun searchWithNoMatchIsEmpty() {
        assertTrue(ChannelFilter.apply(all, "xyz", emptySet(), false).isEmpty())
    }

    @Test fun favoritesArePinnedFirstKeepingRelativeOrder() {
        val favs = setOf(key("SBT"), key("TV Câmara"))
        val out = ChannelFilter.apply(all, "", favs, onlyFavorites = false).map { it.name }
        assertEquals(listOf("TV Câmara", "SBT", "TV Brasil", "Band HD", "Record"), out)
    }

    @Test fun onlyFavoritesFiltersAndCombinesWithSearch() {
        val favs = setOf(key("SBT"), key("TV Brasil"))
        assertEquals(listOf("TV Brasil", "SBT"), ChannelFilter.apply(all, "", favs, true).map { it.name })
        assertEquals(listOf("TV Brasil"), ChannelFilter.apply(all, "brasil", favs, true).map { it.name })
        assertTrue(ChannelFilter.apply(all, "record", favs, true).isEmpty())
    }

    // ---- FavoriteRepository ----

    private class FakeFavoriteDao : FavoriteDao {
        val rows = MutableStateFlow<List<Favorite>>(emptyList())
        override fun observeKeys(): Flow<List<String>> = rows.map { l -> l.map { it.dedupeKey } }
        override suspend fun insert(favorite: Favorite): Long {
            if (rows.value.any { it.dedupeKey == favorite.dedupeKey }) return -1
            rows.value = rows.value + favorite
            return 1
        }
        override suspend fun delete(key: String): Int {
            val before = rows.value.size
            rows.value = rows.value.filterNot { it.dedupeKey == key }
            return before - rows.value.size
        }
    }

    @Test fun toggleAddsThenRemoves() = runBlocking {
        val repo = FavoriteRepository(FakeFavoriteDao()) { 42L }
        repo.toggle("name:sbt")
        assertEquals(setOf("name:sbt"), repo.keys.first())
        repo.toggle("name:sbt")
        assertTrue(repo.keys.first().isEmpty())
    }
}
