package com.canaisabertos.data

import com.canaisabertos.data.m3u.ChannelKeys
import com.canaisabertos.data.m3u.ChannelMerger
import com.canaisabertos.data.m3u.ParsedChannel
import com.canaisabertos.data.m3u.toChannel
import org.junit.Assert.assertEquals
import org.junit.Test

class ChannelMergerTest {
    private fun ch(source: String, name: String, tvgId: String? = null, url: String = "https://x.test/$name") =
        ParsedChannel(tvgId, name, null, null, url, null, null).toChannel(source)

    @Test
    fun normalizeStripsAccentsBracketsAndQualityTag() {
        assertEquals("tv brasil", ChannelKeys.normalize("TV Brasil HD (720p) [Geo-blocked]"))
        assertEquals("tv camara", ChannelKeys.normalize("TV Câmara"))
        assertEquals("redetv", ChannelKeys.normalize("RedeTV!"))
    }

    @Test
    fun dedupesByTvgIdAndFirstSourceWins() {
        val a = ch("a", "TV Brasil", "TVBrasil.br")
        val b = ch("b", "TV Brasil HD", "tvbrasil.br")
        val out = ChannelMerger.merge(listOf(a, b))
        assertEquals(listOf("a"), out.map { it.sourceId })
    }

    @Test
    fun dedupesByNormalizedNameWhenNoTvgId() {
        val a = ch("a", "Band")
        val b = ch("b", "Band HD")
        val c = ch("b", "SBT")
        assertEquals(listOf("Band", "SBT"), ChannelMerger.merge(listOf(a, b, c)).map { it.name })
    }

    @Test
    fun keepsDistinctTvgIdsEvenWithSameName() {
        val a = ch("a", "Globo", "globo.sp")
        val b = ch("a", "Globo", "globo.rj")
        assertEquals(2, ChannelMerger.merge(listOf(a, b)).size)
    }

    @Test
    fun nameOnlyChannelIsDuplicateOfEarlierChannelWithTvgId() {
        val a = ch("a", "Cultura", "cultura.br")
        val b = ch("b", "Cultura")
        assertEquals(1, ChannelMerger.merge(listOf(a, b)).size)
    }
}
