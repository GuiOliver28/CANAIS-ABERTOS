package com.canaisabertos.data

import com.canaisabertos.data.net.DownloadException
import com.canaisabertos.data.net.M3uDownloader
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test

class M3uDownloaderTest {
    private lateinit var server: MockWebServer
    private val playlist = "#EXTM3U\n#EXTINF:-1,Canal\nhttps://s.test/a.m3u8\n"

    // backoff zerado para o teste não dormir
    private fun downloader() = M3uDownloader(OkHttpClient(), maxAttempts = 3, baseBackoffMs = 0)

    @Before fun setUp() { server = MockWebServer().apply { start() } }
    @After fun tearDown() { server.shutdown() }

    private fun url() = server.url("/list.m3u").toString()

    @Test
    fun retriesOn5xxThenSucceeds() = runBlocking {
        server.enqueue(MockResponse().setResponseCode(503))
        server.enqueue(MockResponse().setResponseCode(503))
        server.enqueue(MockResponse().setResponseCode(200).setBody(playlist))
        val r = downloader().download(url())
        assertEquals(1, r.size)
        assertEquals(3, server.requestCount)
    }

    @Test
    fun doesNotRetryOn404() = runBlocking {
        server.enqueue(MockResponse().setResponseCode(404))
        try {
            downloader().download(url())
            fail("deveria falhar")
        } catch (e: DownloadException) {
            assertFalse(e.retryable)
            assertTrue(e.message!!.contains("404"))
        }
        assertEquals(1, server.requestCount)
    }

    @Test
    fun givesUpAfterMaxAttempts() = runBlocking {
        repeat(3) { server.enqueue(MockResponse().setResponseCode(500)) }
        try {
            downloader().download(url())
            fail("deveria falhar")
        } catch (e: DownloadException) {
            assertTrue(e.retryable)
        }
        assertEquals(3, server.requestCount)
    }

    @Test
    fun emptyOrNonM3uBodyFailsWithoutRetry() = runBlocking {
        server.enqueue(MockResponse().setResponseCode(200).setBody("<html>oops</html>"))
        try {
            downloader().download(url())
            fail("deveria falhar")
        } catch (e: DownloadException) {
            assertFalse(e.retryable)
        }
        assertEquals(1, server.requestCount)
    }

    @Test
    fun invalidUrlFailsFast() = runBlocking {
        try {
            downloader().download("não é url")
            fail("deveria falhar")
        } catch (e: DownloadException) {
            assertFalse(e.retryable)
        }
    }
}
