package com.canaisabertos.data

import com.canaisabertos.data.model.Source
import com.canaisabertos.data.model.SourceHealth
import com.canaisabertos.data.model.SourceStatus
import com.canaisabertos.data.repo.DefaultSources
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class DefaultSourcesTest {
    @Test
    fun parsesBundledSourcesJson() {
        val json = File("src/main/assets/sources.json").readText()
        val s = DefaultSources.parse(json)
        assertEquals(listOf("iptv-org-br", "iptv-com-br"), s.map { it.id })
        assertTrue(s.all { it.builtin && it.enabled })
    }

    @Test
    fun healthReflectsStatusAndFreshness() {
        val now = 10L * Source.STALE_AFTER_MS
        val base = Source(id = "x", name = "x", url = "https://x.test/l.m3u")
        assertEquals(SourceHealth.PENDING, base.health(now))
        assertEquals(SourceHealth.FAILED, base.copy(status = SourceStatus.FAILED).health(now))
        assertEquals(SourceHealth.OK, base.copy(status = SourceStatus.OK, lastDownloadAt = now - 1000).health(now))
        assertEquals(
            SourceHealth.STALE,
            base.copy(status = SourceStatus.OK, lastDownloadAt = now - Source.STALE_AFTER_MS - 1).health(now),
        )
    }
}
