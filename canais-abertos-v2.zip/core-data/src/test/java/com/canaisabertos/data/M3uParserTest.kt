package com.canaisabertos.data

import com.canaisabertos.data.m3u.M3uParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class M3uParserTest {
    @Test
    fun parsesBasicEntry() {
        val m3u = """
            #EXTM3U
            #EXTINF:-1 tvg-id="TVBrasil.br" tvg-logo="https://x/logo.png" group-title="Público",TV Brasil
            https://example.com/a.m3u8
        """.trimIndent()
        val r = M3uParser.parse(m3u)
        assertEquals(1, r.size)
        assertEquals("TV Brasil", r[0].name)
        assertEquals("TVBrasil.br", r[0].tvgId)
        assertEquals("https://x/logo.png", r[0].logoUrl)
        assertEquals("Público", r[0].groupTitle)
        assertEquals("https://example.com/a.m3u8", r[0].streamUrl)
    }

    @Test
    fun toleratesBomCrlfAndBlankLines() {
        val m3u = "﻿#EXTM3U\r\n\r\n#EXTINF:-1,Canal A\r\n\r\nhttp://a.test/1.m3u8\r\n"
        val r = M3uParser.parse(m3u)
        assertEquals(1, r.size)
        assertEquals("Canal A", r[0].name)
        assertNull(r[0].tvgId)
        assertNull(r[0].logoUrl)
    }

    @Test
    fun commaInsideQuotedAttributeDoesNotSplitName() {
        val m3u = """
            #EXTINF:-1 group-title="Notícias, Esportes" tvg-id="b.br",Canal B
            https://b.test/b.m3u8
        """.trimIndent()
        val r = M3uParser.parse(m3u).single()
        assertEquals("Canal B", r.name)
        assertEquals("Notícias, Esportes", r.groupTitle)
    }

    @Test
    fun readsVlcOptions() {
        val m3u = """
            #EXTINF:-1,Canal C
            #EXTVLCOPT:http-user-agent=MeuUA/1.0
            #EXTVLCOPT:http-referrer=https://ref.test/
            https://c.test/c.m3u8
        """.trimIndent()
        val r = M3uParser.parse(m3u).single()
        assertEquals("MeuUA/1.0", r.userAgent)
        assertEquals("https://ref.test/", r.referrer)
    }

    @Test
    fun skipsNonHttpStreamsAndKeepsParsing() {
        val m3u = """
            #EXTINF:-1,RTMP
            rtmp://x.test/live
            #EXTINF:-1,Ok
            https://ok.test/ok.m3u8
        """.trimIndent()
        val r = M3uParser.parse(m3u)
        assertEquals(listOf("Ok"), r.map { it.name })
    }

    @Test
    fun fallsBackToTvgNameAndExtGrp() {
        val m3u = """
            #EXTINF:-1 tvg-name="Sem Nome Visivel",
            #EXTGRP:Variedades
            https://d.test/d.m3u8
        """.trimIndent()
        val r = M3uParser.parse(m3u).single()
        assertEquals("Sem Nome Visivel", r.name)
        assertEquals("Variedades", r.groupTitle)
    }

    @Test
    fun extinfWithoutUrlIsDroppedWhenNextExtinfArrives() {
        val m3u = """
            #EXTINF:-1,Orfao
            #EXTINF:-1,Valido
            https://v.test/v.m3u8
        """.trimIndent()
        assertEquals(listOf("Valido"), M3uParser.parse(m3u).map { it.name })
    }

    @Test
    fun htmlOrGarbageYieldsNoChannels() {
        assertEquals(0, M3uParser.parse("<html><body>404</body></html>").size)
        assertEquals(0, M3uParser.parse("").size)
    }
}
