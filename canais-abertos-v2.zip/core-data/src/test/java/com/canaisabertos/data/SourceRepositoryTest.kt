package com.canaisabertos.data

import com.canaisabertos.data.db.ChannelDao
import com.canaisabertos.data.db.SourceDao
import com.canaisabertos.data.model.Channel
import com.canaisabertos.data.model.Source
import com.canaisabertos.data.model.SourceStatus
import com.canaisabertos.data.net.M3uDownloader
import com.canaisabertos.data.repo.SourceRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.mockwebserver.Dispatcher
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.RecordedRequest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/** DAOs em memória: testam a lógica do repositório sem Room/Robolectric. */
private class FakeSourceDao : SourceDao {
    val rows = MutableStateFlow<List<Source>>(emptyList())
    private fun sorted(l: List<Source>) = l.sortedWith(compareBy({ it.position }, { it.name }))

    override fun observeAll(): Flow<List<Source>> = rows.map { sorted(it) }
    override suspend fun getAll() = sorted(rows.value)
    override suspend fun get(id: String) = rows.value.firstOrNull { it.id == id }
    override suspend fun insertAll(sources: List<Source>) {
        val known = rows.value.map { it.id }.toSet()
        rows.value = rows.value + sources.filter { it.id !in known }
    }
    override suspend fun insert(source: Source) { rows.value = rows.value + source }
    private fun mutate(id: String, f: (Source) -> Source) {
        rows.value = rows.value.map { if (it.id == id) f(it) else it }
    }
    override suspend fun setEnabled(id: String, enabled: Boolean) = mutate(id) { it.copy(enabled = enabled) }
    override suspend fun markSuccess(id: String, at: Long, count: Int) =
        mutate(id) { it.copy(lastDownloadAt = at, channelCount = count, status = SourceStatus.OK, lastError = null) }
    override suspend fun markFailure(id: String, error: String?) =
        mutate(id) { it.copy(status = SourceStatus.FAILED, lastError = error) }
    override suspend fun deleteCustom(id: String): Int {
        val before = rows.value.size
        rows.value = rows.value.filterNot { it.id == id && !it.builtin }
        return before - rows.value.size
    }
    override suspend fun nextPosition() = (rows.value.maxOfOrNull { it.position } ?: -1) + 1
}

private class FakeChannelDao(private val sources: FakeSourceDao) : ChannelDao() {
    val rows = MutableStateFlow<List<Channel>>(emptyList())
    private var nextId = 1L

    override suspend fun deleteBySource(sourceId: String) {
        rows.value = rows.value.filterNot { it.sourceId == sourceId }
    }
    override suspend fun insertAll(channels: List<Channel>) {
        rows.value = rows.value + channels.map { it.copy(id = nextId++) }
    }
    override fun observeEnabled(): Flow<List<Channel>> =
        combine(sources.observeAll(), rows) { srcs, chs ->
            srcs.filter { it.enabled }.flatMap { s -> chs.filter { it.sourceId == s.id } }
        }
}

class SourceRepositoryTest {
    private lateinit var server: MockWebServer
    private lateinit var sourceDao: FakeSourceDao
    private lateinit var channelDao: FakeChannelDao
    private lateinit var repo: SourceRepository
    private var now = 1_000_000_000_000L

    private val playlists = mutableMapOf(
        "/a.m3u" to "#EXTM3U\n#EXTINF:-1 tvg-id=\"tv.a\",Canal A\nhttps://s.test/a.m3u8\n",
        "/b.m3u" to "#EXTM3U\n#EXTINF:-1 tvg-id=\"tv.a\",Canal A Repetido\nhttps://s.test/a2.m3u8\n" +
            "#EXTINF:-1,Canal B\nhttps://s.test/b.m3u8\n",
    )
    private var failPaths = mutableSetOf<String>()

    @Before
    fun setUp() {
        server = MockWebServer().apply {
            dispatcher = object : Dispatcher() {
                override fun dispatch(request: RecordedRequest): MockResponse {
                    val path = request.path ?: return MockResponse().setResponseCode(400)
                    if (path in failPaths) return MockResponse().setResponseCode(500)
                    val body = playlists[path] ?: return MockResponse().setResponseCode(404)
                    return MockResponse().setResponseCode(200).setBody(body)
                }
            }
            start()
        }
        sourceDao = FakeSourceDao()
        channelDao = FakeChannelDao(sourceDao)
        // 1 tentativa, sem backoff: falha vira falha imediatamente
        val downloader = M3uDownloader(OkHttpClient(), maxAttempts = 1, baseBackoffMs = 0)
        repo = SourceRepository(sourceDao, channelDao, downloader) { now }
    }

    @After fun tearDown() { server.shutdown() }

    private fun url(path: String) = server.url(path).toString()
    private fun builtin(id: String, path: String) =
        Source(id = id, name = id, url = url(path), enabled = true, builtin = true)

    @Test
    fun seedDefaultsIsIdempotentAndKeepsUserToggle() = runBlocking {
        val defaults = listOf(builtin("a", "/a.m3u"), builtin("b", "/b.m3u"))
        repo.seedDefaults(defaults)
        repo.setEnabled("a", false)
        repo.seedDefaults(defaults)

        val all = sourceDao.getAll()
        assertEquals(listOf("a", "b"), all.map { it.id })
        assertEquals(listOf(0, 1), all.map { it.position })
        assertFalse(all.first { it.id == "a" }.enabled)
    }

    @Test
    fun addSourceRejectsInvalidUrls() = runBlocking {
        assertTrue(repo.addSource("ftp://x.test/l.m3u", null).isFailure)
        assertTrue(repo.addSource("isso nao e url", null).isFailure)
        assertTrue(sourceDao.getAll().isEmpty())
    }

    @Test
    fun addSourceSavesOnlyAfterSuccessfulTestDownload() = runBlocking {
        val r = repo.addSource(url("/a.m3u"), "  Minha lista ")
        val s = r.getOrThrow()
        assertEquals("Minha lista", s.name)
        assertFalse(s.builtin)
        assertEquals(SourceStatus.OK, s.status)
        assertEquals(1, s.channelCount)
        assertEquals(1, channelDao.rows.value.size)
        assertEquals(1, sourceDao.getAll().size)
    }

    @Test
    fun addSourceUsesHostWhenNameIsBlank() = runBlocking {
        val s = repo.addSource(url("/a.m3u"), "   ").getOrThrow()
        assertEquals(server.hostName, s.name)
    }

    @Test
    fun addSourceDoesNotSaveWhenDownloadFails() = runBlocking {
        assertTrue(repo.addSource(url("/nao-existe.m3u"), null).isFailure)
        assertTrue(sourceDao.getAll().isEmpty())
        assertTrue(channelDao.rows.value.isEmpty())
    }

    @Test
    fun addSourceRejectsDuplicateUrl() = runBlocking {
        repo.addSource(url("/a.m3u"), null).getOrThrow()
        assertTrue(repo.addSource(url("/a.m3u"), "outra").isFailure)
        assertEquals(1, sourceDao.getAll().size)
    }

    @Test
    fun builtinCannotBeRemovedButCustomCan() = runBlocking {
        repo.seedDefaults(listOf(builtin("a", "/a.m3u")))
        val custom = repo.addSource(url("/b.m3u"), "x").getOrThrow()
        assertFalse(repo.remove("a"))
        assertTrue(repo.remove(custom.id))
        assertEquals(listOf("a"), sourceDao.getAll().map { it.id })
    }

    @Test
    fun failedRefreshKeepsChannelsAndMarksSourceAsFailed() = runBlocking {
        repo.seedDefaults(listOf(builtin("a", "/a.m3u")))
        assertTrue(repo.refresh("a").isSuccess)
        failPaths += "/a.m3u"

        val r = repo.refresh("a")
        assertTrue(r.isFailure)
        val s = sourceDao.get("a")!!
        assertEquals(SourceStatus.FAILED, s.status)
        assertNotNull(s.lastError)
        assertEquals(1, s.channelCount)               // metadados do último sucesso preservados
        assertEquals(1, channelDao.rows.value.size)   // canais antigos continuam
    }

    @Test
    fun isRefreshingReturnsToFalseAfterSuccessAndAfterFailure() = runBlocking {
        repo.seedDefaults(listOf(builtin("a", "/a.m3u")))
        assertFalse(repo.isRefreshing.first())
        repo.refresh("a")
        assertFalse(repo.isRefreshing.first())
        failPaths += "/a.m3u"
        repo.refresh("a")
        assertFalse(repo.isRefreshing.first())
    }

    @Test
    fun refreshAllOnlyTouchesEnabledSources() = runBlocking {
        repo.seedDefaults(listOf(builtin("a", "/a.m3u"), builtin("b", "/b.m3u")))
        repo.setEnabled("b", false)

        val results = repo.refreshAll()
        assertEquals(setOf("a"), results.keys)
        assertEquals(1, server.requestCount)
    }

    @Test
    fun refreshStaleSkipsFreshSourcesAndRefreshesOldOnes() = runBlocking {
        repo.seedDefaults(listOf(builtin("a", "/a.m3u"), builtin("b", "/b.m3u")))
        repo.refreshAll()
        val after = server.requestCount

        // nada está desatualizado: sem rede
        assertTrue(repo.refreshStale().isEmpty())
        assertEquals(after, server.requestCount)

        // 8 dias depois: as duas voltam a ser baixadas
        now += 8L * 24 * 60 * 60 * 1000
        assertEquals(setOf("a", "b"), repo.refreshStale().keys)
    }

    @Test
    fun channelsAreMergedAcrossEnabledSourcesWithFirstSourceWinning() = runBlocking {
        repo.seedDefaults(listOf(builtin("a", "/a.m3u"), builtin("b", "/b.m3u")))
        repo.refreshAll()

        // "tv.a" aparece nas duas fontes; a de menor posição vence. "Canal B" só existe em b.
        val merged = repo.channels.first()
        assertEquals(listOf("Canal A", "Canal B"), merged.map { it.name })

        // desativar "a": o tv.a de "b" passa a valer
        repo.setEnabled("a", false)
        assertEquals(listOf("Canal A Repetido", "Canal B"), repo.channels.first().map { it.name })
    }
}
