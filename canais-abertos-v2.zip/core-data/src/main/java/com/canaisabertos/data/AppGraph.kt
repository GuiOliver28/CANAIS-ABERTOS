package com.canaisabertos.data

import android.content.Context
import com.canaisabertos.data.db.AppDatabase
import com.canaisabertos.data.net.HttpClientFactory
import com.canaisabertos.data.net.M3uDownloader
import com.canaisabertos.data.repo.DefaultSources
import com.canaisabertos.data.repo.FavoriteRepository
import com.canaisabertos.data.repo.SourceRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Injeção manual (sem Hilt/Dagger), criada uma vez na Application. */
class AppGraph(context: Context) {
    private val app = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    val database by lazy { AppDatabase.build(app) }
    val httpClient by lazy { HttpClientFactory.create(app.cacheDir) }
    val sourceRepository by lazy {
        SourceRepository(database.sourceDao(), database.channelDao(), M3uDownloader(httpClient))
    }

    val favoriteRepository by lazy { FavoriteRepository(database.favoriteDao()) }

    /**
     * Grava as fontes padrão no Room e baixa as ativas que nunca foram baixadas ou estão
     * desatualizadas (mais de 7 dias). Fontes frescas não geram rede na abertura do app.
     */
    fun bootstrap() {
        scope.launch {
            runCatching {
                sourceRepository.seedDefaults(DefaultSources.load(app))
                sourceRepository.refreshStale()
            }
        }
    }
}
