package com.canaisabertos.data.repo

import com.canaisabertos.data.db.FavoriteDao
import com.canaisabertos.data.model.Favorite
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class FavoriteRepository(
    private val dao: FavoriteDao,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    val keys: Flow<Set<String>> = dao.observeKeys().map { it.toSet() }

    /** Remove se já era favorito; senão adiciona. */
    suspend fun toggle(dedupeKey: String) {
        if (dao.delete(dedupeKey) == 0) dao.insert(Favorite(dedupeKey, clock()))
    }
}
