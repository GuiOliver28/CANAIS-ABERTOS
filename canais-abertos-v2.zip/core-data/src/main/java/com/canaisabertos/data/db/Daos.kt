package com.canaisabertos.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.canaisabertos.data.model.Channel
import com.canaisabertos.data.model.Source
import kotlinx.coroutines.flow.Flow

@Dao
interface SourceDao {
    @Query("SELECT * FROM sources ORDER BY position, name")
    fun observeAll(): Flow<List<Source>>

    @Query("SELECT * FROM sources ORDER BY position, name")
    suspend fun getAll(): List<Source>

    @Query("SELECT * FROM sources WHERE id = :id")
    suspend fun get(id: String): Source?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(sources: List<Source>)

    @Insert
    suspend fun insert(source: Source)

    @Query("UPDATE sources SET enabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: String, enabled: Boolean)

    @Query("UPDATE sources SET lastDownloadAt = :at, channelCount = :count, status = 'OK', lastError = NULL WHERE id = :id")
    suspend fun markSuccess(id: String, at: Long, count: Int)

    @Query("UPDATE sources SET status = 'FAILED', lastError = :error WHERE id = :id")
    suspend fun markFailure(id: String, error: String?)

    /** Só remove fontes customizadas; retorna quantas linhas foram apagadas. */
    @Query("DELETE FROM sources WHERE id = :id AND builtin = 0")
    suspend fun deleteCustom(id: String): Int

    @Query("SELECT COALESCE(MAX(position), -1) + 1 FROM sources")
    suspend fun nextPosition(): Int
}

@Dao
abstract class ChannelDao {
    @Query("DELETE FROM channels WHERE sourceId = :sourceId")
    abstract suspend fun deleteBySource(sourceId: String)

    @Insert
    abstract suspend fun insertAll(channels: List<Channel>)

    @Transaction
    open suspend fun replaceForSource(sourceId: String, channels: List<Channel>) {
        deleteBySource(sourceId)
        insertAll(channels)
    }

    /** Canais das fontes ativas, na ordem de prioridade das fontes (base da fusão/deduplicação). */
    @Query(
        """
        SELECT c.* FROM channels c
        INNER JOIN sources s ON s.id = c.sourceId
        WHERE s.enabled = 1
        ORDER BY s.position, c.name COLLATE NOCASE
        """,
    )
    abstract fun observeEnabled(): Flow<List<Channel>>
}
