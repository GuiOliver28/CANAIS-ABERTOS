package com.canaisabertos.data.m3u

import com.canaisabertos.data.model.Channel
import java.text.Normalizer
import java.util.Locale

object ChannelKeys {
    private val DIACRITICS = Regex("\\p{M}+")
    private val BRACKETS = Regex("\\(.*?\\)|\\[.*?]")
    private val NON_ALNUM = Regex("[^a-z0-9]+")
    private val QUALITY_SUFFIX = Regex("\\s(hd|fhd|sd|uhd|4k)$")

    /** "TV Brasil HD (720p) [Geo-blocked]" -> "tv brasil". */
    fun normalize(name: String): String {
        var s = Normalizer.normalize(name, Normalizer.Form.NFD).replace(DIACRITICS, "")
        s = s.lowercase(Locale.ROOT)
        s = s.replace(BRACKETS, " ")
        s = s.replace(NON_ALNUM, " ").trim()
        s = s.replace(QUALITY_SUFFIX, "")
        return s.ifEmpty { name.trim().lowercase(Locale.ROOT) }
    }

    fun dedupeKey(tvgId: String?, normalizedName: String): String =
        tvgId?.trim()?.lowercase(Locale.ROOT)?.takeIf { it.isNotEmpty() }?.let { "id:$it" }
            ?: "name:$normalizedName"
}

fun ParsedChannel.toChannel(sourceId: String): Channel {
    val normalized = ChannelKeys.normalize(name)
    return Channel(
        sourceId = sourceId,
        tvgId = tvgId,
        name = name,
        normalizedName = normalized,
        dedupeKey = ChannelKeys.dedupeKey(tvgId, normalized),
        logoUrl = logoUrl,
        groupTitle = groupTitle,
        streamUrl = streamUrl,
        userAgent = userAgent,
        referrer = referrer,
    )
}
