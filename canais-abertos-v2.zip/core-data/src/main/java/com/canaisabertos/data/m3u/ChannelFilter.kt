package com.canaisabertos.data.m3u

import com.canaisabertos.data.model.Channel

object ChannelFilter {
    /**
     * Busca por nome (sem acento, sem caixa, ignorando "HD" etc.), filtro opcional só de favoritos
     * e, na lista completa, favoritos fixados no topo (ordem original preservada dentro de cada grupo).
     */
    fun apply(
        channels: List<Channel>,
        query: String,
        favorites: Set<String>,
        onlyFavorites: Boolean,
    ): List<Channel> {
        val q = query.trim().takeIf { it.isNotEmpty() }?.let { ChannelKeys.normalize(it) }
        var out = channels
        if (onlyFavorites) out = out.filter { it.dedupeKey in favorites }
        if (q != null) out = out.filter { it.normalizedName.contains(q) }
        if (!onlyFavorites && favorites.isNotEmpty()) out = out.sortedByDescending { it.dedupeKey in favorites }
        return out
    }
}
