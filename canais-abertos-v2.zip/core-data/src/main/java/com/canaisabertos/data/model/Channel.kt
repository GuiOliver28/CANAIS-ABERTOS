package com.canaisabertos.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "channels",
    foreignKeys = [
        ForeignKey(
            entity = Source::class,
            parentColumns = ["id"],
            childColumns = ["sourceId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("sourceId"), Index("dedupeKey")],
)
data class Channel(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceId: String,
    val tvgId: String?,
    val name: String,
    val normalizedName: String,
    /**
     * Chave estável entre atualizações ("id:<tvg-id>" ou "name:<nome normalizado>").
     * Favoritos (passo 6) devem apontar para ela, não para [id], que muda a cada refresh.
     */
    val dedupeKey: String,
    val logoUrl: String?,
    val groupTitle: String?,
    val streamUrl: String,
    val userAgent: String?,
    val referrer: String?,
)
