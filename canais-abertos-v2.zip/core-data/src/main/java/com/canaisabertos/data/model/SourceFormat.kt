package com.canaisabertos.data.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Rótulos de status para a tela de Fontes (em caixa alta; a UI aplica o estilo de badge). */
fun Source.healthLabel(now: Long = System.currentTimeMillis()): String = when (health(now)) {
    SourceHealth.OK -> "OK"
    SourceHealth.FAILED -> "! FALHOU"
    SourceHealth.STALE -> "DESATUALIZADA"
    SourceHealth.PENDING -> "PENDENTE"
}

fun Source.lastDownloadLabel(): String =
    lastDownloadAt?.let { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(it)) }
        ?: "nunca"
