package com.canaisabertos.data.m3u

data class ParsedChannel(
    val tvgId: String?,
    val name: String,
    val logoUrl: String?,
    val groupTitle: String?,
    val streamUrl: String,
    val userAgent: String?,
    val referrer: String?,
)

/**
 * Parser M3U tolerante: aceita BOM, CRLF, linhas em branco, atributos com ou sem aspas,
 * vírgulas dentro de atributos entre aspas, #EXTVLCOPT e #EXTGRP. Entradas sem nome ou
 * com URL que não seja http(s) são ignoradas (Media3 HLS só consome http/https).
 */
object M3uParser {
    private val ATTR = Regex("""([A-Za-z0-9_\-]+)=(?:"([^"]*)"|([^\s",]+))""")

    private class Pending(
        var name: String? = null,
        var attrs: Map<String, String> = emptyMap(),
        var userAgent: String? = null,
        var referrer: String? = null,
        var extGrp: String? = null,
    )

    fun parse(text: String): List<ParsedChannel> = parse(text.lineSequence())

    fun parse(lines: Sequence<String>): List<ParsedChannel> {
        val out = ArrayList<ParsedChannel>()
        var pending: Pending? = null

        for (raw in lines) {
            val line = raw.removePrefix("﻿").trim()
            if (line.isEmpty()) continue
            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> pending = parseExtInf(line)
                line.startsWith("#EXTVLCOPT:", ignoreCase = true) -> {
                    val p = pending ?: Pending().also { pending = it }
                    applyVlcOpt(p, line.substring("#EXTVLCOPT:".length))
                }
                line.startsWith("#EXTGRP:", ignoreCase = true) -> {
                    val p = pending ?: Pending().also { pending = it }
                    p.extGrp = line.substring("#EXTGRP:".length).trim()
                }
                line.startsWith("#") -> Unit // #EXTM3U, #KODIPROP, comentários
                else -> {
                    val p = pending
                    pending = null
                    if (p != null && isHttp(line)) {
                        build(p, line)?.let { out.add(it) }
                    }
                }
            }
        }
        return out
    }

    private fun parseExtInf(line: String): Pending {
        val body = line.substringAfter(':', "")
        // Primeira vírgula fora de aspas separa metadados do nome.
        var inQuote = false
        var comma = -1
        for ((i, c) in body.withIndex()) {
            if (c == '"') inQuote = !inQuote
            else if (c == ',' && !inQuote) {
                comma = i
                break
            }
        }
        val header = if (comma >= 0) body.substring(0, comma) else body
        val name = if (comma >= 0) body.substring(comma + 1).trim() else ""
        val attrs = ATTR.findAll(header).associate { m ->
            m.groupValues[1].lowercase() to (m.groups[2]?.value ?: m.groups[3]?.value ?: "")
        }
        return Pending(name = name, attrs = attrs)
    }

    private fun applyVlcOpt(p: Pending, opt: String) {
        val key = opt.substringBefore('=').trim().lowercase()
        val value = opt.substringAfter('=', "").trim().ifEmpty { null }
        when (key) {
            "http-user-agent" -> p.userAgent = value
            "http-referrer", "http-referer" -> p.referrer = value
        }
    }

    private fun build(p: Pending, url: String): ParsedChannel? {
        val name = p.name.nullIfBlank() ?: p.attrs["tvg-name"].nullIfBlank() ?: return null
        return ParsedChannel(
            tvgId = p.attrs["tvg-id"].nullIfBlank(),
            name = name,
            logoUrl = p.attrs["tvg-logo"].nullIfBlank(),
            groupTitle = p.attrs["group-title"].nullIfBlank() ?: p.extGrp.nullIfBlank(),
            streamUrl = url,
            userAgent = p.userAgent,
            referrer = p.referrer,
        )
    }

    private fun isHttp(url: String) =
        url.startsWith("http://", ignoreCase = true) || url.startsWith("https://", ignoreCase = true)

    private fun String?.nullIfBlank(): String? = this?.trim()?.takeIf { it.isNotEmpty() }
}
