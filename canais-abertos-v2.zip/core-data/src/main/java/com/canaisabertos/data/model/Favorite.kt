package com.canaisabertos.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Favorito ligado à [Channel.dedupeKey], que sobrevive a refresh e a troca de fonte. */
@Entity(tableName = "favorites")
data class Favorite(
    @PrimaryKey val dedupeKey: String,
    val addedAt: Long,
)
