package com.canaisabertos.data.repo

import android.content.Context
import com.canaisabertos.data.model.Source
import org.json.JSONArray

object DefaultSources {
    const val ASSET_NAME = "sources.json"

    fun parse(json: String): List<Source> {
        val arr = JSONArray(json)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Source(
                id = o.getString("id"),
                name = o.getString("name"),
                url = o.getString("url"),
                enabled = o.optBoolean("enabled", true),
                builtin = true,
            )
        }
    }

    fun load(context: Context): List<Source> =
        parse(context.assets.open(ASSET_NAME).bufferedReader().use { it.readText() })
}
