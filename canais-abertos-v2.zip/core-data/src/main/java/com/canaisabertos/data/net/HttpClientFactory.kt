package com.canaisabertos.data.net

import okhttp3.Cache
import okhttp3.OkHttpClient
import java.io.File
import java.util.concurrent.TimeUnit

object HttpClientFactory {
    const val TIMEOUT_SECONDS = 5L
    private const val CACHE_BYTES = 10L * 1024 * 1024

    fun create(cacheDir: File): OkHttpClient =
        OkHttpClient.Builder()
            .cache(Cache(File(cacheDir, "http"), CACHE_BYTES))
            .connectTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .readTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .writeTimeout(TIMEOUT_SECONDS, TimeUnit.SECONDS)
            .build()
}
