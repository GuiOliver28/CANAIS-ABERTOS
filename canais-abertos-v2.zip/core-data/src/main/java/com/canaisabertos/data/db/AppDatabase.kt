package com.canaisabertos.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.canaisabertos.data.model.Channel
import com.canaisabertos.data.model.Favorite
import com.canaisabertos.data.model.Source

// Versão 1: o app ainda não foi publicado, então favoritos entram sem migração.
@Database(entities = [Source::class, Channel::class, Favorite::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun sourceDao(): SourceDao
    abstract fun channelDao(): ChannelDao
    abstract fun favoriteDao(): FavoriteDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "canais-abertos.db")
                .build()
    }
}
