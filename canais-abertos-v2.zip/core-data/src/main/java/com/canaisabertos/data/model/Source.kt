package com.canaisabertos.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class SourceStatus { PENDING, OK, FAILED }

/** Estado exibido na tela de Fontes (calculado, não persistido). */
enum class SourceHealth { PENDING, OK, FAILED, STALE }

@Entity(tableName = "sources")
data class Source(
    @PrimaryKey val id: String,
    val name: String,
    val url: String,
    val enabled: Boolean = true,
    val builtin: Boolean = false,
    /** Ordem de prioridade: na deduplicação, a fonte de menor posição vence. */
    val position: Int = 0,
    val lastDownloadAt: Long? = null,
    val channelCount: Int = 0,
    val status: SourceStatus = SourceStatus.PENDING,
    val lastError: String? = null,
) {
    fun isStale(now: Long = System.currentTimeMillis()): Boolean =
        lastDownloadAt == null || now - lastDownloadAt > STALE_AFTER_MS

    fun health(now: Long = System.currentTimeMillis()): SourceHealth = when (status) {
        SourceStatus.PENDING -> SourceHealth.PENDING
        SourceStatus.FAILED -> SourceHealth.FAILED
        SourceStatus.OK -> if (isStale(now)) SourceHealth.STALE else SourceHealth.OK
    }

    companion object {
        const val STALE_AFTER_MS = 7L * 24 * 60 * 60 * 1000
    }
}
