package com.canaisabertos.data

/** Implementado pela Application para que ViewModels (via factory) alcancem o [AppGraph]. */
interface GraphProvider {
    val graph: AppGraph
}
