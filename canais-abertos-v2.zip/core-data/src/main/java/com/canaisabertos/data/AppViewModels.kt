package com.canaisabertos.data

import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.CreationExtras
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory

object AppViewModels {
    val Factory: ViewModelProvider.Factory = viewModelFactory {
        initializer { graph().let { ChannelListViewModel(it.sourceRepository, it.favoriteRepository) } }
        initializer { SourcesViewModel(graph().sourceRepository) }
    }

    private fun CreationExtras.graph(): AppGraph {
        val app = this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY]
        return (app as GraphProvider).graph
    }
}
