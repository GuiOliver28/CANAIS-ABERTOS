package com.canaisabertos.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.canaisabertos.data.m3u.ChannelFilter
import com.canaisabertos.data.model.Channel
import com.canaisabertos.data.repo.FavoriteRepository
import com.canaisabertos.data.repo.SourceRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** ViewModel compartilhado por :ui-tv e :ui-mobile. */
class ChannelListViewModel(
    private val repo: SourceRepository,
    private val favorites: FavoriteRepository,
) : ViewModel() {
    private val keep = SharingStarted.WhileSubscribed(5_000)

    /** Todos os canais das fontes ativas (fundidos), sem busca nem filtro. */
    val channels: StateFlow<List<Channel>> = repo.channels.stateIn(viewModelScope, keep, emptyList())

    val favoriteKeys: StateFlow<Set<String>> = favorites.keys.stateIn(viewModelScope, keep, emptySet())

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    private val _onlyFavorites = MutableStateFlow(false)
    val onlyFavorites: StateFlow<Boolean> = _onlyFavorites.asStateFlow()

    /** O que a tela mostra (e o que o player percorre ao trocar de canal). */
    val visible: StateFlow<List<Channel>> =
        combine(channels, _query, favoriteKeys, _onlyFavorites) { all, q, favs, only ->
            ChannelFilter.apply(all, q, favs, only)
        }.flowOn(Dispatchers.Default).stateIn(viewModelScope, keep, emptyList())

    /** Reflete qualquer download em andamento, inclusive o da abertura do app. */
    val isRefreshing: StateFlow<Boolean> = repo.isRefreshing.stateIn(viewModelScope, keep, false)

    fun setQuery(q: String) { _query.value = q }

    fun toggleOnlyFavorites() = _onlyFavorites.update { !it }

    fun toggleFavorite(channel: Channel) {
        viewModelScope.launch { favorites.toggle(channel.dedupeKey) }
    }

    fun refresh() {
        if (isRefreshing.value) return
        viewModelScope.launch { repo.refreshAll() }
    }
}
