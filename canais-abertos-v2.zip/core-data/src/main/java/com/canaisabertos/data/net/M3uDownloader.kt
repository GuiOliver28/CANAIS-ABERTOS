package com.canaisabertos.data.net

import com.canaisabertos.data.m3u.M3uParser
import com.canaisabertos.data.m3u.ParsedChannel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.CacheControl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

class DownloadException(
    message: String,
    val retryable: Boolean,
    cause: Throwable? = null,
) : IOException(message, cause)

/**
 * Baixa e interpreta uma lista M3U. Faz até [maxAttempts] tentativas com backoff exponencial
 * (base, 2x base, 4x base...) para erro de rede, timeout, 5xx, 408 e 429. Outros 4xx, URL inválida
 * e lista sem canais não são repetidos. Usa revalidação (ETag) no cache HTTP do OkHttp.
 */
class M3uDownloader(
    private val client: OkHttpClient,
    private val maxAttempts: Int = 3,
    private val baseBackoffMs: Long = 500L,
) {
    suspend fun download(url: String): List<ParsedChannel> = withContext(Dispatchers.IO) {
        var last: IOException? = null
        for (attempt in 1..maxAttempts) {
            try {
                return@withContext fetchOnce(url)
            } catch (e: IOException) {
                last = e
                val retryable = (e as? DownloadException)?.retryable ?: true
                if (!retryable || attempt == maxAttempts) throw e
                delay(baseBackoffMs * (1L shl (attempt - 1)))
            }
        }
        throw last ?: DownloadException("falha desconhecida", retryable = false)
    }

    private fun fetchOnce(url: String): List<ParsedChannel> {
        val httpUrl = url.trim().toHttpUrlOrNull()
            ?: throw DownloadException("URL inválida", retryable = false)
        val request = Request.Builder()
            .url(httpUrl)
            .header("User-Agent", "CanaisAbertos/1.0")
            .cacheControl(CacheControl.Builder().maxAge(0, TimeUnit.SECONDS).build())
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val code = response.code
                throw DownloadException(
                    "HTTP $code",
                    retryable = code >= 500 || code == 429 || code == 408,
                )
            }
            val body = response.body ?: throw DownloadException("resposta sem corpo", retryable = true)
            val channels = body.byteStream().bufferedReader().useLines { M3uParser.parse(it) }
            if (channels.isEmpty()) {
                throw DownloadException("nenhum canal encontrado na lista", retryable = false)
            }
            return channels
        }
    }
}
