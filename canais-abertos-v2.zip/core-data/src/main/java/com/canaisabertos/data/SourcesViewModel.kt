package com.canaisabertos.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.canaisabertos.data.model.Source
import com.canaisabertos.data.repo.SourceRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SourcesViewModel(private val repo: SourceRepository) : ViewModel() {
    companion object {
        /** Id "virtual" usado em [busy] enquanto uma fonte nova está sendo testada. */
        const val ADDING = "__adding__"
        /** Id "virtual" usado em [busy] durante "Atualizar todas". */
        const val ALL = "__all__"
    }

    val sources: StateFlow<List<Source>> =
        repo.sources.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _busy = MutableStateFlow<Set<String>>(emptySet())
    val busy: StateFlow<Set<String>> = _busy.asStateFlow()

    private val _messages = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val messages: SharedFlow<String> = _messages.asSharedFlow()

    private suspend fun withBusy(id: String, block: suspend () -> Unit) {
        _busy.update { it + id }
        try {
            block()
        } finally {
            _busy.update { it - id }
        }
    }

    /** [onSuccess] roda na main thread, para a tela limpar o formulário. */
    fun add(url: String, name: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            withBusy(ADDING) {
                repo.addSource(url, name).fold(
                    onSuccess = {
                        _messages.tryEmit("Fonte adicionada: ${it.channelCount} canais")
                        onSuccess()
                    },
                    onFailure = { _messages.tryEmit("Não foi possível adicionar: ${it.message}") },
                )
            }
        }
    }

    fun setEnabled(id: String, enabled: Boolean) {
        viewModelScope.launch { repo.setEnabled(id, enabled) }
    }

    fun refresh(id: String) {
        viewModelScope.launch {
            withBusy(id) {
                repo.refresh(id).fold(
                    onSuccess = { _messages.tryEmit("Atualizada: $it canais") },
                    onFailure = { _messages.tryEmit("Falhou: ${it.message}") },
                )
            }
        }
    }

    fun refreshAll() {
        viewModelScope.launch {
            withBusy(ALL) {
                val results = repo.refreshAll()
                val failed = results.count { it.value.isFailure }
                _messages.tryEmit(
                    when {
                        results.isEmpty() -> "Nenhuma fonte ativa para atualizar"
                        failed == 0 -> "${results.size} fonte(s) atualizada(s)"
                        else -> "${results.size - failed} atualizada(s), $failed falhou(aram)"
                    },
                )
            }
        }
    }

    fun remove(id: String) {
        viewModelScope.launch {
            if (!repo.remove(id)) _messages.tryEmit("Fontes padrão só podem ser desativadas")
        }
    }
}
