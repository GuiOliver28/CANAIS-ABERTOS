package com.canaisabertos.data.m3u

import com.canaisabertos.data.model.Channel
import java.util.Locale

object ChannelMerger {
    /**
     * Funde canais de várias fontes. A entrada deve vir ordenada por prioridade de fonte
     * (quem aparece primeiro vence). Com tvg-id, duplicata = mesmo tvg-id; sem tvg-id,
     * duplicata = mesmo nome normalizado (inclusive de um canal que veio com tvg-id).
     */
    fun merge(channels: List<Channel>): List<Channel> {
        val ids = HashSet<String>()
        val names = HashSet<String>()
        val out = ArrayList<Channel>(channels.size)
        for (c in channels) {
            val id = c.tvgId?.trim()?.lowercase(Locale.ROOT)?.takeIf { it.isNotEmpty() }
            val duplicate = if (id != null) id in ids else c.normalizedName in names
            if (duplicate) continue
            if (id != null) ids += id
            names += c.normalizedName
            out += c
        }
        return out
    }
}
