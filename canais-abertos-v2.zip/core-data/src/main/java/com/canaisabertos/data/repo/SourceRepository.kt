package com.canaisabertos.data.repo

import com.canaisabertos.data.db.ChannelDao
import com.canaisabertos.data.db.SourceDao
import com.canaisabertos.data.m3u.ChannelMerger
import com.canaisabertos.data.m3u.toChannel
import com.canaisabertos.data.model.Channel
import com.canaisabertos.data.model.Source
import com.canaisabertos.data.model.SourceStatus
import com.canaisabertos.data.net.M3uDownloader
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.Dispatchers
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import java.util.UUID

class SourceRepository(
    private val sourceDao: SourceDao,
    private val channelDao: ChannelDao,
    private val downloader: M3uDownloader,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    val sources: Flow<List<Source>> = sourceDao.observeAll()

    private val activeRefreshes = MutableStateFlow(0)

    /** true enquanto qualquer fonte está sendo baixada (inclusive no bootstrap, antes da UI pedir). */
    val isRefreshing: Flow<Boolean> = activeRefreshes.map { it > 0 }

    /** Canais das fontes ativas, já fundidos e deduplicados. */
    val channels: Flow<List<Channel>> =
        channelDao.observeEnabled().map { ChannelMerger.merge(it) }.flowOn(Dispatchers.Default)

    /** Insere as fontes padrão que ainda não existem; nunca sobrescreve toggles do usuário. */
    suspend fun seedDefaults(defaults: List<Source>) {
        val existing = sourceDao.getAll().map { it.id }.toSet()
        var position = sourceDao.nextPosition()
        val fresh = defaults.filter { it.id !in existing }
            .map { it.copy(builtin = true, position = position++) }
        if (fresh.isNotEmpty()) sourceDao.insertAll(fresh)
    }

    suspend fun refresh(id: String): Result<Int> {
        val source = sourceDao.get(id)
            ?: return Result.failure(IllegalArgumentException("fonte não encontrada"))
        activeRefreshes.update { it + 1 }
        return try {
            val channels = downloader.download(source.url).map { it.toChannel(source.id) }
            channelDao.replaceForSource(source.id, channels)
            sourceDao.markSuccess(source.id, clock(), channels.size)
            Result.success(channels.size)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // Mantém os canais já salvos; só marca a fonte como falha.
            sourceDao.markFailure(source.id, e.message ?: e::class.java.simpleName)
            Result.failure(e)
        } finally {
            activeRefreshes.update { it - 1 }
        }
    }

    /** "Atualizar todas": atualiza as fontes ativas em paralelo. */
    suspend fun refreshAll(): Map<String, Result<Int>> = coroutineScope {
        sourceDao.getAll().filter { it.enabled }
            .map { s -> async { s.id to refresh(s.id) } }
            .awaitAll()
            .toMap()
    }

    /** Na abertura do app: atualiza só as fontes ativas nunca baixadas ou desatualizadas. */
    suspend fun refreshStale(): Map<String, Result<Int>> = coroutineScope {
        val now = clock()
        sourceDao.getAll().filter { it.enabled && it.isStale(now) }
            .map { s -> async { s.id to refresh(s.id) } }
            .awaitAll()
            .toMap()
    }

    /** Valida a URL, testa o download e só então salva a fonte (com seus canais). */
    suspend fun addSource(url: String, name: String?): Result<Source> {
        val cleanUrl = url.trim()
        val httpUrl = cleanUrl.toHttpUrlOrNull()
            ?: return Result.failure(IllegalArgumentException("URL inválida (use http:// ou https://)"))
        if (sourceDao.getAll().any { it.url.equals(cleanUrl, ignoreCase = true) }) {
            return Result.failure(IllegalArgumentException("essa fonte já foi adicionada"))
        }
        return try {
            val id = UUID.randomUUID().toString()
            val channels = downloader.download(cleanUrl).map { it.toChannel(id) }
            val source = Source(
                id = id,
                name = name?.trim()?.takeIf { it.isNotEmpty() } ?: httpUrl.host,
                url = cleanUrl,
                enabled = true,
                builtin = false,
                position = sourceDao.nextPosition(),
                lastDownloadAt = clock(),
                channelCount = channels.size,
                status = SourceStatus.OK,
            )
            sourceDao.insert(source)
            channelDao.replaceForSource(id, channels)
            Result.success(source)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun setEnabled(id: String, enabled: Boolean) = sourceDao.setEnabled(id, enabled)

    /** Retorna false se a fonte é builtin (só pode ser desativada) ou não existe. */
    suspend fun remove(id: String): Boolean = sourceDao.deleteCustom(id) > 0
}
