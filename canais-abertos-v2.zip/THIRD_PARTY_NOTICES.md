# Avisos de terceiros

O código do Canais Abertos é MIT (veja `LICENSE`). O app usa os componentes abaixo, cada um com a sua própria licença. As licenças foram anotadas de memória: **confira no repositório de cada projeto antes de publicar o app**.

| Componente | Licença | Observação |
|---|---|---|
| Inter (fonte) | SIL Open Font License 1.1 | arquivos em `ui-common/src/main/res/font/`; texto da licença em `licenses/INTER-OFL-copyright.txt` |
| AndroidX: Compose, Material3, Activity, Lifecycle, Room, Media3, TV Material | Apache License 2.0 | |
| Kotlin, kotlinx.coroutines | Apache License 2.0 | |
| OkHttp | Apache License 2.0 | |
| Coil | Apache License 2.0 | |
| Somente testes: JUnit | Eclipse Public License 1.0 | não vai no APK |
| Somente testes: MockWebServer (OkHttp) | Apache License 2.0 | não vai no APK |
| Somente testes: `org.json:json` | licença JSON | não vai no APK |

## Fontes de canais

O app não inclui nenhuma lista de canais. Ele baixa as listas M3U que o usuário configurar (por padrão, as de `sources.json`). Os direitos sobre listas, logos e streams são dos respectivos donos; use apenas fontes públicas e legítimas.
