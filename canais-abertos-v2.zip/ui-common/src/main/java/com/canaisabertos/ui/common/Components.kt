package com.canaisabertos.ui.common

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage

/** Badge "AO VIVO": ponto branco pulsante + texto labelSmall bold em caixa alta. */
@Composable
fun LiveBadge(modifier: Modifier = Modifier, color: Color = Mono.White) {
    val transition = rememberInfiniteTransition(label = "live")
    val dotAlpha by transition.animateFloat(
        initialValue = 1f,
        targetValue = 0.25f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "dot",
    )
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(Modifier.size(8.dp).alpha(dotAlpha).background(color, CircleShape))
        Text("AO VIVO", style = MaterialTheme.typography.labelSmall, color = color)
    }
}

/** Logo 1:1 provisório (iniciais). Troca por imagem real quando o loader de logos entrar. */
@Composable
fun ChannelLogoPlaceholder(name: String, modifier: Modifier = Modifier) {
    val initials = name.split(" ")
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercase() }
    Box(
        modifier = modifier.aspectRatio(1f).background(Mono.Gray600, RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center,
    ) {
        Text(initials, style = MaterialTheme.typography.titleLarge, color = Mono.White)
    }
}

/** Marcador de erro monocromático: círculo com contorno branco e "!" (sem vermelho). */
@Composable
fun ErrorMark(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(56.dp)
            .border(3.dp, Mono.White, CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text("!", style = MaterialTheme.typography.headlineMedium, color = Mono.White)
    }
}

/**
 * Logo 1:1 do canal. Com [logoUrl], carrega a imagem sobre um quadro branco (logos costumam ser
 * feitos para fundo claro e continuam monocromáticos na UI); sem URL, enquanto carrega ou se falhar,
 * mostra as iniciais ([ChannelLogoPlaceholder]).
 */
@Composable
fun ChannelLogo(name: String, logoUrl: String?, modifier: Modifier = Modifier) {
    if (logoUrl.isNullOrBlank()) {
        ChannelLogoPlaceholder(name, modifier)
        return
    }
    Box(
        modifier = modifier.aspectRatio(1f).background(Mono.White, RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center,
    ) {
        SubcomposeAsyncImage(
            model = logoUrl,
            contentDescription = name,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize().padding(6.dp),
            loading = { ChannelLogoPlaceholder(name, Modifier.fillMaxSize()) },
            error = { ChannelLogoPlaceholder(name, Modifier.fillMaxSize()) },
        )
    }
}
