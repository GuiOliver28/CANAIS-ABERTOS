package com.canaisabertos.ui.common

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private fun scheme(background: androidx.compose.ui.graphics.Color) = darkColorScheme(
    primary = Mono.White,
    onPrimary = Mono.Black,
    secondary = Mono.Gray200,
    onSecondary = Mono.Black,
    background = background,
    onBackground = Mono.White,
    surface = Mono.Gray900,
    onSurface = Mono.White,
    surfaceVariant = Mono.Gray800,
    onSurfaceVariant = Mono.Gray200,
    outline = Mono.Gray600,
    outlineVariant = Mono.Gray600,
    error = Mono.Gray200,   // erro monocromático: cinza claro + ícone "!"
    onError = Mono.Black,
)

/** TV usa preto absoluto; mobile usa preto suave. App é sempre escuro. */
@Composable
fun AppTheme(isTv: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = scheme(if (isTv) Mono.Black else Mono.BlackSoft),
        typography = AppTypography,
        content = content,
    )
}
