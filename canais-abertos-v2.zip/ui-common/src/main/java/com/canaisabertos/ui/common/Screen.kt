package com.canaisabertos.ui.common

/** Telas do app. Navegação simples por estado, compartilhada por TV e mobile. */
enum class Screen { LIST, SOURCES }
