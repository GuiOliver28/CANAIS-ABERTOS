package com.canaisabertos.ui.common

import androidx.compose.ui.graphics.Color

/** Paleta monocromática. Sem cores de acento: hierarquia vem de peso, tamanho e contraste. */
object Mono {
    val Black = Color(0xFF000000)      // background TV e player
    val BlackSoft = Color(0xFF0A0A0A)  // background mobile
    val Gray900 = Color(0xFF121212)    // surface
    val Gray800 = Color(0xFF1E1E1E)    // surface variant / cards
    val Gray600 = Color(0xFF3A3A3A)    // divider, outline
    val Gray400 = Color(0xFF888888)    // texto secundário, ícones inativos
    val Gray200 = Color(0xFFD0D0D0)    // texto em cards
    val White = Color(0xFFFFFFFF)      // texto primário, foco, destaque
}
