package com.canaisabertos.player

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.canaisabertos.data.model.Channel
import kotlinx.coroutines.flow.StateFlow

/** Sobrevive a rotação; o ExoPlayer só é liberado quando a Activity termina de vez. */
class PlayerViewModel(application: Application) : ViewModel() {
    private val controller = PlayerController(application)

    val player get() = controller.player
    val state: StateFlow<PlayerState> = controller.state

    fun start(channels: List<Channel>, index: Int) = controller.start(channels, index)
    fun next() = controller.next()
    fun previous() = controller.previous()
    fun stop() = controller.stop()
    fun togglePlayPause() = controller.togglePlayPause()
    fun onAppStopped() = controller.suspend()
    fun onAppStarted() { if (state.value.channel != null) controller.retry() }

    override fun onCleared() = controller.release()

    companion object {
        val Factory: ViewModelProvider.Factory = viewModelFactory {
            initializer {
                PlayerViewModel(this[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as Application)
            }
        }
    }
}
