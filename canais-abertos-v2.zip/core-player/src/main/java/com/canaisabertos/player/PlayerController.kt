@file:OptIn(UnstableApi::class)

package com.canaisabertos.player

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy
import com.canaisabertos.data.model.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class PlaybackStatus { LOADING, PLAYING, UNAVAILABLE }

data class PlayerState(
    val channel: Channel? = null,
    val index: Int = -1,
    val status: PlaybackStatus = PlaybackStatus.LOADING,
    /** Canal sugerido quando o atual está indisponível. */
    val suggestedNext: Channel? = null,
)

/**
 * Envolve o ExoPlayer: um canal por vez, timeout de [loadTimeoutMs] para começar a tocar,
 * retry limitado do Media3 (1 tentativa extra por requisição) e fallback manual para o próximo
 * canal. Deve ser usado só na main thread.
 */
class PlayerController(
    context: Context,
    private val loadTimeoutMs: Long = DEFAULT_TIMEOUT_MS,
) {
    companion object {
        const val DEFAULT_TIMEOUT_MS = 5_000L
    }

    private val handler = Handler(Looper.getMainLooper())
    private var channels: List<Channel> = emptyList()

    private val httpFactory = DefaultHttpDataSource.Factory()
        .setAllowCrossProtocolRedirects(true) // muitas listas misturam http e https
        .setConnectTimeoutMs(loadTimeoutMs.toInt())
        .setReadTimeoutMs(loadTimeoutMs.toInt())

    val player: ExoPlayer = ExoPlayer.Builder(context.applicationContext)
        .setMediaSourceFactory(
            DefaultMediaSourceFactory(httpFactory)
                .setLoadErrorHandlingPolicy(DefaultLoadErrorHandlingPolicy(/* minimumLoadableRetryCount = */ 1)),
        )
        .setLoadControl(DefaultLoadControl())
        .build()

    private val _state = MutableStateFlow(PlayerState())
    val state: StateFlow<PlayerState> = _state.asStateFlow()

    private val timeout = Runnable { markUnavailable() }

    private val listener = object : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: Int) {
            if (playbackState == Player.STATE_READY && _state.value.channel != null) {
                handler.removeCallbacks(timeout)
                _state.update { it.copy(status = PlaybackStatus.PLAYING, suggestedNext = null) }
            }
        }

        override fun onPlayerError(error: PlaybackException) = markUnavailable()
    }

    init {
        player.addListener(listener)
        player.playWhenReady = true
    }

    /** Abre a lista [list] no canal [index]. */
    fun start(list: List<Channel>, index: Int) {
        if (list.isEmpty() || index !in list.indices) return
        channels = list
        play(index)
    }

    fun next() = play(ChannelNavigator.next(_state.value.index, channels.size))

    fun previous() = play(ChannelNavigator.previous(_state.value.index, channels.size))

    /** Tenta de novo o canal atual (por exemplo depois de voltar do segundo plano). */
    fun retry() {
        val i = _state.value.index
        if (i in channels.indices) play(i)
    }

    /** Fecha o player e volta para a lista. */
    fun stop() {
        handler.removeCallbacks(timeout)
        player.stop()
        player.clearMediaItems()
        _state.value = PlayerState()
    }

    /** App foi para segundo plano: para o stream (é ao vivo, não faz sentido pausar) sem perder o canal. */
    fun suspend() {
        handler.removeCallbacks(timeout)
        player.stop()
    }

    fun togglePlayPause() {
        if (player.isPlaying) player.pause() else player.play()
    }

    fun release() {
        handler.removeCallbacks(timeout)
        player.removeListener(listener)
        player.release()
    }

    private fun play(index: Int) {
        if (index !in channels.indices) return
        val channel = channels[index]
        handler.removeCallbacks(timeout)
        player.stop()

        val headers = buildMap {
            channel.referrer?.let { put("Referer", it) }
        }
        httpFactory.setUserAgent(channel.userAgent ?: "CanaisAbertos/1.0")
        httpFactory.setDefaultRequestProperties(headers)

        _state.value = PlayerState(channel = channel, index = index, status = PlaybackStatus.LOADING)
        player.setMediaItem(MediaItem.fromUri(channel.streamUrl))
        player.prepare()
        player.play()
        handler.postDelayed(timeout, loadTimeoutMs)
    }

    private fun markUnavailable() {
        handler.removeCallbacks(timeout)
        val s = _state.value
        if (s.channel == null || s.status == PlaybackStatus.UNAVAILABLE) return
        player.stop()
        val nextIndex = ChannelNavigator.next(s.index, channels.size)
        _state.value = s.copy(
            status = PlaybackStatus.UNAVAILABLE,
            suggestedNext = channels.getOrNull(nextIndex)?.takeIf { nextIndex != s.index },
        )
    }
}
