package com.canaisabertos.player

/** Aritmética de índice circular para trocar de canal. Pura, para ser testável na JVM. */
object ChannelNavigator {
    fun next(index: Int, size: Int): Int =
        if (size <= 0) -1 else (index + 1).mod(size)

    fun previous(index: Int, size: Int): Int =
        if (size <= 0) -1 else (index - 1).mod(size)
}
