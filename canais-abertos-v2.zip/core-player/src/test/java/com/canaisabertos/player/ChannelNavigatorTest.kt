package com.canaisabertos.player

import org.junit.Assert.assertEquals
import org.junit.Test

class ChannelNavigatorTest {
    @Test fun nextWrapsAround() {
        assertEquals(1, ChannelNavigator.next(0, 3))
        assertEquals(0, ChannelNavigator.next(2, 3))
    }

    @Test fun previousWrapsAround() {
        assertEquals(2, ChannelNavigator.previous(0, 3))
        assertEquals(0, ChannelNavigator.previous(1, 3))
    }

    @Test fun singleChannelStaysOnItself() {
        assertEquals(0, ChannelNavigator.next(0, 1))
        assertEquals(0, ChannelNavigator.previous(0, 1))
    }

    @Test fun emptyListReturnsMinusOne() {
        assertEquals(-1, ChannelNavigator.next(0, 0))
        assertEquals(-1, ChannelNavigator.previous(0, 0))
    }
}
