# PROGRESS

Legenda: **escrito** = código no disco; **build** = resultado de `./gradlew assembleDebug`.
Em todas as etapas o build ficou **não executado** (ver BLOCKERS.md, B1).

| Etapa | Descrição | Escrito | Comando | Resultado | Tempo |
|---|---|---|---|---|---|
| 1 | Esqueleto, tema, MainActivity, manifest dupla entrada | sim | `./gradlew assembleDebug` | não executado (B1) | — |
| 2 | Parser M3U, Room, downloader, repositório, sources.json, testes JVM | sim | `./gradlew :core-data:testDebugUnitTest` | não executado (B1) | — |
| 3 | Lista mock nas duas UIs | sim | `./gradlew assembleDebug` | não executado (B1) | — |
| 4 | Gerenciador de fontes (SourcesViewModel, telas TV/mobile, SourceRepositoryTest, refresh na abertura só de fontes desatualizadas) | sim | `./gradlew :core-data:testDebugUnitTest assembleDebug` | não executado (B1) | — |
| 5 | Player Media3: core-player (PlayerController, timeout 5s, retry limitado, fallback p/ próximo), player TV (overlay 3s, teclas D-pad/mídia) e mobile (PlayerView com controles pretos/brancos, landscape) | sim | `./gradlew :core-player:testDebugUnitTest assembleDebug` | não executado (B1) | — |
| 6 | Favoritos (Room, por dedupeKey), busca sem acento, filtro de favoritos, estado vazio com CTA, pull-to-refresh, estrela (toque no mobile, OK longo na TV) | sim | `./gradlew :core-data:testDebugUnitTest assembleDebug` | não executado (B1) | — |
| 7 | Documentação e CI (README, TESTING, DESIGN, FINAL_REPORT, workflow do GitHub Actions). Release e APK **não** gerados | docs sim; release não | `./gradlew assembleRelease` | não executado (B1) | — |

## Verificações feitas sem build
- `sources.json` é JSON válido e idêntico nas duas cópias (raiz e `core-data/src/main/assets`).
- Contraste da paleta calculado por script (tabela em DESIGN.md).
- Workflow YAML validado só na sintaxe; nunca executado.
- Pendente: alteração não commitada em `TvPlayerScreen.kt` (BLOCKERS B3).

## Depois da etapa 7 (autonomia total até o fim do app)
- `ac0160b` commit da edição pendente do player da TV (B3).
- `3bae45c` logos reais com Coil e `material-ripple` explícito (B4).
- `b6ec10b` correções da verificação própria: conflito `abiFilters`/`splits`, estado "atualizando" no bootstrap, barras do sistema, memória do Gradle (B5).
- Revisor independente falhou 2 vezes por limite de uso; substituído por scripts de import e dependência (BLOCKERS B5).
- Testes escritos: 42. Executados: 0. Builds: 0.
