package com.canaisabertos.ui.tv

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.ui.PlayerView
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.Text
import com.canaisabertos.player.PlaybackStatus
import com.canaisabertos.player.PlayerViewModel
import com.canaisabertos.ui.common.ErrorMark
import com.canaisabertos.ui.common.LiveBadge
import com.canaisabertos.ui.common.Mono
import kotlinx.coroutines.delay

private const val OVERLAY_MS = 3_000L
private val OverlayBg = Color(0xB3000000) // preto 70%

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun TvPlayerScreen(vm: PlayerViewModel) {
    val state by vm.state.collectAsState()
    val focus = remember { FocusRequester() }
    var overlayVisible by remember { mutableStateOf(true) }
    var ping by remember { mutableIntStateOf(0) }

    BackHandler { vm.stop() }
    LaunchedEffect(Unit) { runCatching { focus.requestFocus() } }

    // Overlay aparece ao trocar de canal ou ao pedir info, e some após 3s.
    LaunchedEffect(ping, state.channel?.id) {
        overlayVisible = true
        delay(OVERLAY_MS)
        overlayVisible = false
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Mono.Black)
            .focusRequester(focus)
            .onPreviewKeyEvent { e ->
                if (e.type != KeyEventType.KeyDown) return@onPreviewKeyEvent false
                when (e.key) {
                    Key.DirectionUp, Key.ChannelUp, Key.MediaNext -> { vm.next(); true }
                    Key.DirectionDown, Key.ChannelDown, Key.MediaPrevious -> { vm.previous(); true }
                    Key.DirectionCenter, Key.Enter, Key.NumPadEnter ->
                        if (state.status == PlaybackStatus.UNAVAILABLE) { vm.next(); true } else { ping++; true }
                    Key.Menu, Key.Info -> { ping++; true }
                    Key.MediaPlayPause, Key.MediaPlay, Key.MediaPause -> { vm.togglePlayPause(); ping++; true }
                    else -> false
                }
            }
            .focusable(),
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false // controles são o overlay Compose + D-pad
                    isFocusable = false
                    isFocusableInTouchMode = false
                    keepScreenOn = true
                    player = vm.player
                }
            },
            onRelease = { it.player = null },
        )

        when (state.status) {
            PlaybackStatus.UNAVAILABLE -> Box(Modifier.fillMaxSize().background(OverlayBg), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ErrorMark()
                    Text(
                        "CANAL INDISPONÍVEL",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Mono.White,
                        textAlign = TextAlign.Center,
                    )
                    Text(state.channel?.name.orEmpty(), style = MaterialTheme.typography.titleLarge, color = Mono.Gray200)
                    state.suggestedNext?.let {
                        Text(
                            "OK ou CIMA: ${it.name.uppercase()}",
                            style = MaterialTheme.typography.titleMedium,
                            color = Mono.White,
                        )
                    }
                    Text("VOLTAR: lista de canais", style = MaterialTheme.typography.bodyMedium, color = Mono.Gray400)
                }
            }
            PlaybackStatus.LOADING -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("CARREGANDO…", style = MaterialTheme.typography.headlineMedium, color = Mono.White)
            }
            PlaybackStatus.PLAYING -> Unit
        }

        if (overlayVisible && state.status != PlaybackStatus.UNAVAILABLE) {
            Column(
                Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(OverlayBg)
                    .padding(horizontal = 48.dp, vertical = 24.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Text(
                    state.channel?.name.orEmpty(),
                    style = MaterialTheme.typography.displayLarge,
                    color = Mono.White,
                    maxLines = 1,
                )
                LiveBadge()
                state.channel?.groupTitle?.let {
                    Text(it, style = MaterialTheme.typography.bodyMedium, color = Mono.Gray200)
                }
                Text(
                    "CIMA / BAIXO: trocar canal · PLAY/PAUSE: pausar · VOLTAR: lista",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mono.Gray400,
                )
            }
        }
    }
}
