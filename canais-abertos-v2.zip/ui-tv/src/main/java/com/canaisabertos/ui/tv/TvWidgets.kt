package com.canaisabertos.ui.tv

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import com.canaisabertos.ui.common.Mono

private val BtnShape = RoundedCornerShape(12.dp)

/**
 * Botão TV. Primário: fundo branco/texto preto. Secundário: outline branco 2dp.
 * Foco: borda branca 3dp + escala 1.05; no primário a borda é preta para continuar visível sobre branco.
 */
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun TvButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    primary: Boolean = false,
    enabled: Boolean = true,
) {
    val container = if (primary) Mono.White else Mono.Black
    val content = if (primary) Mono.Black else Mono.White
    val focusRing = if (primary) Mono.Gray600 else Mono.White
    Surface(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        shape = ClickableSurfaceDefaults.shape(BtnShape),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = container,
            contentColor = content,
            focusedContainerColor = container,
            focusedContentColor = content,
            pressedContainerColor = container,
            pressedContentColor = content,
            disabledContainerColor = Mono.Gray800,
            disabledContentColor = Mono.Gray400,
        ),
        border = ClickableSurfaceDefaults.border(
            border = Border(BorderStroke(2.dp, if (primary) Mono.White else Mono.Gray400), shape = BtnShape),
            focusedBorder = Border(BorderStroke(3.dp, focusRing), shape = BtnShape),
            pressedBorder = Border(BorderStroke(3.dp, focusRing), shape = BtnShape),
        ),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.05f),
    ) {
        Text(
            text,
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp),
        )
    }
}

/** Campo de texto TV: focável por D-pad; OK abre o teclado virtual. Borda branca no foco. */
@Composable
fun TvTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
) {
    var focused by remember { mutableStateOf(false) }
    Box(
        modifier = modifier
            .background(Mono.Gray900, BtnShape)
            .border(if (focused) 3.dp else 2.dp, if (focused) Mono.White else Mono.Gray600, BtnShape)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.CenterStart,
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyLarge.copy(color = Mono.White),
            cursorBrush = SolidColor(Mono.White),
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
            modifier = Modifier.onFocusChanged { focused = it.isFocused || it.hasFocus }.then(Modifier),
            decorationBox = { inner ->
                if (value.isEmpty()) {
                    androidx.compose.material3.Text(
                        placeholder,
                        style = MaterialTheme.typography.bodyLarge,
                        color = Mono.Gray400,
                    )
                }
                inner()
            },
        )
    }
}
