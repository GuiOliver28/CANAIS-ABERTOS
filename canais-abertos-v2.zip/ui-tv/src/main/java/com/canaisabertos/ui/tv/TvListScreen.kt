package com.canaisabertos.ui.tv

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.tv.material3.Border
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import com.canaisabertos.data.AppViewModels
import com.canaisabertos.data.ChannelListViewModel
import com.canaisabertos.data.model.Channel
import com.canaisabertos.ui.common.ChannelLogo
import com.canaisabertos.ui.common.LiveBadge
import com.canaisabertos.ui.common.Mono

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun TvListScreen(
    onOpenSources: () -> Unit,
    onPlay: (List<Channel>, Int) -> Unit,
    vm: ChannelListViewModel = viewModel(factory = AppViewModels.Factory),
) {
    val all by vm.channels.collectAsState()
    val visible by vm.visible.collectAsState()
    val favorites by vm.favoriteKeys.collectAsState()
    val query by vm.query.collectAsState()
    val onlyFavorites by vm.onlyFavorites.collectAsState()
    val refreshing by vm.isRefreshing.collectAsState()
    val firstItem = remember { FocusRequester() }
    val sourcesButton = remember { FocusRequester() }

    // Foco inicial: primeiro canal; sem canais, o botão de fontes.
    LaunchedEffect(all.isNotEmpty()) {
        runCatching { if (all.isNotEmpty()) firstItem.requestFocus() else sourcesButton.requestFocus() }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 32.dp)) { // margem de overscan
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CANAIS ABERTOS", style = MaterialTheme.typography.headlineMedium, color = Mono.White)
                Text(
                    if (visible.size == all.size) "${all.size} canais · segure OK para favoritar"
                    else "${visible.size} de ${all.size} canais · segure OK para favoritar",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mono.Gray400,
                )
            }
            TvButton(
                if (refreshing) "ATUALIZANDO…" else "ATUALIZAR",
                onClick = vm::refresh,
                enabled = !refreshing,
            )
            Spacer(Modifier.padding(start = 12.dp))
            TvButton("FONTES", onClick = onOpenSources, modifier = Modifier.focusRequester(sourcesButton))
        }

        if (all.isNotEmpty()) {
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                TvTextField(query, vm::setQuery, "Buscar canal (OK abre o teclado)", Modifier.weight(1f))
                TvButton(
                    if (onlyFavorites) "★ FAVORITOS" else "☆ FAVORITOS",
                    onClick = vm::toggleOnlyFavorites,
                    primary = onlyFavorites,
                )
            }
        }
        Spacer(Modifier.height(8.dp))

        when {
            all.isEmpty() -> CenterMessage(
                title = if (refreshing) "CARREGANDO CANAIS…" else "NENHUM CANAL",
                body = if (refreshing) null else "Nenhuma fonte ativa carregou. Ative, adicione ou atualize uma fonte.",
                cta = if (refreshing) null else "GERENCIAR FONTES" to onOpenSources,
            )
            visible.isEmpty() -> CenterMessage(
                title = if (onlyFavorites && query.isBlank()) "SEM FAVORITOS" else "NADA ENCONTRADO",
                body = if (onlyFavorites && query.isBlank()) "Segure OK em um canal para favoritar."
                else "Nenhum canal combina com a busca.",
                cta = null,
            )
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                // Folga para a borda de 3dp e a escala 1.05 não serem cortadas nas bordas do grid.
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(24.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                itemsIndexed(visible, key = { _, c -> c.id }) { index, channel ->
                    TvChannelCard(
                        channel = channel,
                        favorite = channel.dedupeKey in favorites,
                        onClick = { onPlay(visible, index) },
                        onToggleFavorite = { vm.toggleFavorite(channel) },
                        modifier = if (index == 0) Modifier.focusRequester(firstItem) else Modifier,
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun CenterMessage(title: String, body: String?, cta: Pair<String, () -> Unit>?) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.headlineMedium, color = Mono.White)
            if (body != null) {
                Text(body, style = MaterialTheme.typography.bodyLarge, color = Mono.Gray200, textAlign = TextAlign.Center)
            }
            if (cta != null) TvButton(cta.first, onClick = cta.second, primary = true)
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvChannelCard(
    channel: Channel,
    favorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(12.dp)
    Surface(
        onClick = onClick,
        onLongClick = onToggleFavorite, // segurar OK = favoritar / desfavoritar
        modifier = modifier.fillMaxWidth(),
        shape = ClickableSurfaceDefaults.shape(shape),
        colors = ClickableSurfaceDefaults.colors(
            containerColor = Mono.Gray800,
            contentColor = Mono.White,
            focusedContainerColor = Mono.Gray800,
            focusedContentColor = Mono.White,
            pressedContainerColor = Mono.Gray800,
            pressedContentColor = Mono.White,
        ),
        // Foco: borda branca 3dp + escala 1.05 (sem cor de acento).
        border = ClickableSurfaceDefaults.border(
            focusedBorder = Border(BorderStroke(3.dp, Mono.White), shape = shape),
            pressedBorder = Border(BorderStroke(3.dp, Mono.White), shape = shape),
        ),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.05f),
    ) {
        Box(Modifier.fillMaxWidth()) {
            Column(
                Modifier.fillMaxWidth().padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                ChannelLogo(channel.name, channel.logoUrl, Modifier.fillMaxWidth(0.5f))
                Text(
                    channel.name,
                    style = MaterialTheme.typography.titleLarge,
                    color = Mono.White,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                LiveBadge()
            }
            if (favorite) {
                Text(
                    "★",
                    style = MaterialTheme.typography.titleLarge,
                    color = Mono.White,
                    modifier = Modifier.align(Alignment.TopEnd).padding(10.dp),
                )
            }
        }
    }
}
