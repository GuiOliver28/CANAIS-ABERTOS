package com.canaisabertos.ui.tv

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.canaisabertos.player.PlayerViewModel
import com.canaisabertos.ui.common.Mono
import com.canaisabertos.ui.common.Screen

@Composable
fun TvRoot() {
    var screen by rememberSaveable { mutableStateOf(Screen.LIST) }
    val player: PlayerViewModel = viewModel(factory = PlayerViewModel.Factory)
    val playerState by player.state.collectAsState()

    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { player.onAppStopped() }
    LifecycleEventEffect(Lifecycle.Event.ON_START) { player.onAppStarted() }

    Box(Modifier.fillMaxSize().background(Mono.Black)) {
        when {
            playerState.channel != null -> TvPlayerScreen(player)
            screen == Screen.SOURCES -> TvSourcesScreen(onBack = { screen = Screen.LIST })
            else -> TvListScreen(
                onOpenSources = { screen = Screen.SOURCES },
                onPlay = player::start,
            )
        }
    }
}
