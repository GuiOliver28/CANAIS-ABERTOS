package com.canaisabertos.ui.tv

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.Text
import com.canaisabertos.data.AppViewModels
import com.canaisabertos.data.SourcesViewModel
import com.canaisabertos.data.model.Source
import com.canaisabertos.data.model.SourceHealth
import com.canaisabertos.data.model.healthLabel
import com.canaisabertos.data.model.lastDownloadLabel
import com.canaisabertos.ui.common.Mono

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun TvSourcesScreen(
    onBack: () -> Unit,
    vm: SourcesViewModel = viewModel(factory = AppViewModels.Factory),
) {
    BackHandler(onBack = onBack)
    val sources by vm.sources.collectAsState()
    val busy by vm.busy.collectAsState()
    var message by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(vm) { vm.messages.collect { message = it } }

    var url by rememberSaveable { mutableStateOf("") }
    var name by rememberSaveable { mutableStateOf("") }
    val adding = SourcesViewModel.ADDING in busy
    val refreshingAll = SourcesViewModel.ALL in busy
    val firstFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { firstFocus.requestFocus() } }

    Column(Modifier.fillMaxSize().padding(horizontal = 48.dp, vertical = 32.dp)) {
        Text("FONTES", style = MaterialTheme.typography.headlineMedium, color = Mono.White)
        Text(
            message ?: "Voltar: sai desta tela. OK em um campo abre o teclado.",
            style = MaterialTheme.typography.bodyMedium,
            color = if (message != null) Mono.White else Mono.Gray400,
        )

        LazyColumn(
            contentPadding = PaddingValues(vertical = 16.dp, horizontal = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            item {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    TvTextField(
                        url, { url = it }, "URL da lista M3U (https://…)",
                        modifier = Modifier.fillMaxWidth().focusRequester(firstFocus),
                        keyboardType = KeyboardType.Uri,
                    )
                    TvTextField(name, { name = it }, "Nome (opcional)", Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        TvButton(
                            if (adding) "TESTANDO…" else "ADICIONAR",
                            onClick = { vm.add(url, name) { url = ""; name = "" } },
                            primary = true,
                            enabled = url.isNotBlank() && !adding,
                        )
                        TvButton(
                            if (refreshingAll) "ATUALIZANDO…" else "ATUALIZAR TODAS",
                            onClick = vm::refreshAll,
                            enabled = !refreshingAll,
                        )
                        TvButton("VOLTAR", onClick = onBack)
                    }
                }
            }
            items(sources, key = { it.id }) { source ->
                TvSourceRow(
                    source = source,
                    busy = source.id in busy || refreshingAll,
                    onToggle = { vm.setEnabled(source.id, !source.enabled) },
                    onRefresh = { vm.refresh(source.id) },
                    onRemove = { vm.remove(source.id) },
                )
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvSourceRow(
    source: Source,
    busy: Boolean,
    onToggle: () -> Unit,
    onRefresh: () -> Unit,
    onRemove: () -> Unit,
) {
    val now = System.currentTimeMillis()
    val health = source.health(now)
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier.fillMaxWidth().background(Mono.Gray800, shape).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(source.name, style = MaterialTheme.typography.titleLarge, color = Mono.White)
        Text(
            source.url, style = MaterialTheme.typography.bodyMedium, color = Mono.Gray400,
            maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            val filled = health == SourceHealth.OK
            Box(
                Modifier
                    .then(if (filled) Modifier.background(Mono.White, RoundedCornerShape(6.dp))
                          else Modifier.border(1.5.dp, Mono.Gray400, RoundedCornerShape(6.dp)))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
            ) {
                Text(
                    source.healthLabel(now),
                    style = MaterialTheme.typography.labelSmall,
                    color = if (filled) Mono.Black else Mono.Gray200,
                )
            }
            Text(
                "${source.channelCount} canais · ${source.lastDownloadLabel()}",
                style = MaterialTheme.typography.bodyMedium, color = Mono.Gray200,
            )
        }
        when (health) {
            SourceHealth.STALE -> Text(
                "Sem atualizar há mais de 7 dias. Sugestão: ATUALIZAR.",
                style = MaterialTheme.typography.bodyMedium, color = Mono.Gray200,
            )
            SourceHealth.FAILED -> Text(
                "Erro: ${source.lastError ?: "desconhecido"}",
                style = MaterialTheme.typography.bodyMedium, color = Mono.Gray200,
            )
            else -> Unit
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TvButton(if (source.enabled) "ATIVA · DESATIVAR" else "INATIVA · ATIVAR", onToggle, primary = !source.enabled)
            TvButton(if (busy) "ATUALIZANDO…" else "ATUALIZAR", onRefresh, enabled = !busy)
            if (!source.builtin) TvButton("REMOVER", onRemove)
        }
    }
}
