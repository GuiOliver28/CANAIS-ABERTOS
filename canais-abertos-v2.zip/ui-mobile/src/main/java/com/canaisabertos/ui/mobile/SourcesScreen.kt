package com.canaisabertos.ui.mobile

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.canaisabertos.data.AppViewModels
import com.canaisabertos.data.SourcesViewModel
import com.canaisabertos.data.model.Source
import com.canaisabertos.data.model.SourceHealth
import com.canaisabertos.data.model.healthLabel
import com.canaisabertos.data.model.lastDownloadLabel
import com.canaisabertos.ui.common.Mono

@Composable
fun MobileSourcesScreen(
    onBack: () -> Unit,
    vm: SourcesViewModel = viewModel(factory = AppViewModels.Factory),
) {
    BackHandler(onBack = onBack)
    val sources by vm.sources.collectAsState()
    val busy by vm.busy.collectAsState()
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(vm) { vm.messages.collect { snackbar.showSnackbar(it) } }

    var url by rememberSaveable { mutableStateOf("") }
    var name by rememberSaveable { mutableStateOf("") }
    val adding = SourcesViewModel.ADDING in busy
    val refreshingAll = SourcesViewModel.ALL in busy

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.systemBars,
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    SecondaryButton("VOLTAR", onBack)
                    Text("FONTES", style = MaterialTheme.typography.headlineMedium, color = Mono.White)
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = url,
                        onValueChange = { url = it },
                        label = { Text("URL da lista M3U") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        colors = monoTextFieldColors(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nome (opcional)") },
                        singleLine = true,
                        colors = monoTextFieldColors(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        PrimaryButton(
                            if (adding) "TESTANDO…" else "ADICIONAR",
                            onClick = { vm.add(url, name) { url = ""; name = "" } },
                            enabled = url.isNotBlank() && !adding,
                        )
                        SecondaryButton(
                            if (refreshingAll) "ATUALIZANDO…" else "ATUALIZAR TODAS",
                            onClick = vm::refreshAll,
                            enabled = !refreshingAll,
                        )
                    }
                }
            }
            items(sources, key = { it.id }) { source ->
                SourceCard(
                    source = source,
                    busy = source.id in busy || refreshingAll,
                    onToggle = { vm.setEnabled(source.id, it) },
                    onRefresh = { vm.refresh(source.id) },
                    onRemove = { vm.remove(source.id) },
                )
            }
        }
    }
}

@Composable
private fun SourceCard(
    source: Source,
    busy: Boolean,
    onToggle: (Boolean) -> Unit,
    onRefresh: () -> Unit,
    onRemove: () -> Unit,
) {
    val now = System.currentTimeMillis()
    val health = source.health(now)
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(source.name, style = MaterialTheme.typography.titleLarge, color = Mono.White)
                    Text(
                        source.url,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mono.Gray400,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                Switch(checked = source.enabled, onCheckedChange = onToggle, colors = monoSwitchColors())
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatusBadge(source.healthLabel(now), filled = health == SourceHealth.OK)
                Text(
                    "${source.channelCount} canais · ${source.lastDownloadLabel()}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mono.Gray200,
                )
            }
            when (health) {
                SourceHealth.STALE -> Text(
                    "Sem atualizar há mais de 7 dias. Toque em ATUALIZAR.",
                    style = MaterialTheme.typography.bodyMedium, color = Mono.Gray200,
                )
                SourceHealth.FAILED -> Text(
                    "Erro: ${source.lastError ?: "desconhecido"}",
                    style = MaterialTheme.typography.bodyMedium, color = Mono.Gray200,
                )
                else -> Unit
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SecondaryButton(if (busy) "ATUALIZANDO…" else "ATUALIZAR", onRefresh, enabled = !busy)
                if (!source.builtin) SecondaryButton("REMOVER", onRemove)
            }
        }
    }
}
