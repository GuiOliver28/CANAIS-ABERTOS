package com.canaisabertos.ui.mobile

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.canaisabertos.ui.common.Mono

private val ButtonShape = RoundedCornerShape(12.dp)
private val ButtonPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)

/** Primário: fundo branco, texto preto bold. */
@Composable
fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled,
        shape = ButtonShape,
        contentPadding = ButtonPadding,
        colors = ButtonDefaults.buttonColors(
            containerColor = Mono.White,
            contentColor = Mono.Black,
            disabledContainerColor = Mono.Gray600,
            disabledContentColor = Mono.Gray400,
        ),
    ) { Text(text, style = MaterialTheme.typography.titleMedium) }
}

/** Secundário: outline branco 2dp, texto branco bold. */
@Composable
fun SecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    OutlinedButton(
        onClick = onClick,
        modifier = modifier,
        enabled = enabled,
        shape = ButtonShape,
        contentPadding = ButtonPadding,
        border = BorderStroke(2.dp, if (enabled) Mono.White else Mono.Gray600),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = Mono.White,
            disabledContentColor = Mono.Gray400,
        ),
    ) { Text(text, style = MaterialTheme.typography.titleMedium) }
}

@Composable
fun monoTextFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedTextColor = Mono.White,
    unfocusedTextColor = Mono.White,
    focusedBorderColor = Mono.White,
    unfocusedBorderColor = Mono.Gray600,
    focusedLabelColor = Mono.White,
    unfocusedLabelColor = Mono.Gray400,
    focusedPlaceholderColor = Mono.Gray400,
    unfocusedPlaceholderColor = Mono.Gray400,
    cursorColor = Mono.White,
)

@Composable
fun monoSwitchColors() = SwitchDefaults.colors(
    checkedThumbColor = Mono.Black,
    checkedTrackColor = Mono.White,
    checkedBorderColor = Mono.White,
    uncheckedThumbColor = Mono.Gray400,
    uncheckedTrackColor = Mono.Gray800,
    uncheckedBorderColor = Mono.Gray600,
)

/** Badge de status: "OK" preenchido em branco; demais estados só com contorno. */
@Composable
fun StatusBadge(label: String, filled: Boolean, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(6.dp)
    Box(
        modifier = modifier
            .then(
                if (filled) Modifier.background(Mono.White, shape)
                else Modifier.border(1.5.dp, Mono.Gray400, shape),
            )
            .padding(horizontal = 8.dp, vertical = 3.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelSmall,
            color = if (filled) Mono.Black else Mono.Gray200,
        )
    }
}
