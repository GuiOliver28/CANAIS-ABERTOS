# BLOCKERS

## B1 — Nenhum build é possível no ambiente de desenvolvimento (aberto)

**Etapas afetadas:** todas (checkpoint de build das etapas 1–7).

**Causa:** a sessão onde o código foi escrito não tem Android SDK e o proxy de saída recusa
`services.gradle.org`, `repo.maven.apache.org` e `dl.google.com` (HTTP 403 no CONNECT). O Gradle
não baixa nem a distribuição, nem o AGP, nem Room/OkHttp/Media3/Compose.

**Evidência:**
```
curl https://dl.google.com/dl/android/maven2/...   -> CONNECT tunnel failed, response 403
curl https://repo.maven.apache.org/maven2/...      -> CONNECT tunnel failed, response 403
curl https://services.gradle.org/distributions/    -> CONNECT tunnel failed, response 403
ANDROID_HOME / ANDROID_SDK_ROOT: vazios; sem kotlinc no PATH
```

**Decisão:** seguir a regra 3 (escrever o código offline e registrar). Não tentei contornar o proxy.
Nenhuma etapa foi marcada como "build verde". Os commits por etapa existem, mas a mensagem inclui
`[sem build]`.

**O que fazer na sua máquina:**
```
./gradlew :core-data:testDebugUnitTest   # testes JVM (parser, merger, downloader, repositório)
./gradlew assembleDebug
./gradlew assembleRelease
```
Requisitos: JDK 17+, Android SDK com platform 35 (`ANDROID_HOME` ou `local.properties` com `sdk.dir`).

## B2 — Pontos de API não verificados por compilação (aberto)

Escritos de memória da documentação pública; são os primeiros suspeitos se o build acusar erro:

- `androidx.tv:tv-material:1.0.0`: `Surface`, `Button`, `ClickableSurfaceDefaults.{shape,colors,border,scale}`, `ButtonDefaults.*`, `Border`.
- Material3 1.3.1: `RippleConfiguration` + `LocalRippleConfiguration` (com `androidx.compose.material.ripple.RippleAlpha`), `PullToRefreshBox`.
- Media3 1.4.1: layout de controles customizado (`mono_player_control_view.xml`, id `exo_play_pause` como `ImageButton`) e `DefaultLoadErrorHandlingPolicy(int)`.
- Versões escolhidas sem poder consultar o Maven: AGP 8.7.3, Kotlin 2.0.21, KSP 2.0.21-1.0.28, Room 2.6.1 (mantida; compatível com minSdk 22), Compose BOM 2024.11.00, Media3 1.4.1.

## B2 (complemento) — outros pontos de API para conferir no primeiro build

- `androidx.compose.material.ripple.RippleAlpha` (usado em `MobileRoot.kt`): pode exigir declarar `androidx.compose.material:material-ripple` no `ui-mobile/build.gradle.kts`.
- tv-material 1.0.0: parâmetro `onLongClick` de `Surface` (favoritar com OK longo), `Border`, `ClickableSurfaceDefaults.border(border=, focusedBorder=, pressedBorder=)`.
- Compose: `Key.Info`, `Key.ChannelUp/ChannelDown`, `LifecycleEventEffect`, `PullToRefreshBox` (opt-in experimental já declarado).
- Media3: qualquer símbolo marcado `@UnstableApi` usado fora de `PlayerController.kt` vira erro de compilação; só esse arquivo tem o opt-in.
- Testes JVM: `DefaultSourcesTest` usa `org.json` (dependência `org.json:json` de teste já declarada); se o stub do `android.jar` vencer, os testes que parseiam JSON falham.

## B3 — Edição pendente em `TvPlayerScreen.kt` (RESOLVIDO)

Removida a chamada `setShutterBackgroundColor` (API `@UnstableApi` do Media3, erro de compilação em Kotlin). Commit `ac0160b`.

## B4 — Logos dos canais não carregavam (RESOLVIDO, não testado em aparelho)

`ChannelLogo` (em `ui-common/Components.kt`) carrega `Channel.logoUrl` com Coil 2.7.0 sobre um quadro branco de 1:1; sem URL, enquanto carrega ou em erro, mostra as iniciais. Usado nas duas listas. Em aberto: só dá para ver se o contraste dos logos sobre o quadro branco fica bom rodando o app. Se ficar ruim, trocar o fundo em `ChannelLogo`.

## B5 — Revisão independente (SUBSTITUÍDA por verificação própria)

O revisor separado falhou duas vezes por limite de uso (HTTP 429) antes de ler qualquer arquivo, então não houve segunda opinião de outro agente. No lugar, fiz:
- script de imports (tipos e funções de extensão sem `import`): 49 arquivos, nenhum achado real (4 falsos positivos conferidos à mão);
- script de dependências: todo `import com.canaisabertos...` aponta para um símbolo que existe e todo módulo declara o que usa (0 problemas);
- leitura de lógica e de configuração do Gradle, que achou 4 problemas já corrigidos (commit `b6ec10b`): conflito `ndk.abiFilters` com `splits.abi` (o AGP recusa), tela vazia indevida na primeira abertura (o estado "atualizando" agora vem do repositório), ícones da barra de status escuros em celular com tema claro, e `-Xmx2g` baixo para o R8.

Nada disso substitui compilar. Os scripts não validam assinaturas de API.

## B6 — URL builtin do iptv-com não confirmada (aberto)

`https://raw.githubusercontent.com/iptv-com/iptv/main/lists/brazil.m3u`: esta sessão não alcança o GitHub. Uma busca na web pelo repositório `iptv-com/iptv` não achou nada com esse nome (só o `iptv-org/iptv` e espelhos). Isso não prova que não existe, mas é um sinal ruim. Mantive a fonte, como a especificação pede: se der 404, ela aparece como "falhou" e a outra continua funcionando (um 404 não é repetido). Se confirmar que não existe, editar `sources.json` e `core-data/src/main/assets/sources.json` (idênticos): remover a entrada ou trocar a URL.

## B7 — Decisões e lacunas que talvez precisem mudar (abertas)

- Keystore de release gerado nesta sessão (`keystore/release.jks`, `keystore.properties`, ambos no `.gitignore`): **existe só nesta sessão**. Recomendado gerar a sua própria chave (README).
- `usesCleartextTraffic="true"` no manifest: necessário para listas/streams `http://`, mas reduz a segurança. Decisão sua.
- `ndk.abiFilters` foi removido do `app/build.gradle.kts` (conflita com `splits.abi`); como o app não tem código nativo, os APKs por ABI saem equivalentes ao universal.
- Deduplicação remove variantes do mesmo canal (por exemplo HD e SD); não há fallback entre variantes.
- Ícones: a especificação pede Material Symbols; o código usa vetores próprios e os glifos ★ ☆, sem confirmar se a Inter os tem.
- O workflow `.github/workflows/android-build.yml` nunca rodou; as versões das actions (`checkout@v4`, `setup-java@v4`, `setup-android@v3`, `setup-gradle@v4`, `upload-artifact@v4`) vieram de memória.
- O workflow roda também `:core-player:testDebugUnitTest`, além do `:core-data:testDebugUnitTest` pedido.
- Licença: MIT, escolhida por mim (`LICENSE`, titular "Canais Abertos contributors"). Troque o titular pelo seu nome se quiser. As licenças dos componentes de terceiros em `THIRD_PARTY_NOTICES.md` foram anotadas de memória; conferir antes de publicar.
- `exportSchema = true` no Room grava `core-data/schemas/` no primeiro build; essa pasta deve ser commitada.

## Resolvidos

- Fonte Inter: os TTFs não estavam no projeto. Foram copiados das fontes OFL instaladas no sistema
  (`/usr/share/fonts/opentype/inter`, formato OTF, aceito em `res/font`). Licença em `licenses/`.
- Wrapper Gradle: gerado offline (`gradlew`, `gradle-wrapper.jar`, Gradle 8.10.2). A distribuição
  será baixada na primeira execução na sua máquina.
- Recursos que o manifest referenciava e não existiam: `strings.xml`, `themes.xml`, `ic_launcher`,
  `banner`, `proguard-rules.pro`.
