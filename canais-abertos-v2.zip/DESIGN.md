# DESIGN

Design system monocromático e bold. **Sem cores de acento**: toda a hierarquia vem de peso tipográfico, tamanho e contraste. Código em `ui-common/` (`Color.kt`, `Typography.kt`, `Theme.kt`, `Components.kt`); componentes específicos em `ui-tv/` e `ui-mobile/`.

> Estado: implementado em código, **nunca visto em tela** (o projeto não foi compilado). Veja a seção "Diferenças em relação à especificação".

## Paleta

Objeto `Mono` em `Color.kt`. O tema é sempre escuro (`darkColorScheme`).

| Token | Hex | Uso |
|---|---|---|
| Preto | `#000000` | fundo na TV e no player |
| Preto suave | `#0A0A0A` | fundo no celular |
| Cinza 900 | `#121212` | surface |
| Cinza 800 | `#1E1E1E` | cards, surface variant |
| Cinza 600 | `#3A3A3A` | divisor, contorno, logo placeholder |
| Cinza 400 | `#888888` | texto secundário, ícones inativos |
| Cinza 200 | `#D0D0D0` | texto em cards, erro |
| Branco | `#FFFFFF` | texto primário, foco, destaque |

Mapeamento Material 3: `primary` branco, `onPrimary` preto, `background` preto (TV) ou preto suave (celular), `surface` cinza 900, `surfaceVariant` cinza 800, `outline` cinza 600, `error` cinza 200 (nunca vermelho).

### Contraste (calculado, WCAG 2.x)

Meta: AA, 4,5:1 para texto. Valores calculados com a fórmula de luminância relativa; não foram conferidos em tela.

| Texto sobre fundo | Razão | AA |
|---|---|---|
| Branco / Preto | 21,00 | sim |
| Branco / Preto suave | 19,80 | sim |
| Branco / Cinza 900 | 18,73 | sim |
| Branco / Cinza 800 | 16,67 | sim |
| Cinza 200 / Cinza 800 | 10,81 | sim |
| Cinza 200 / Preto | 13,62 | sim |
| Cinza 400 / Preto | 5,92 | sim |
| Cinza 400 / Preto suave | 5,58 | sim |
| Cinza 400 / Cinza 900 | 5,28 | sim |
| Cinza 400 / Cinza 800 | 4,70 | sim (margem pequena) |
| Cinza 400 / Cinza 600 | 3,21 | **não** — não usar texto cinza 400 sobre cinza 600 |
| Cinza 600 / Preto | 1,85 | n/a — só para contornos e divisores, nunca texto |

## Tipografia

Fonte **Inter** (OFL), arquivos OTF em `ui-common/src/main/res/font/`: Medium 500, SemiBold 600, Bold 700, ExtraBold 800. Licença em `licenses/`. Todo texto de interface é Medium, SemiBold, Bold ou ExtraBold: o peso é a identidade visual.

| Estilo | Tamanho | Peso | Uso |
|---|---|---|---|
| `displayLarge` | 48 sp | ExtraBold 800 | título do canal no overlay do player (TV) |
| `headlineMedium` | 28 sp | Bold 700 | títulos de tela e de seção, mensagens centrais |
| `titleLarge` | 22 sp | Bold 700 | nome do canal e da fonte nos cards |
| `titleMedium` | 18 sp | SemiBold 600 | rótulos de UI e botões |
| `bodyLarge` | 16 sp | SemiBold 600 | texto principal |
| `bodyMedium` | 14 sp | Medium 500 | metadados |
| `labelSmall` | 12 sp | Bold 700, espaçamento 0,5 sp | badges e "AO VIVO"; o texto é passado em caixa alta |

## Componentes

**Card de canal** — fundo Cinza 800, cantos 12 dp, logo 1:1 centralizado (TV) ou à esquerda (celular), nome em `titleLarge`, badge "AO VIVO". Na TV o foco é borda branca de 3 dp e escala 1,05. No celular o estado pressionado é ripple branco a 12% de alpha.

**Badge "AO VIVO" (`LiveBadge`)** — ponto branco de 8 dp com opacidade pulsando (1,0 ↔ 0,25 em 0,9 s) e texto `labelSmall` em caixa alta.

**Botões** — primário: fundo branco, texto preto, `titleMedium`. Secundário: contorno branco de 2 dp, texto branco. Cantos de 12 dp. Desabilitado: cinza 800/600 com texto cinza 400. Na TV (`TvButton`) o foco é borda de 3 dp com escala 1,05; no primário a borda de foco é cinza 600, para continuar visível sobre o branco.

**Badge de status (fontes)** — OK: preenchido em branco com texto preto. Demais estados (FALHOU, DESATUALIZADA, PENDENTE): só contorno cinza 400 com texto cinza 200. Falha mostra "! FALHOU".

**Marcador de erro (`ErrorMark`)** — círculo de 56 dp com contorno branco de 3 dp e "!" branco. Erro nunca usa vermelho.

**Campos de texto** — contorno cinza 600, branco no foco (3 dp na TV), texto branco, placeholder cinza 400.

**Interruptor (mobile)** — ligado: trilho branco e botão preto; desligado: trilho cinza 800 e botão cinza 400. Na TV, ativar e desativar é um botão de texto ("ATIVA · DESATIVAR").

**Overlay do player (TV)** — fundo preto a 70%, texto branco bold, aparece ao trocar de canal ou pedir informação e some após 3 s. Em "indisponível" e "carregando" o texto fica fixo.

**Player (mobile)** — `PlayerView` com `surface_type="surface_view"` e layout de controles próprio (`mono_player_control_view.xml`), em preto e branco, com botões de canal anterior e próximo.

**Logo (`ChannelLogo`)** — quadrado 1:1. Com `tvg-logo`, a imagem (Coil) fica sobre um quadro branco com 6 dp de margem, porque a maioria dos logos é desenhada para fundo claro e o branco continua dentro da paleta. Sem URL, carregando ou em erro: quadro cinza 600 com as iniciais.

## Diferenças em relação à especificação

Itens que o código ainda não atende; registrados em `BLOCKERS.md`.

- **Logos:** implementados com Coil, mas ainda não vistos em tela; o quadro branco foi uma escolha minha e pode ficar forte demais em cima do cinza 800.
- **Ícones:** a especificação pede Material Symbols outlined. O código usa dois vetores próprios (anterior/próximo), os ícones padrão do Media3 e os caracteres ★ ☆. Não verificado se a Inter tem esses glifos.
- **Peso do `bodyLarge`:** a especificação diz "Bold 600"; usei SemiBold (600).
- **Contraste:** medido por cálculo, não em tela.
