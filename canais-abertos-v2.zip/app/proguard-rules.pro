# Room, OkHttp e Media3 trazem consumer rules próprias.
# Mantém nomes das entidades para facilitar leitura de stack traces.
-keep class com.canaisabertos.data.model.** { *; }
