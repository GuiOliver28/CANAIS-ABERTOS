package com.canaisabertos

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.canaisabertos.ui.common.AppTheme
import com.canaisabertos.ui.common.DeviceMode
import com.canaisabertos.ui.mobile.MobileRoot
import com.canaisabertos.ui.tv.TvRoot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // O app é sempre escuro: ícones claros nas barras mesmo com o sistema em tema claro.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
        )

        val isTv = DeviceMode.isTv(this)
        if (isTv) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

        setContent {
            AppTheme(isTv = isTv) {
                if (isTv) TvRoot() else MobileRoot()
            }
        }
    }
}
