package com.canaisabertos

import android.app.Application
import com.canaisabertos.data.AppGraph
import com.canaisabertos.data.GraphProvider

class CanaisApp : Application(), GraphProvider {
    override val graph: AppGraph by lazy { AppGraph(this) }

    override fun onCreate() {
        super.onCreate()
        graph.bootstrap()
    }
}
