# Canais Abertos

Player de TV ao vivo focado em canais abertos brasileiros. Um único APK para **Fire TV**, **Android TV** e **smartphones/tablets Android**, sem Google Play Services, sem login, sem anúncios e sem telemetria.

> ## ⚠️ Estado do projeto: escrito, NÃO compilado
> Todo o código (etapas 1 a 6) foi escrito sem acesso a Android SDK nem a Maven/Gradle. **Nenhum build rodou e nenhum dos 42 testes foi executado.** Não existe APK pronto. Espere erros de compilação no primeiro build, principalmente em APIs do Compose para TV e do Media3 (veja `BLOCKERS.md`, item B2). Detalhes em `FINAL_REPORT.md`.
>
> Para gerar o APK: siga o `BUILD_PASSO_A_PASSO.md` (GitHub Actions, sem ferramenta local) ou compile numa máquina com Android SDK.

## O que o app faz

- Abre direto na lista de canais ao vivo (sem VOD, sem menu inicial).
- **Não traz lista de canais embutida.** Gerencia fontes M3U: adicionar (com validação e teste de download), ativar/desativar, atualizar uma ou todas, remover as personalizadas. Mostra último download, nº de canais e status (OK, falhou, desatualizada após 7 dias).
- Fontes padrão (ativadas por padrão, só podem ser desativadas): IPTV-org Brasil e IPTV-com Brasil. Veja `sources.json`.
- Une canais de várias fontes e remove duplicatas por `tvg-id` ou nome normalizado.
- Favoritos, busca por nome (sem acento), filtro de favoritos.
- Player Media3 (HLS): se o canal não começar em 5 s, mostra "indisponível" e sugere o próximo.
- Logos dos canais (Coil) com fallback para as iniciais.
- Visual monocromático (preto, branco, cinza) com Inter bold. Veja `DESIGN.md`.

O app só consome listas e URLs que **você** configurar. Use apenas fontes públicas e legítimas. O projeto não inclui links de retransmissão não autorizada e não contorna DRM.

## Estrutura

```
app/          MainActivity, manifest, assinatura, ABIs
ui-common/    cores, tipografia Inter, tema, DeviceMode, componentes comuns
ui-tv/        interface Compose for TV (D-pad)
ui-mobile/    interface Compose Material3 (toque, tablet em 2 colunas)
core-data/    Room, parser M3U, downloader OkHttp, repositórios, ViewModels
core-player/  wrapper Media3 (ExoPlayer)
```

`MainActivity` detecta TV (leanback, `amazon.hardware.fire_tv` ou UI mode TV) e escolhe `TvRoot()` ou `MobileRoot()`.

## Compilar

Requisitos: JDK 17+ e Android SDK com a plataforma 35 (`ANDROID_HOME` ou `local.properties` com `sdk.dir`).

```bash
./gradlew :core-data:testDebugUnitTest :core-player:testDebugUnitTest   # testes JVM
./gradlew assembleDebug                                                 # APKs debug
./gradlew assembleRelease                                               # APKs release
```

APKs em `app/build/outputs/apk/<debug|release>/`: um universal (`app-universal-*.apk`) e um por ABI (`app-arm64-v8a-*`, `app-armeabi-v7a-*`, `app-x86_64-*`). Em dúvida, use o universal.

### Sem máquina local: GitHub Actions

Suba o projeto para um repositório no GitHub. O workflow `.github/workflows/android-build.yml` roda os testes, compila o debug e publica o APK como artifact (aba **Actions** → execução → **Artifacts**). Ele nunca foi executado; se falhar, o log mostra o erro de compilação.

### Assinatura do release

Sem `keystore.properties`, o `assembleRelease` assina com a chave **debug** (serve para teste, não para distribuição). Para assinar com a sua chave:

```bash
keytool -genkeypair -v -keystore keystore/release.jks -alias canaisabertos \
  -keyalg RSA -keysize 2048 -validity 10000
```

Crie `keystore.properties` na raiz:

```
storeFile=keystore/release.jks
storePassword=...
keyAlias=canaisabertos
keyPassword=...
```

`keystore/`, `*.jks` e `keystore.properties` estão no `.gitignore`. **Faça backup da sua chave**: sem ela não dá para publicar atualizações do mesmo app.

## Instalar no Fire TV / Fire Stick (sideload via adb)

1. No Fire TV: **Configurações → Meu Fire TV → Sobre** (clique 7 vezes em "Fire TV Stick" para liberar **Opções do desenvolvedor**).
2. Em **Opções do desenvolvedor**, ative **Depuração ADB** e **Apps de fontes desconhecidas**.
3. Descubra o IP em **Configurações → Meu Fire TV → Sobre → Rede**.
4. No computador (com `adb` instalado, na mesma rede):

```bash
adb connect 192.168.0.50:5555        # use o IP do seu Fire TV
adb install -r app-universal-release.apk
```

5. Confirme o pedido de autorização de depuração na TV, se aparecer. O app fica em **Seus apps e canais** (use "Ver tudo").

Para desinstalar: `adb uninstall com.canaisabertos`.

## Instalar no celular ou tablet

**Direto no aparelho:** copie o APK universal (ou o da sua ABI), abra pelo gerenciador de arquivos e, quando o Android pedir, permita "instalar apps desconhecidos" para esse app de arquivos.

**Via adb (USB):** ative a depuração USB e rode `adb install -r app-universal-release.apk`.

Requer Android 5.1 (API 22) ou mais novo.

## Controles

| Plataforma | Ação |
|---|---|
| TV | Cima/Baixo/Esq/Dir navegam; **OK** abre o canal; **segurar OK** favorita |
| TV (no player) | Cima/Baixo ou Canal+/−, Mídia Próximo/Anterior: trocam de canal; Menu, Info ou OK: mostram o overlay (some em 3 s); Play/Pause pausa; **Voltar** sai |
| Celular | Toque abre o canal; estrela favorita; puxar a lista atualiza; **Voltar** fecha o player |

## Privacidade

Sem GMS, Firebase, Crashlytics, anúncios ou telemetria. A única rede é baixar as listas M3U que você configurou e reproduzir os streams. O manifest permite tráfego HTTP sem TLS (`usesCleartextTraffic`), porque muitas listas e streams IPTV usam `http://`.

## Licença

MIT (veja `LICENSE`). Componentes de terceiros, incluindo a fonte Inter (SIL OFL), estão em `THIRD_PARTY_NOTICES.md`.
