# Passo a passo: compilar sem ferramenta local (GitHub Actions)

O projeto nunca foi compilado. O caminho mais curto é deixar o GitHub compilar: o workflow `.github/workflows/android-build.yml` roda sozinho a cada `push`, executa os testes e publica o APK.

## 1. Criar o repositório

No GitHub: **New repository** → nome `canais-abertos` → **sem** README, sem .gitignore, sem licença (o projeto já tem) → **Create repository**. Pode ser privado: o Actions funciona igual.

## 2. Enviar o projeto

### Caminho A (recomendado): terminal com git

Serve qualquer computador com git, ou o **Codespaces** do GitHub (abre um terminal no navegador). Troque `SEU_USUARIO`:

```bash
unzip canais-abertos-fonte.zip
cd canais-abertos
git remote add origin https://github.com/SEU_USUARIO/canais-abertos.git
git branch -M main
git push -u origin main
```

O `.git` já vem no zip, com o histórico. O push pede o seu login do GitHub (use um *personal access token* no lugar da senha, se pedir).

Dica: no Codespaces, para subir o zip, arraste-o para a árvore de arquivos do editor.

### Caminho B: só pelo navegador

Descompacte o zip, abra o repositório vazio no GitHub, **uploading an existing file** e arraste as pastas e arquivos. O navegador aceita cerca de 100 arquivos por envio, e o projeto tem mais que isso; envie em lotes. Não envie as pastas `.git` e `keystore`. **Tem que subir também a pasta oculta `.github`**, porque é onde está o workflow (alguns gerenciadores de arquivos escondem pastas com ponto).

## 3. Ver o build rodar

Abra a aba **Actions** do repositório. A execução "Android build" começa sozinha depois do push (leva alguns minutos; a primeira baixa muita coisa). Para rodar de novo sem novo commit: **Actions → Android build → Run workflow**.

## 4. Se ficar verde

1. Abra a execução e, no fim da página, em **Artifacts**, baixe `canais-abertos-debug-apk`.
2. Descompacte. Dentro estão `app-universal-debug.apk` (use este) e um APK por ABI.
3. Instale: celular, copie o APK e abra; Fire TV, `adb install -r app-universal-debug.apk` (detalhes no `README.md`).
4. Percorra o `TESTING.md`.

O APK debug é assinado com a chave de debug do Android: serve para instalar e testar, não para publicar.

## 5. Se ficar vermelho (o mais provável na primeira vez)

Isso é esperado: o código foi escrito sem compilador. Para me mandar o erro:

1. Abra a execução vermelha → o job **build** → o passo **Testes e assembleDebug**.
2. Procure as linhas que começam com `e: ` (erro do Kotlin) ou `error:` / `FAILED` / `* What went wrong`.
3. Copie essas linhas, mais ou menos as últimas 40, e cole aqui na conversa.

Ou, no terminal do Codespaces ou numa máquina com a CLI `gh`:

```bash
gh run list --limit 1
gh run view --log-failed | tail -60
```

Cole a saída aqui. Eu corrijo e mando o zip atualizado; substitua os arquivos alterados no seu repositório e faça outro `git push` (o Actions roda de novo sozinho).

Se o vermelho for no passo **Android SDK** ou **Instalar plataforma e build-tools**, o problema é o próprio workflow (versão de uma action ou nome do pacote do SDK); cole o log desse passo também.

## 6. Depois do primeiro verde

1. Commite a pasta `core-data/schemas/` que o Room gera no primeiro build (se não aparecer no repositório, rode o build local uma vez e a adicione).
2. Para um APK de release assinado, gere a sua chave (README, seção "Assinatura do release"). O workflow atual só gera o debug; assinar o release no GitHub exige guardar a chave como *secret*, e eu posso montar isso depois do primeiro build verde.
3. Confirme a URL da fonte iptv-com (`BLOCKERS.md`, B6).
