# TESTING

> **Status geral: NADA FOI EXECUTADO.** Nenhum build, nenhum teste unitário e nenhum teste em aparelho. Toda caixa abaixo está desmarcada de propósito. Marque conforme for validando e anote a data, o aparelho e a versão do sistema.

Legenda: `[ ]` não executado · `[x]` passou · `[!]` falhou (descreva em BLOCKERS.md)

## 0. Pré-requisito: build

- [ ] `./gradlew :core-data:testDebugUnitTest :core-player:testDebugUnitTest` verde
- [ ] `./gradlew assembleDebug` verde
- [ ] `./gradlew assembleRelease` verde (APK universal + 3 por ABI)
- [ ] O workflow `android-build.yml` roda no GitHub e publica o APK

## 1. Testes unitários JVM (42 testes escritos, 0 executados)

| Arquivo | Testes | Cobre | Executado |
|---|---|---|---|
| `M3uParserTest` | 8 | EXTINF, atributos, BOM/CRLF, vírgula em aspas, EXTVLCOPT, EXTGRP, http(s) apenas, lixo/HTML | [ ] |
| `ChannelMergerTest` | 5 | normalização, dedupe por tvg-id e por nome, prioridade da fonte | [ ] |
| `M3uDownloaderTest` | 5 | retry em 5xx, sem retry em 404, limite de tentativas, corpo não M3U, URL inválida | [ ] |
| `DefaultSourcesTest` | 2 | `sources.json`, status e frescor (7 dias) | [ ] |
| `SourceRepositoryTest` | 12 | seed idempotente, adicionar (valida e testa antes de salvar), duplicata, remoção, falha de refresh, estado "atualizando" volta a falso, só fontes ativas, fusão | [ ] |
| `ChannelFilterTest` | 6 | busca sem acento, favoritos no topo, filtro de favoritos, toggle | [ ] |
| `ChannelNavigatorTest` | 4 | próximo/anterior circular, lista vazia | [ ] |

Não há testes de UI, de Room real (DAOs são fakes) nem de `PlayerController` (precisa de aparelho).

## 2. Checklist por etapa

**Etapa 1 — esqueleto e tema**
- [ ] App abre em TV e em celular sem fechar
- [ ] TV abre em landscape fixo; celular acompanha o sistema
- [ ] Fundo preto absoluto na TV e preto suave no celular
- [ ] Fonte Inter carrega (não cai para a fonte do sistema)
- [ ] Ícone e banner aparecem (launcher normal e launcher da TV)

**Etapa 2 e 3 — parser, Room e lista**
- [ ] Primeira abertura grava as 2 fontes padrão e tenta baixar
- [ ] Lista mostra logo (iniciais), nome e "AO VIVO" com ponto pulsante
- [ ] Tablet mostra 2 colunas; celular, 1; TV, 4
- [ ] Logos carregam (quadro branco) e, sem URL ou em erro, aparecem as iniciais
- [ ] Primeira abertura mostra "CARREGANDO CANAIS…" (e não "NENHUM CANAL") até o primeiro download terminar

**Etapa 4 — gerenciador de fontes**
- [ ] Adicionar URL válida: testa, salva e mostra nº de canais
- [ ] URL inválida, duplicada ou que não é M3U: mensagem de erro e nada salvo
- [ ] Ativar/desativar muda a lista na hora
- [ ] Atualizar uma, atualizar todas; status e data mudam
- [ ] Fonte que falha: badge "! FALHOU", canais antigos continuam
- [ ] Fonte com mais de 7 dias: badge "DESATUALIZADA"
- [ ] Fonte padrão não tem botão remover; personalizada tem
- [ ] **A URL do iptv-com é real?** Se não for, aparece "falhou" (veja BLOCKERS.md)
- [ ] Sem fonte ativa: tela "NENHUM CANAL" com botão "GERENCIAR FONTES"

**Etapa 5 — player**
- [ ] Abrir canal HLS que funciona
- [ ] Canal fora do ar: em até ~5 s mostra "CANAL INDISPONÍVEL" e sugere o próximo
- [ ] Trocar de canal (próximo/anterior) nas duas plataformas, com volta circular
- [ ] Voltar sai do player e retorna à lista
- [ ] App em segundo plano e volta: o canal retoma
- [ ] Mobile: vira landscape no player e volta ao sair; barras do sistema somem
- [ ] Mobile: controles pretos e brancos aparecem ao tocar; botões de canal funcionam
- [ ] TV: overlay aparece ao trocar de canal e some em 3 s
- [ ] Stream com `http://` e redirecionamento http→https toca
- [ ] Tela não apaga durante a reprodução

**Etapa 6 — favoritos, busca e polimento**
- [ ] Favoritar (toque na estrela / segurar OK) e desfavoritar
- [ ] Favoritos ficam no topo; filtro "FAVORITOS" mostra só eles
- [ ] Favorito continua após atualizar a lista e reabrir o app
- [ ] Busca ignora acento e maiúsculas ("camara" acha "TV Câmara")
- [ ] Mensagens "SEM FAVORITOS" e "NADA ENCONTRADO"
- [ ] Mobile: puxar para atualizar; TV: botão ATUALIZAR
- [ ] Ao tocar em um canal com filtro ativo, próximo/anterior percorre só a lista filtrada

## 3. Checklist por plataforma

Em cada aparelho, rode as seções 2 (etapas 1 a 6) e os itens específicos abaixo.

**Fire TV Stick 4K — Fire OS 7** · [ ] não testado
- [ ] Instala por `adb install` e aparece em "Seus apps e canais"
- [ ] Foco branco 3 dp + escala 1,05 visível em todos os cards e botões
- [ ] Teclado virtual abre no campo de busca e no de URL
- [ ] Controle remoto: Voltar, Menu, Play/Pause, avançar/retroceder mídia
- [ ] Desempenho aceitável com a lista grande (minSdk 22 + Compose pesa em Stick antigo)

**Fire TV Stick 4K — Fire OS 8** · [ ] não testado
- [ ] Mesmos itens do Fire OS 7

**Android TV genérica** · [ ] não testado
- [ ] Aparece no launcher da TV (banner) e abre em modo TV
- [ ] D-pad cobre todas as telas sem foco "preso"
- [ ] Teclas Canal+/Canal− funcionam no player

**Smartphone Android 9** · [ ] não testado
**Smartphone Android 11** · [ ] não testado
**Smartphone Android 14** · [ ] não testado
- [ ] Tráfego `http://` funciona (cleartext)
- [ ] Rotação no player e na lista sem perder o canal
- [ ] Gesto de voltar fecha o player; na lista, sai do app
- [ ] Android 14: sem crash ao abrir (targetSdk 35)

**Tablet** · [ ] não testado
- [ ] Lista em 2 colunas e player em tela cheia
- [ ] Modo janela dividida não quebra o layout

## 4. Verificações transversais

- [ ] Ícones da barra de status e de navegação ficam claros também com o celular em tema claro
- [ ] `assembleRelease` gera `app-universal-release.apk` e os 3 por ABI (sem erro de `abiFilters`)
- [ ] Nenhuma dependência de Google Play Services (`./gradlew :app:dependencies | grep -i gms` vazio)
- [ ] Nenhuma permissão além de INTERNET e ACCESS_NETWORK_STATE (`aapt dump permissions`)
- [ ] APK release assina e instala; confira o tamanho e se o R8 não quebrou o Room
- [ ] Contraste AA do texto sobre os fundos (calculado em `DESIGN.md`; falta conferir em tela)
- [ ] Texto das estrelas (★ ☆) renderiza com a fonte Inter ou cai em fonte do sistema
