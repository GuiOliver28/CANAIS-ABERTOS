package com.canaisabertos

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.SideEffect
import com.canaisabertos.ui.common.AppTheme
import com.canaisabertos.ui.common.DeviceMode
import com.canaisabertos.ui.common.ThemeState
import com.canaisabertos.ui.mobile.MobileRoot
import com.canaisabertos.ui.tv.TvRoot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeState.init(this)

        val isTv = DeviceMode.isTv(this)
        if (isTv) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

        setContent {
            // Ícones das barras acompanham o tema (claros no escuro, escuros no claro).
            val light = ThemeState.effectiveLight
            SideEffect {
                val style = if (light) SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                else SystemBarStyle.dark(Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }
            AppTheme(isTv = isTv) {
                if (isTv) TvRoot() else MobileRoot()
            }
        }
    }
}
