package com.canaisabertos.ui.common

import androidx.compose.ui.graphics.Color

/**
 * Paleta monocromática. Sem cores de acento: hierarquia vem de peso, tamanho e contraste.
 * Os nomes são papéis, não cores literais: no tema claro Black/White trocam de lado
 * (Black = fundo, White = texto/destaque) e os cinzas são espelhados.
 */
object Mono {
    private val light: Boolean get() = ThemeState.effectiveLight

    val Black: Color get() = if (light) Color(0xFFFFFFFF) else Color(0xFF000000)     // fundo TV e player
    val BlackSoft: Color get() = if (light) Color(0xFFFAFAFA) else Color(0xFF0A0A0A) // fundo mobile
    val Gray900: Color get() = if (light) Color(0xFFF2F2F2) else Color(0xFF121212)   // surface
    val Gray800: Color get() = if (light) Color(0xFFE8E8E8) else Color(0xFF1E1E1E)   // cards
    val Gray600: Color get() = if (light) Color(0xFFC4C4C4) else Color(0xFF3A3A3A)   // divisor, contorno
    val Gray400: Color get() = if (light) Color(0xFF666666) else Color(0xFF888888)   // texto secundário
    val Gray200: Color get() = if (light) Color(0xFF2E2E2E) else Color(0xFFD0D0D0)   // texto em cards
    val White: Color get() = if (light) Color(0xFF000000) else Color(0xFFFFFFFF)     // texto primário, foco
}
