package com.canaisabertos.ui.common

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Tema escuro (padrão) ou claro, salvo em SharedPreferences (sem dependência nova).
 * [Mono] lê daqui: qualquer tela que use `Mono.*` recompõe sozinha quando o tema muda.
 * O player (mobile e TV) fica sempre escuro: [playerOpen] força o visual escuro enquanto ele está aberto.
 */
object ThemeState {
    private const val PREFS = "canais_prefs"
    private const val KEY_LIGHT = "light_theme"

    var isLight by mutableStateOf(false)
        private set

    /** Marcado pelas raízes (MobileRoot/TvRoot) enquanto há um canal em reprodução. */
    var playerOpen by mutableStateOf(false)

    /** O que as cores e as barras do sistema realmente usam agora. */
    val effectiveLight: Boolean get() = isLight && !playerOpen

    fun init(context: Context) {
        isLight = context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_LIGHT, false)
    }

    fun toggle(context: Context) {
        isLight = !isLight
        context.applicationContext
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_LIGHT, isLight).apply()
    }
}
