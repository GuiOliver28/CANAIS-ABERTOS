package com.canaisabertos.ui.tv

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.canaisabertos.cast.CastProtocol
import com.canaisabertos.cast.CastReceiver
import com.canaisabertos.player.PlayerViewModel
import com.canaisabertos.ui.common.Mono
import com.canaisabertos.ui.common.Screen
import com.canaisabertos.ui.common.ThemeState

@Composable
fun TvRoot() {
    var screen by rememberSaveable { mutableStateOf(Screen.LIST) }
    val player: PlayerViewModel = viewModel(factory = PlayerViewModel.Factory)
    val playerState by player.state.collectAsState()

    SideEffect { ThemeState.playerOpen = playerState.channel != null } // player sempre escuro

    // Recebe canais enviados pelo celular (mesma rede). Só enquanto o app está visível.
    val context = LocalContext.current
    val castReceiver = remember { CastReceiver(context) { req -> player.start(listOf(req.toChannel()), 0) } }
    val castInfo = remember { CastProtocol.localIpv4()?.let { "Cast: $it" } }
    DisposableEffect(castReceiver) { onDispose { castReceiver.stop() } }

    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { castReceiver.stop(); player.onAppStopped() }
    LifecycleEventEffect(Lifecycle.Event.ON_START) { castReceiver.start(); player.onAppStarted() }

    Box(Modifier.fillMaxSize().background(Mono.Black)) {
        when {
            playerState.channel != null -> TvPlayerScreen(player)
            screen == Screen.SOURCES -> TvSourcesScreen(onBack = { screen = Screen.LIST })
            else -> TvListScreen(
                onOpenSources = { screen = Screen.SOURCES },
                onPlay = { list, index ->
                    ThemeState.playerOpen = true
                    player.start(list, index)
                },
                castInfo = castInfo,
            )
        }
    }
}
