package com.canaisabertos.cast

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class CastHttpTest {
    private fun http(method: String, path: String, body: String): java.io.InputStream {
        val bytes = body.toByteArray()
        val head = "$method $path HTTP/1.1\r\nHost: x\r\nContent-Length: ${bytes.size}\r\n\r\n"
        return (head.toByteArray() + bytes).inputStream()
    }

    @Test fun roundTrip() {
        val req = CastRequest("Globo HD", "https://exemplo.com/a b.m3u8?x=1&y=2", "UA/1", null)
        val parsed = CastHttp.parsePlay(http("POST", "/play", CastHttp.encode(req)))
        assertEquals(req, parsed)
    }

    @Test fun rejectsOtherMethodPathAndSchemes() {
        assertNull(CastHttp.parsePlay(http("GET", "/play", "url=http://a")))
        assertNull(CastHttp.parsePlay(http("POST", "/x", "url=http://a")))
        assertNull(CastHttp.parsePlay(http("POST", "/play", "url=file:///etc/passwd")))
        assertNull(CastHttp.parsePlay(http("POST", "/play", "name=a")))
    }

    @Test fun defaultName() {
        assertEquals("Canal", CastHttp.parsePlay(http("POST", "/play", "url=http%3A%2F%2Fa"))?.name)
        assertNotNull(CastHttp.parsePlay(http("POST", "/play", "url=http%3A%2F%2Fa")))
    }
}
