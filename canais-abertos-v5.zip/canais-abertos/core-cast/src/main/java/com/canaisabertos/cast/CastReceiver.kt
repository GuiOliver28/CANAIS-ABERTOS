package com.canaisabertos.cast

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/**
 * Lado da TV. Enquanto estiver iniciado, aceita `POST /play` na rede local e chama [onPlay]
 * na main thread. Ligue em ON_START e desligue em ON_STOP (a TV só recebe com o app aberto).
 *
 * Três formas de ser achada: NSD/mDNS, resposta a broadcast UDP e IP digitado (porta fixa [CastProtocol.TCP_PORT]).
 * Mantém um MulticastLock: sem ele o Wi-Fi do Fire OS descarta pacotes multicast/broadcast e a TV fica invisível.
 * Só aceita URLs http/https; qualquer aparelho da mesma rede pode enviar (ver README).
 */
class CastReceiver(
    context: Context,
    private val onPlay: (CastRequest) -> Unit,
) {
    private val appContext = context.applicationContext
    private val nsd = appContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifi = appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    private val multicastLock = wifi?.createMulticastLock("canais-abertos-cast")?.apply { setReferenceCounted(false) }
    private val main = Handler(Looper.getMainLooper())
    private val deviceName = "Canais Abertos (${Build.MODEL.replace('|', ' ')})"

    private var server: ServerSocket? = null
    private var udp: DatagramSocket? = null
    private var registration: NsdManager.RegistrationListener? = null

    @Synchronized
    fun start() {
        if (server != null) return
        try { multicastLock?.acquire() } catch (_: Exception) {}

        val ss = openServer() ?: return
        server = ss
        thread(name = "cast-accept", isDaemon = true) {
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (_: Exception) { break }
                thread(name = "cast-client", isDaemon = true) { handle(s) }
            }
        }

        startUdpResponder(ss.localPort)

        val info = NsdServiceInfo().apply {
            serviceName = deviceName
            serviceType = CastProtocol.SERVICE_TYPE
            port = ss.localPort
        }
        val listener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) {}
            override fun onRegistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
            override fun onServiceUnregistered(info: NsdServiceInfo) {}
            override fun onUnregistrationFailed(info: NsdServiceInfo, errorCode: Int) {}
        }
        registration = listener
        try { nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, listener) } catch (_: Exception) {}
    }

    @Synchronized
    fun stop() {
        registration?.let { try { nsd.unregisterService(it) } catch (_: Exception) {} }
        registration = null
        try { udp?.close() } catch (_: Exception) {}
        udp = null
        try { server?.close() } catch (_: Exception) {}
        server = null
        try { if (multicastLock?.isHeld == true) multicastLock.release() } catch (_: Exception) {}
    }

    private fun openServer(): ServerSocket? {
        try {
            return ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(CastProtocol.TCP_PORT))
            }
        } catch (_: Exception) { /* porta ocupada: cai para uma livre */ }
        return try { ServerSocket(0) } catch (_: Exception) { null }
    }

    /** Responde "CANAIS_ABERTOS?" com "CANAIS_ABERTOS!|nome|porta" direto ao remetente. */
    private fun startUdpResponder(tcpPort: Int) {
        val sock = try {
            DatagramSocket(null as java.net.SocketAddress?).apply {
                reuseAddress = true
                broadcast = true
                bind(InetSocketAddress(CastProtocol.UDP_PORT))
            }
        } catch (_: Exception) { return }
        udp = sock
        thread(name = "cast-udp", isDaemon = true) {
            val buf = ByteArray(256)
            while (!sock.isClosed) {
                try {
                    val p = DatagramPacket(buf, buf.size)
                    sock.receive(p)
                    if (String(p.data, 0, p.length).trim() == CastProtocol.DISCOVER) {
                        val reply = "${CastProtocol.REPLY_PREFIX}|$deviceName|$tcpPort".toByteArray()
                        sock.send(DatagramPacket(reply, reply.size, p.socketAddress))
                    }
                } catch (_: Exception) {
                    if (sock.isClosed) break
                }
            }
        }
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            s.soTimeout = 5_000
            val request = try { CastHttp.parsePlay(s.getInputStream()) } catch (_: Exception) { null }
            val status = if (request != null) "200 OK" else "400 Bad Request"
            try {
                s.getOutputStream().apply {
                    write("HTTP/1.1 $status\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
                    flush()
                }
            } catch (_: Exception) {}
            if (request != null) main.post { onPlay(request) }
        }
    }
}
