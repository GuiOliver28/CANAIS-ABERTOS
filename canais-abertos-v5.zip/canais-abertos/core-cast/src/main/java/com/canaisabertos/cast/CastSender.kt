package com.canaisabertos.cast

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import com.canaisabertos.data.model.Channel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.withContext
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import java.net.URL
import kotlin.concurrent.thread

data class CastTarget(val name: String, val host: String, val port: Int)

/** Lado do celular: descobre TVs por NSD e envia o canal. Use start/stopDiscovery com o ciclo da tela. */
class CastSender(context: Context) {
    private val nsd = context.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val _targets = MutableStateFlow<List<CastTarget>>(emptyList())
    val targets: StateFlow<List<CastTarget>> = _targets.asStateFlow()

    private val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    private val multicastLock = wifi?.createMulticastLock("canais-abertos-cast")?.apply { setReferenceCounted(false) }
    private var udp: DatagramSocket? = null

    private var discovery: NsdManager.DiscoveryListener? = null
    private val pending = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    @Synchronized
    fun startDiscovery() {
        if (discovery != null) return
        // Sem o MulticastLock o Wi-Fi do Android/Fire OS descarta as respostas mDNS e broadcast.
        try { multicastLock?.acquire() } catch (_: Exception) {}
        startUdpDiscovery()
        val listener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onServiceFound(info: NsdServiceInfo) = enqueue(info)
            override fun onServiceLost(info: NsdServiceInfo) {
                _targets.update { list -> list.filterNot { it.name == info.serviceName } }
            }
        }
        discovery = listener
        try { nsd.discoverServices(CastProtocol.SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listener) } catch (_: Exception) { discovery = null }
    }

    @Synchronized
    fun stopDiscovery() {
        discovery?.let { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        discovery = null
        pending.clear()
        resolving = false
        try { udp?.close() } catch (_: Exception) {}
        udp = null
        try { if (multicastLock?.isHeld == true) multicastLock.release() } catch (_: Exception) {}
    }

    /** Alvo para um IP digitado à mão (a TV escuta na porta fixa [CastProtocol.TCP_PORT]). */
    fun manualTarget(host: String) = CastTarget("TV $host", host.trim(), CastProtocol.TCP_PORT)

    private fun addTarget(t: CastTarget) {
        _targets.update { list -> list.filterNot { it.host == t.host && it.port == t.port } + t }
    }

    // Broadcast "CANAIS_ABERTOS?" a cada 2 s; as TVs respondem "CANAIS_ABERTOS!|nome|porta".
    private fun startUdpDiscovery() {
        val sock = try {
            DatagramSocket().apply { broadcast = true; soTimeout = 800 }
        } catch (_: Exception) { return }
        udp = sock
        thread(name = "cast-udp-find", isDaemon = true) {
            val payload = CastProtocol.DISCOVER.toByteArray()
            val buf = ByteArray(512)
            var lastSend = 0L
            while (!sock.isClosed) {
                val now = System.currentTimeMillis()
                if (now - lastSend > 2_000) {
                    lastSend = now
                    for (addr in broadcastAddresses()) {
                        try { sock.send(DatagramPacket(payload, payload.size, addr, CastProtocol.UDP_PORT)) } catch (_: Exception) {}
                    }
                }
                try {
                    val p = DatagramPacket(buf, buf.size)
                    sock.receive(p)
                    val parts = String(p.data, 0, p.length).split('|')
                    val port = parts.getOrNull(2)?.trim()?.toIntOrNull()
                    val host = p.address?.hostAddress
                    if (parts.getOrNull(0) == CastProtocol.REPLY_PREFIX && port != null && host != null) {
                        addTarget(CastTarget(parts.getOrNull(1)?.ifBlank { null } ?: "TV $host", host, port))
                    }
                } catch (_: SocketTimeoutException) {
                } catch (_: Exception) {
                    if (sock.isClosed) break
                }
            }
        }
    }

    private fun broadcastAddresses(): List<InetAddress> {
        val out = mutableListOf<InetAddress>()
        try {
            out += InetAddress.getByName("255.255.255.255")
            NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
                .filter { it.isUp && !it.isLoopback }
                .forEach { ni -> ni.interfaceAddresses.forEach { ia -> ia.broadcast?.let { out += it } } }
        } catch (_: Exception) {}
        return out.distinct()
    }

    // NsdManager só resolve um serviço por vez; serializa.
    @Synchronized
    private fun enqueue(info: NsdServiceInfo) {
        pending.addLast(info)
        resolveNext()
    }

    @Synchronized
    private fun resolveNext() {
        if (resolving) return
        val next = pending.removeFirstOrNull() ?: return
        resolving = true
        val done = {
            synchronized(this) { resolving = false; resolveNext() }
        }
        try {
            @Suppress("DEPRECATION")
            nsd.resolveService(next, object : NsdManager.ResolveListener {
                override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) = done()
                override fun onServiceResolved(info: NsdServiceInfo) {
                    @Suppress("DEPRECATION")
                    val host = info.host?.hostAddress
                    if (host != null) addTarget(CastTarget(info.serviceName, host, info.port))
                    done()
                }
            })
        } catch (_: Exception) {
            resolving = false
        }
    }

    /** Envia o canal para a TV. Retorna true se a TV confirmou (HTTP 200). */
    suspend fun send(target: CastTarget, channel: Channel): Boolean = withContext(Dispatchers.IO) {
        val body = CastHttp.encode(
            CastRequest(channel.name, channel.streamUrl, channel.userAgent, channel.referrer),
        ).toByteArray()
        val host = if (target.host.contains(':')) "[${target.host}]" else target.host
        var conn: HttpURLConnection? = null
        try {
            conn = (URL("http://$host:${target.port}${CastProtocol.PATH_PLAY}").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 4_000
                readTimeout = 4_000
                doOutput = true
                setFixedLengthStreamingMode(body.size)
                setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            }
            conn.outputStream.use { it.write(body) }
            conn.responseCode == 200
        } catch (_: Exception) {
            false
        } finally {
            conn?.disconnect()
        }
    }
}
