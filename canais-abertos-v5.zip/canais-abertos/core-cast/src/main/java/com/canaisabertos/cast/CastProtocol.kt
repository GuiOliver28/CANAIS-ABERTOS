package com.canaisabertos.cast

import com.canaisabertos.data.model.Channel
import java.io.InputStream
import java.net.URLDecoder
import java.net.URLEncoder

/**
 * "Cast" próprio, sem Google Play Services (a Fire TV não é alvo do Google Cast):
 * a TV abre um servidor HTTP mínimo na rede local e se anuncia por NSD (mDNS); o celular descobre
 * as TVs e envia `POST /play` com `name`, `url` (+ `ua`, `ref`) em application/x-www-form-urlencoded.
 * A TV toca o stream por conta própria; o celular só manda o endereço.
 */
object CastProtocol {
    const val SERVICE_TYPE = "_canaisabertos._tcp"
    const val PATH_PLAY = "/play"
    const val MAX_BODY = 8 * 1024

    /** Porta TCP preferida (permite digitar só o IP); se ocupada, a TV usa uma livre e anuncia. */
    const val TCP_PORT = 8765

    /** Descoberta por broadcast UDP: fallback para redes/aparelhos em que o mDNS (NSD) falha. */
    const val UDP_PORT = 8766
    const val DISCOVER = "CANAIS_ABERTOS?"
    const val REPLY_PREFIX = "CANAIS_ABERTOS!"

    /** Primeiro IPv4 local não-loopback (para a TV mostrar na tela). */
    fun localIpv4(): String? = try {
        java.net.NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { it is java.net.Inet4Address && !it.isLoopbackAddress }
            ?.hostAddress
    } catch (_: Exception) { null }
}

data class CastRequest(
    val name: String,
    val url: String,
    val userAgent: String? = null,
    val referrer: String? = null,
) {
    /** Canal avulso (não pertence a nenhuma fonte) para o player da TV. */
    fun toChannel() = Channel(
        sourceId = "cast",
        tvgId = null,
        name = name,
        normalizedName = name.lowercase(),
        dedupeKey = "cast:$url",
        logoUrl = null,
        groupTitle = null,
        streamUrl = url,
        userAgent = userAgent,
        referrer = referrer,
    )
}

/** Parsing HTTP mínimo e puro (testável na JVM). */
internal object CastHttp {
    /** Retorna o pedido de reprodução, ou null se não for um `POST /play` válido (http/https). */
    fun parsePlay(input: InputStream): CastRequest? {
        val head = readHead(input) ?: return null
        val lines = head.split("\r\n")
        val requestLine = lines.firstOrNull()?.split(" ") ?: return null
        if (requestLine.size < 2 || requestLine[0] != "POST" || requestLine[1] != CastProtocol.PATH_PLAY) return null
        val length = lines.drop(1)
            .firstOrNull { it.startsWith("content-length:", ignoreCase = true) }
            ?.substringAfter(':')?.trim()?.toIntOrNull() ?: return null
        if (length !in 1..CastProtocol.MAX_BODY) return null
        val body = ByteArray(length)
        var read = 0
        while (read < length) {
            val n = input.read(body, read, length - read)
            if (n < 0) return null
            read += n
        }
        val fields = String(body, Charsets.UTF_8).split('&').mapNotNull {
            val i = it.indexOf('=')
            if (i <= 0) null else URLDecoder.decode(it.substring(0, i), "UTF-8") to URLDecoder.decode(it.substring(i + 1), "UTF-8")
        }.toMap()
        val url = fields["url"]?.trim().orEmpty()
        if (!(url.startsWith("http://", true) || url.startsWith("https://", true))) return null
        return CastRequest(
            name = fields["name"]?.takeIf { it.isNotBlank() } ?: "Canal",
            url = url,
            userAgent = fields["ua"]?.takeIf { it.isNotBlank() },
            referrer = fields["ref"]?.takeIf { it.isNotBlank() },
        )
    }

    fun encode(request: CastRequest): String = buildList {
        add("name" to request.name)
        add("url" to request.url)
        request.userAgent?.let { add("ua" to it) }
        request.referrer?.let { add("ref" to it) }
    }.joinToString("&") { (k, v) -> "$k=${URLEncoder.encode(v, "UTF-8")}" }

    /** Lê até a linha em branco que fecha o cabeçalho (limite de 8 KB). */
    private fun readHead(input: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < CastProtocol.MAX_BODY) {
            val b = input.read()
            if (b < 0) return null
            sb.append(b.toChar())
            if (sb.endsWith("\r\n\r\n")) return sb.toString()
        }
        return null
    }
}
