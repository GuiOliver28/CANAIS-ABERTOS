pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "CanaisAbertos"
include(":app", ":ui-common", ":ui-tv", ":ui-mobile", ":core-data", ":core-player", ":core-cast")
