// Gera dist/webos: bundle clássico (sem módulos ES), JS rebaixado para ES2017, tudo embutido.
// Motivo: app empacotado roda em file://, onde <script type="module"> e fetch('sources.json') são bloqueados,
// e o webOS 5 (Chromium 68) não entende ?. ?? ??=.
import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const ts = require('typescript');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const out = path.join(root, 'dist', 'webos');
const read = (p) => fs.readFileSync(path.join(root, p), 'utf8');

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(path.join(out, 'css'), { recursive: true });

// 1) módulos -> CommonJS ES2017 -> um único arquivo com mini-loader
const files = ['m3u', 'store', 'sources', 'nav', 'player', 'app'];
let bundle = '(function(){\n"use strict";\nvar defs={},cache={};\n' +
  'function req(n){n=n.replace(/^\\.\\//,"").replace(/\\.js$/,"");if(cache[n])return cache[n].exports;' +
  'var m=cache[n]={exports:{}};defs[n](m,m.exports,req);return m.exports;}\n';
for (const f of files) {
  const js = ts.transpileModule(read(`js/${f}.js`), {
    compilerOptions: { target: ts.ScriptTarget.ES2017, module: ts.ModuleKind.CommonJS, allowJs: true },
  }).outputText;
  bundle += `defs[${JSON.stringify(f)}]=function(module,exports,require){\n${js}\n};\n`;
}
bundle += 'req("app");\n})();\n';
const defaults = JSON.stringify(JSON.parse(read('sources.json')));
fs.writeFileSync(path.join(out, 'app.js'), `window.__DEFAULT_SOURCES__=${defaults};\n${bundle}`);

// 2) HTML (script clássico, no fim do body) + CSS + fontes
const html = read('index.html')
  .replace(/\s*<!-- Opcional[\s\S]*?-->\s*<!-- <script[^>]*><\/script> -->/, '')
  .replace('<script type="module" src="js/app.js"></script>', '<script src="vendor/hls.min.js" onerror="void 0"></script>\n  <script src="app.js"></script>');
fs.writeFileSync(path.join(out, 'index.html'), html);
fs.copyFileSync(path.join(root, 'css/app.css'), path.join(out, 'css/app.css'));
fs.cpSync(path.join(root, 'fonts'), path.join(out, 'fonts'), { recursive: true });
if (fs.existsSync(path.join(root, 'vendor'))) fs.cpSync(path.join(root, 'vendor'), path.join(out, 'vendor'), { recursive: true });

// 3) metadados e ícones do webOS
for (const f of fs.readdirSync(path.join(root, 'platform/webos'))) {
  fs.copyFileSync(path.join(root, 'platform/webos', f), path.join(out, f));
}
console.log('ok ->', out, fs.readdirSync(out).join(' '));
