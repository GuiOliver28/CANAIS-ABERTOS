import assert from 'node:assert/strict';
import { parseM3u, normalize, toChannel, mergeChannels, filterChannels } from '../js/m3u.js';

const txt = '﻿#EXTM3U\r\n#EXTINF:-1 tvg-id="Globo.br" tvg-logo="http://x/l.png" group-title="Abertos, TV",Globo HD (720p)\r\n#EXTVLCOPT:http-user-agent=UA/1\r\nhttps://a/b.m3u8\r\n\r\n#EXTINF:-1,Sem URL valida\r\nrtmp://x\r\n#EXTINF:-1 tvg-name="Band",\r\nhttp://c/d.m3u8\r\n';
const r = parseM3u(txt);
assert.equal(r.length, 2);
assert.equal(r[0].name, 'Globo HD (720p)');
assert.equal(r[0].groupTitle, 'Abertos, TV');
assert.equal(r[0].userAgent, 'UA/1');
assert.equal(r[1].name, 'Band');
assert.equal(normalize('TV Brasil HD (720p) [Geo-blocked]'), 'tv brasil');
assert.equal(normalize('São Paulo'), 'sao paulo');
const a = r.map((p) => toChannel(p, 's1'));
assert.equal(a[0].dedupeKey, 'id:globo.br');
assert.equal(mergeChannels([a, a]).length, 2);
const fav = new Set(['name:band']);
assert.equal(filterChannels(a, '', fav, false)[0].name, 'Band');
assert.equal(filterChannels(a, 'GLOBO', new Set(), false).length, 1);
console.log('ok');
