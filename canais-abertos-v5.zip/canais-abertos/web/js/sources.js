import { parseM3u, toChannel, mergeChannels } from './m3u.js';
import { store } from './store.js';

const FRESH_MS = 7 * 24 * 3600 * 1000; // mesmo frescor de 7 dias do app Android

function withTimeout(promise, ms) {
  return Promise.race([promise, new Promise((_, rej) => setTimeout(() => rej(new Error('tempo esgotado')), ms))]);
}

export class SourceManager {
  constructor(defaults) {
    this.defaults = defaults;
    this.sources = store.getSources(defaults);
  }
  save() { store.saveSources(this.sources); }

  async fetchOne(source, { force = false } = {}) {
    const cached = store.getCache(source.id);
    if (!force && cached && Date.now() - cached.at < FRESH_MS) return cached.channels;
    try {
      const res = await withTimeout(fetch(source.url), 20000);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const channels = parseM3u(await res.text()).map((p) => toChannel(p, source.id));
      if (!channels.length) throw new Error('lista sem canais');
      store.saveCache(source.id, channels);
      return channels;
    } catch (e) {
      if (cached) return cached.channels; // offline/falha: usa o cache velho
      throw e;
    }
  }

  /** Canais fundidos das fontes ativas; fontes que falham não derrubam as outras. */
  async loadActive({ force = false } = {}) {
    const active = this.sources.filter((s) => s.enabled);
    const errors = {};
    // sem Promise.allSettled (webOS 5 = Chromium 68)
    const lists = await Promise.all(active.map((s) => this.fetchOne(s, { force }).catch((e) => {
      errors[s.id] = String((e && e.message) || e);
      return [];
    })));
    return { channels: mergeChannels(lists), errors };
  }

  /** Testa a URL antes de adicionar (como no app). Lança erro se falhar ou vier vazia. */
  async add(name, url) {
    if (!/^https?:\/\//i.test(url)) throw new Error('A URL precisa começar com http:// ou https://');
    const res = await withTimeout(fetch(url), 20000);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const n = parseM3u(await res.text()).length;
    if (!n) throw new Error('A lista não tem canais válidos');
    const id = 'u-' + Date.now().toString(36);
    this.sources.push({ id, name: name || url, url, enabled: true, builtin: false });
    this.save();
    return n;
  }

  toggle(id) {
    const s = this.sources.find((x) => x.id === id);
    if (s) { s.enabled = !s.enabled; this.save(); }
  }
  remove(id) {
    this.sources = this.sources.filter((s) => s.id !== id || s.builtin);
    store.dropCache(id);
    this.save();
  }
}
