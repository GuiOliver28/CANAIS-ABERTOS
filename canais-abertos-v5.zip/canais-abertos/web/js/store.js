// Persistência em localStorage (equivale ao Room do app Android). Tudo tolerante a falha de storage.
const K = { sources: 'ca.sources', cache: 'ca.cache.', favs: 'ca.favs' };

function read(key, fallback) {
  try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; } catch { return fallback; }
}
function write(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { return false; }
}

export const store = {
  getSources: (defaults) => read(K.sources, null) ?? defaults,
  saveSources: (list) => write(K.sources, list),
  getCache: (id) => read(K.cache + id, null), // { at, channels }
  saveCache: (id, channels) => write(K.cache + id, { at: Date.now(), channels }),
  dropCache: (id) => { try { localStorage.removeItem(K.cache + id); } catch { /* ignore */ } },
  getFavorites: () => new Set(read(K.favs, [])),
  saveFavorites: (set) => write(K.favs, [...set]),
};
