// Navegação espacial por D-pad: move o foco para o elemento [data-focus] mais próximo na direção pedida.
export const KEYS = {
  LEFT: 37, UP: 38, RIGHT: 39, DOWN: 40, ENTER: 13,
  BACK_WEBOS: 461, BACK_TIZEN: 10009, ESC: 27, BACKSPACE: 8,
  CH_UP: [33, 427], CH_DOWN: [34, 428], // PageUp/Down (webOS) e Channel +/- (Tizen)
};

export function isBack(e) {
  return [KEYS.BACK_WEBOS, KEYS.BACK_TIZEN, KEYS.ESC].includes(e.keyCode) ||
    (e.keyCode === KEYS.BACKSPACE && !/INPUT|TEXTAREA/.test(document.activeElement?.tagName ?? ''));
}

function center(r) { return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }

export function move(dir, root = document) {
  const items = [...root.querySelectorAll('[data-focus]')].filter((el) => el.offsetParent !== null);
  const cur = document.activeElement?.matches?.('[data-focus]') ? document.activeElement : null;
  if (!cur) { items[0]?.focus(); return; }
  const c = center(cur.getBoundingClientRect());
  let best = null, bestScore = Infinity;
  for (const el of items) {
    if (el === cur) continue;
    const p = center(el.getBoundingClientRect());
    const dx = p.x - c.x, dy = p.y - c.y;
    const along = dir === 'left' ? -dx : dir === 'right' ? dx : dir === 'up' ? -dy : dy;
    if (along <= 1) continue;
    const across = dir === 'left' || dir === 'right' ? Math.abs(dy) : Math.abs(dx);
    const score = along + across * 2.5; // penaliza desvio lateral
    if (score < bestScore) { bestScore = score; best = el; }
  }
  if (best) { best.focus(); best.scrollIntoView({ block: 'nearest', inline: 'nearest' }); }
}

export function dirOf(keyCode) {
  return { [KEYS.LEFT]: 'left', [KEYS.UP]: 'up', [KEYS.RIGHT]: 'right', [KEYS.DOWN]: 'down' }[keyCode] ?? null;
}
