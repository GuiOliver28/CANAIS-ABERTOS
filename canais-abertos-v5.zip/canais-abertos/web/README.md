# Canais Abertos Web (base para LG webOS e Samsung Tizen)

HTML + CSS + JS puro (módulos ES), sem build e sem dependências. Mesmo design do app Android
(preto/branco/cinzas, Inter bold, foco com borda branca de 3 px e escala 1,05).

Reaproveita do app: parser M3U (`js/m3u.js`, port de `M3uParser.kt`/`ChannelKeys.kt`/`ChannelFilter.kt`),
fontes padrão (`sources.json`), gerenciador de fontes com cache de 7 dias (`js/sources.js`, localStorage no lugar do Room),
favoritos, busca sem acento, player com timeout de 5 s e sugestão do próximo canal.

## Rodar no navegador
    cd web && python3 -m http.server 8080      # abra http://localhost:8080
    node test/m3u.test.mjs                      # testes do parser
Setas = D-pad, Enter = selecionar, Esc/Backspace = voltar. No player: setas cima/baixo ou CH+/CH- trocam de canal.
Chrome não toca HLS nativamente: coloque `hls.min.js` em `web/vendor/` e descomente a linha no `index.html`.

## LG webOS
Alvo: **webOS 5 ou mais novo** (2020+, Chromium 68). O app empacotado roda em `file://`, onde módulos ES e `fetch('sources.json')`
não funcionam; por isso há um build que gera um bundle clássico, rebaixa a sintaxe para ES2017 e embute as fontes padrão:

    cd web && npm install && npm test
    npm run build:webos        # gera dist/webos (index.html, app.js, appinfo.json, ícones, fontes)
    npm run package:webos      # gera dist/org.canaisabertos.web_0.1.0_all.ipk (exige o webOS CLI)

Sem Node na sua máquina: copie `web/ci/webos.yml` para `.github/workflows/webos.yml`, rode **Actions > webos-ipk** e baixe o `.ipk`.

Instalar na TV:
1. Instale o app **Developer Mode** na LG Content Store, crie/entre com uma conta LG e ative o modo (a TV reinicia); anote o IP e a senha (passphrase) mostrados no app.
2. No PC: `npm i -g @webos-tools/cli`, `ares-setup-device --add tv -i "host=IP_DA_TV" -i "port=9922" -i "username=prisoner"`, depois `ares-novacom --device tv --getkey` (passphrase do app).
3. `ares-install --device tv dist/org.canaisabertos.web_0.1.0_all.ipk` e `ares-launch --device tv org.canaisabertos.web` (ou abra pelo launcher).
O modo desenvolvedor expira a cada ~50 h (o app Developer Mode tem "Extend"). Publicar na Content Store é outro processo (conta de vendedor LG).

Controle remoto: setas/OK, Voltar (461) volta de tela e fecha o app na lista, **amarelo** favorita o canal em foco, Play/Pause/Stop no player,
CH+/CH- (ou setas cima/baixo) trocam de canal, Magic Remote (ponteiro) foca ao passar o cursor.

## Samsung Tizen
`platform/tizen/config.xml` (copie para a raiz do projeto Tizen Studio, + `icon.png`). O mesmo bundle (`dist/webos`) serve de base;
`video.src` com HLS funciona nativamente. Ainda sem build/empacotamento próprio.

## Limitações conhecidas (não testado em TV real)
- Fontes precisam enviar CORS (`iptv-org` e `raw.githubusercontent.com` enviam). Listas de terceiros sem CORS falham ao adicionar.
- Streams `http://` dentro de app `https://` sofrem bloqueio de conteúdo misto no navegador; em apps empacotados de TV isso não se aplica.
- `user-agent`/`referrer` por canal do M3U não podem ser definidos pelo `<video>`; esses canais podem falhar.
- Não testei em TV LG real nem no emulador do webOS: só no Chromium atual, abrindo o bundle por `file://`. O suporte ao Chromium 68 vem de rebaixar a sintaxe e evitar APIs novas, não de teste.
- Navegação espacial simples (`js/nav.js`); a ordem de foco em telas muito diferentes pode precisar de ajustes na TV real.
