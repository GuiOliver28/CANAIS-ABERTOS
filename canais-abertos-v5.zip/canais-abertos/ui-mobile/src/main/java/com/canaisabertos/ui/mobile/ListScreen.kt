package com.canaisabertos.ui.mobile

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.canaisabertos.data.AppViewModels
import com.canaisabertos.data.ChannelListViewModel
import com.canaisabertos.data.model.Channel
import com.canaisabertos.ui.common.ChannelLogo
import com.canaisabertos.ui.common.LiveBadge
import com.canaisabertos.ui.common.Mono
import com.canaisabertos.ui.common.ThemeState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MobileListScreen(
    onOpenSources: () -> Unit,
    onPlay: (List<Channel>, Int) -> Unit,
    gridState: LazyGridState = rememberLazyGridState(),
    vm: ChannelListViewModel = viewModel(factory = AppViewModels.Factory),
) {
    val all by vm.channels.collectAsState()
    val visible by vm.visible.collectAsState()
    val favorites by vm.favoriteKeys.collectAsState()
    val query by vm.query.collectAsState()
    val onlyFavorites by vm.onlyFavorites.collectAsState()
    val refreshing by vm.isRefreshing.collectAsState()
    val context = LocalContext.current

    Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("CANAIS ABERTOS", style = MaterialTheme.typography.headlineMedium, color = Mono.White)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (visible.size == all.size) "${all.size} canais" else "${visible.size} de ${all.size} canais",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mono.Gray400,
                    )
                    TextButton(
                        onClick = { ThemeState.toggle(context) },
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                    ) {
                        Text(
                            if (ThemeState.isLight) "TEMA ESCURO" else "TEMA CLARO",
                            style = MaterialTheme.typography.labelSmall,
                            color = Mono.White,
                        )
                    }
                }
            }
            SecondaryButton("FONTES", onClick = onOpenSources)
        }

        if (all.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedTextField(
                    value = query,
                    onValueChange = vm::setQuery,
                    placeholder = { Text("Buscar canal") },
                    singleLine = true,
                    colors = monoTextFieldColors(),
                    modifier = Modifier.weight(1f),
                )
                // Ativo = primário (branco cheio); inativo = outline.
                if (onlyFavorites) PrimaryButton("★ FAVORITOS", vm::toggleOnlyFavorites)
                else SecondaryButton("☆ FAVORITOS", vm::toggleOnlyFavorites)
            }
        }

        when {
            all.isEmpty() && refreshing -> CenterMessage("CARREGANDO CANAIS…", null, null)
            all.isEmpty() -> CenterMessage(
                title = "NENHUM CANAL",
                body = "Nenhuma fonte ativa carregou. Ative, adicione ou atualize uma fonte.",
                cta = "GERENCIAR FONTES" to onOpenSources,
            )
            visible.isEmpty() -> CenterMessage(
                title = if (onlyFavorites && query.isBlank()) "SEM FAVORITOS" else "NADA ENCONTRADO",
                body = if (onlyFavorites && query.isBlank()) "Toque na estrela de um canal para favoritar."
                else "Nenhum canal combina com a busca.",
                cta = null,
            )
            else -> PullToRefreshBox(
                isRefreshing = refreshing,
                onRefresh = vm::refresh,
                modifier = Modifier.fillMaxSize(),
            ) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 340.dp), // celular: 1 coluna; tablet/dobrável: 2+; reage à rotação
                    state = gridState,
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    itemsIndexed(visible, key = { _, c -> c.id }) { index, channel ->
                        ChannelCard(
                            channel = channel,
                            favorite = channel.dedupeKey in favorites,
                            onClick = { onPlay(visible, index) },
                            onToggleFavorite = { vm.toggleFavorite(channel) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
internal fun CenterMessage(title: String, body: String?, cta: Pair<String, () -> Unit>?) {
    Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(title, style = MaterialTheme.typography.headlineMedium, color = Mono.White, textAlign = TextAlign.Center)
            if (body != null) {
                Text(body, style = MaterialTheme.typography.bodyLarge, color = Mono.Gray200, textAlign = TextAlign.Center)
            }
            if (cta != null) PrimaryButton(cta.first, cta.second)
        }
    }
}

@Composable
private fun ChannelCard(
    channel: Channel,
    favorite: Boolean,
    onClick: () -> Unit,
    onToggleFavorite: () -> Unit,
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.padding(start = 16.dp, top = 16.dp, bottom = 16.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            ChannelLogo(channel.name, channel.logoUrl, Modifier.size(64.dp))
            Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    channel.name,
                    modifier = Modifier.fillMaxWidth(),
                    style = MaterialTheme.typography.titleLarge,
                    color = Mono.White,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                channel.groupTitle?.let {
                    Text(
                        it,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Mono.Gray400,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
                LiveBadge()
            }
            // Alvo de toque de 48dp: estrela cheia = favorito (branco), vazia = cinza 400.
            Box(
                Modifier.size(48.dp).clickable(onClick = onToggleFavorite),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    if (favorite) "★" else "☆",
                    style = MaterialTheme.typography.headlineMedium,
                    color = if (favorite) Mono.White else Mono.Gray400,
                )
            }
        }
    }
}

internal tailrec fun Context.findActivity(): Activity = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> error("Contexto sem Activity")
}
