package com.canaisabertos.ui.mobile

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.canaisabertos.cast.CastSender
import com.canaisabertos.data.model.Channel
import com.canaisabertos.ui.common.Mono
import kotlinx.coroutines.launch

/** Lista as TVs com o Canais Abertos aberto na mesma rede e envia o canal para a escolhida. */
@Composable
fun CastDialog(channel: Channel, onDismiss: () -> Unit, onSent: () -> Unit) {
    val context = LocalContext.current
    val sender = remember { CastSender(context) }
    val targets by sender.targets.collectAsState()
    val scope = rememberCoroutineScope()
    var error by remember { mutableStateOf<String?>(null) }
    var ip by remember { mutableStateOf("") }

    DisposableEffect(sender) {
        sender.startDiscovery()
        onDispose { sender.stopDiscovery() }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Mono.Gray800,
        titleContentColor = Mono.White,
        textContentColor = Mono.Gray200,
        title = { Text("TRANSMITIR PARA A TV", style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()), // o player é paisagem: com teclado, precisa rolar
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                if (targets.isEmpty()) {
                    Text("Procurando TVs na mesma rede Wi-Fi com o Canais Abertos aberto…")
                }
                targets.forEach { target ->
                    TextButton(onClick = {
                        error = null
                        scope.launch {
                            if (sender.send(target, channel)) onSent()
                            else error = "Não foi possível enviar para ${target.name}."
                        }
                    }) {
                        Text(target.name, color = Mono.White, style = MaterialTheme.typography.titleMedium)
                    }
                }
                Text("Não achou? Digite o IP que aparece na tela inicial da TV:", style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(
                    value = ip,
                    onValueChange = { ip = it },
                    placeholder = { Text("192.168.0.10") },
                    singleLine = true,
                    colors = monoTextFieldColors(),
                )
                TextButton(
                    enabled = ip.isNotBlank(),
                    onClick = {
                        error = null
                        val target = sender.manualTarget(ip)
                        scope.launch {
                            if (sender.send(target, channel)) onSent()
                            else error = "Não foi possível enviar para ${target.host}."
                        }
                    },
                ) { Text("ENVIAR PARA ESTE IP", color = Mono.White, style = MaterialTheme.typography.titleMedium) }
                error?.let { Text(it, color = Mono.White) }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("FECHAR", color = Mono.White) }
        },
    )
}
