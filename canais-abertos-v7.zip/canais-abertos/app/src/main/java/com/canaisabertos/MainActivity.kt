package com.canaisabertos

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Rational
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.SideEffect
import com.canaisabertos.ui.common.AppTheme
import com.canaisabertos.ui.common.DeviceMode
import com.canaisabertos.ui.common.PlayerUi
import com.canaisabertos.ui.common.ThemeState
import com.canaisabertos.ui.mobile.MobileRoot
import com.canaisabertos.ui.tv.TvRoot

class MainActivity : ComponentActivity() {
    private var isTv = false

    /** Home com canal tocando no celular: segue em janela flutuante (picture-in-picture). */
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (!isTv && ThemeState.playerOpen && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                enterPictureInPictureMode(
                    PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build(),
                )
            } catch (_: Exception) { /* aparelho sem PiP ou recurso desativado */ }
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        PlayerUi.inPip = isInPictureInPictureMode
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeState.init(this)

        isTv = DeviceMode.isTv(this)
        if (isTv) requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

        setContent {
            // Ícones das barras acompanham o tema (claros no escuro, escuros no claro).
            val light = ThemeState.effectiveLight
            SideEffect {
                val style = if (light) SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                else SystemBarStyle.dark(Color.TRANSPARENT)
                enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
            }
            AppTheme(isTv = isTv) {
                if (isTv) TvRoot() else MobileRoot()
            }
        }
    }
}
