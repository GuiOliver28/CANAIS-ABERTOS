package com.canaisabertos.ui.tv

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.dp
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.Text
import com.canaisabertos.data.m3u.ChannelFilter
import com.canaisabertos.data.model.Channel
import com.canaisabertos.ui.common.ChannelLogo
import com.canaisabertos.ui.common.LiveBadge
import com.canaisabertos.ui.common.Mono

/** Detalhes do canal (OK no card): logo grande, nome, categoria, ASSISTIR e favoritar. VOLTAR fecha. */
@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun TvChannelDetail(
    channel: Channel,
    favorite: Boolean,
    onWatch: () -> Unit,
    onToggleFavorite: () -> Unit,
    onClose: () -> Unit,
) {
    BackHandler(onBack = onClose)
    val watchFocus = remember { FocusRequester() }
    LaunchedEffect(Unit) { runCatching { watchFocus.requestFocus() } }

    Box(Modifier.fillMaxSize().padding(horizontal = 96.dp, vertical = 48.dp), contentAlignment = Alignment.CenterStart) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(64.dp)) {
            ChannelLogo(channel.name, channel.logoUrl, Modifier.size(280.dp))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    channel.name,
                    style = MaterialTheme.typography.displayLarge,
                    color = Mono.White,
                    maxLines = 2,
                )
                Text(
                    ChannelFilter.groupsOf(channel).joinToString(" · "),
                    style = MaterialTheme.typography.titleLarge,
                    color = Mono.Gray400,
                )
                LiveBadge()
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    TvButton("ASSISTIR", onClick = onWatch, primary = true, modifier = Modifier.focusRequester(watchFocus))
                    TvButton(if (favorite) "★ FAVORITO" else "☆ FAVORITAR", onClick = onToggleFavorite)
                }
                Text(
                    "VOLTAR: lista de canais",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Mono.Gray400,
                )
            }
        }
    }
}
