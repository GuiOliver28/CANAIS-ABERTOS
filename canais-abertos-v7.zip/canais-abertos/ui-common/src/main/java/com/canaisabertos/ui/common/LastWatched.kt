package com.canaisabertos.ui.common

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Lembra o último canal assistido (dedupeKey) para a lista abrir nele. */
object LastWatched {
    private const val PREFS = "canais_prefs"
    private const val KEY = "last_channel"

    fun get(context: Context): String? =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)

    fun set(context: Context, dedupeKey: String) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, dedupeKey).apply()
    }
}

/** Estado do player compartilhado entre Activity e UI (picture-in-picture). */
object PlayerUi {
    var inPip by mutableStateOf(false)
}
