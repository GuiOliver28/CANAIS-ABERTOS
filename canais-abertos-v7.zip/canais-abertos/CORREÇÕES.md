# CORREÇÕES — rodada de 12/11/2026

Baseline: o build verde do GitHub Actions (run #21): `app/build.gradle.kts`, `ui-tv/build.gradle.kts` e
`ui-mobile/.../PlayerScreen.kt` do seu v2 foram incorporados. Estado: **nada abaixo foi compilado por mim**
(sem SDK na sessão); valide no Actions.

## 1. Bug da lista no mobile (nomes somem depois do player)
Não consegui reproduzir sem aparelho, então não afirmo a causa exata. Mudanças que removem as causas prováveis:
- `ChannelListViewModel`: `channels`, `favoriteKeys` e `visible` agora usam `SharingStarted.Eagerly`
  (cache vivo enquanto o ViewModel viver, nunca reinicia ao voltar do player). `isRefreshing` continua `WhileSubscribed`.
- `MobileRoot` guarda o `LazyGridState` e o repassa à lista: a posição de rolagem sobrevive ao player.
- Grade `GridCells.Adaptive(340.dp)` no lugar de `calculateWindowSizeClass(...)` + colunas fixas
  (o cálculo dependia da Activity e do tamanho da janela logo após sair do player em paisagem).
- Card: coluna e texto do nome com `fillMaxWidth()` explícito.
Se o bug persistir, mande um print e a versão do Android; o próximo suspeito é o `SubcomposeAsyncImage` do logo.

## 2. Cast (celular → Fire TV), **sem Google Cast**
O Media3 Cast exige Google Play Services e a Fire TV **não é um receptor Google Cast**; então não é possível
transmitir para ela com esse caminho, e usá-lo quebraria a regra "sem GMS". Alternativa implementada (módulo `core-cast`):
- A TV (`TvRoot`) abre um servidor HTTP mínimo na rede local e se anuncia por NSD/mDNS (`_canaisabertos._tcp`) enquanto o app está visível.
- No player do celular, o botão **TV** lista as TVs achadas e envia o canal (`POST /play`); a TV toca e o celular volta à lista.
- Permissões novas: `ACCESS_WIFI_STATE`, `CHANGE_WIFI_MULTICAST_STATE`.
- Limites: celular e TV na mesma rede (Wi-Fi com "isolamento de clientes" bloqueia); só envia a URL, a TV baixa o stream por conta própria;
  **qualquer aparelho da rede pode mandar um stream http/https para a TV aberta** (sem pareamento/PIN ainda).
- Testes JVM do protocolo: `core-cast/src/test`.

## 3. Versão Web (`web/`)
Base para webOS/Tizen em JS puro, mesmo design, mesmo parser (testado em Node), fontes com localStorage, D-pad, player.
Conferido no Chromium com lista simulada (12 canais, foco, sem erros de JS). Ver `web/README.md`.

## Arquivos
Novos: `core-cast/`, `web/`, `ui-mobile/.../CastDialog.kt`. Alterados: `ChannelListViewModel.kt`, `ListScreen.kt`, `MobileRoot.kt`,
`PlayerScreen.kt` (botão TV), `TvRoot.kt`, `AndroidManifest.xml`, `settings.gradle.kts`, `ui-tv`/`ui-mobile` `build.gradle.kts`.

## 4. webOS (LG) — continuação
`web/` ganhou empacotamento para webOS 5+: `npm run build:webos` gera `dist/webos` (bundle clássico ES2017, fontes padrão embutidas,
sem `flex gap`/`inset`/`replaceChildren`/`matchAll`/`allSettled` por causa do Chromium 68), ícones e splash, `appinfo.json`,
tecla amarela para favoritar, Play/Pause/Stop, Magic Remote, pausa em segundo plano, Voltar fecha o app. `web/ci/webos.yml` gera o `.ipk` no GitHub Actions.
Testado só no Chromium atual via `file://`; sem TV/emulador. Passo a passo de instalação em `web/README.md`.

## 5. Rodada pós-teste no aparelho (v5)
1. **Overlay do player (mobile):** `detectTapGestures` roda no passe Main e o `PlayerView` (AndroidView) consome o toque antes. Agora o toque é
   observado no passe `Initial` (antes dos filhos, sem consumir), então o cabeçalho volta ao tocar no vídeo e os controles do player seguem funcionando.
   Toques dentro do próprio cabeçalho não o alternam (são dos botões VOLTAR/TV).
2. **Cast não achava a TV:** `MulticastLock` adquirido na TV e no celular (enquanto descobre/recebe); novo fallback por **broadcast UDP** (porta 8766)
   além do NSD; a TV usa a porta TCP fixa 8765 (se livre), mostra o próprio IP no topo da lista ("Cast: x.x.x.x") e o diálogo do celular
   aceita **IP digitado**. As permissões de rede já estavam no manifest do app (único APK para celular e Fire TV).
3. **Lista (nomes somem):** causa ainda não confirmada. Além da v3, o logo deixou de usar `SubcomposeAsyncImage` (subcomposição dentro de
   LazyGrid) e passou a `AsyncImage` com as iniciais por baixo; o ponto "AO VIVO" pulsa na fase de desenho (sem recompor cada card por frame).
   Se persistir, mande print + versão do Android.
4. **Tema claro:** `ThemeState` (SharedPreferences) + `Mono` com papéis que invertem no claro. Botão "TEMA CLARO/ESCURO" na lista (mobile e TV).
   O player (mobile e TV) fica sempre escuro. Barras do sistema acompanham o tema.

## 6. Melhorias do app Android (v6) — nada compilado por mim, valide no Actions
- **Categorias:** chips com os `group-title` do M3U (separados por `;`, mais canais primeiro, "Undefined" só em TODOS), no mobile e na TV.
  Tocar na categoria ativa volta para TODOS. Filtro em `ChannelFilter` (com teste) e estado em `ChannelListViewModel`.
- **Retomar de onde parou:** o último canal assistido (inclusive trocando de canal dentro do player) fica salvo; a lista abre rolada nele no celular e o foco inicial da TV vai para ele.
- **Picture-in-picture (celular):** Home com canal tocando abre janela flutuante; o cabeçalho some no PiP; fechar a janela para o stream.
- **Zapping mais rápido:** `DefaultLoadControl` ajustado para TV ao vivo (começa com ~1,5 s de buffer, máx. 30 s).
- Gradle não foi alterado (Media3 segue 1.4.1).

## 7. Rodada de polimento (v7) — nada compilado por mim, valide no Actions
- **Categorias em PT-BR:** `ChannelFilter.label()` traduz GENERAL, ENTERTAINMENT, NEWS, SPORTS, MOVIES, KIDS e mais ~20 categorias do iptv-org;
  sem categoria ou "Undefined" vira **SEM CATEGORIA** (chip sempre por último). Vale para chips, cards, detalhes e filtro (com teste).
- **Detalhes estilo Netflix:** TV: card focado cresce 1,1 com borda branca; OK abre `TvChannelDetail` (logo grande, nome, categoria, ASSISTIR, favoritar; VOLTAR fecha e devolve o foco ao card).
  Mobile: toque abre `ModalBottomSheet` (logo, nome, categoria, ASSISTIR AGORA, favoritar). A estrela do card continua favoritando direto.
- **Mobile visual:** título "CANAIS ABERTOS" menor e cabeçalho compacto; nome do canal em até 2 linhas e fonte menor nos cards (grade de 2 colunas na horizontal).
- **Player mobile imersivo:** abre 100% vídeo, barras ocultas (immersive sticky) e vídeo sob o notch. Toque ou deslizar de baixo para cima mostra o cabeçalho
  (VOLTAR, nome, relógio, TV) por 3 s; deslizar para a direita ou VOLTAR fecha. Os controles anterior/próximo do PlayerView agora seguem o mesmo estado.
- **Temporizador de dormir:** ícone de relógio no cabeçalho com 30/60/90 min e "desativar"; ao vencer, fecha o player. (Só no mobile; "barra de progresso" não se aplica a TV ao vivo.)
