// Monta o .ipk (ar + tar.gz, formato do ares-package) em JS puro: sem ar/tar do sistema, roda também no Windows.
// Formato deliberadamente conservador: ar "comum" (nomes sem "/" final, mtime/uid/gid 0), tar USTAR,
// donos root, modos 0755/0644, datas fixas (build reproduzível).
import fs from 'node:fs';
import path from 'node:path';
import zlib from 'node:zlib';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const appDir = path.join(root, 'dist', 'webos');
const info = JSON.parse(fs.readFileSync(path.join(appDir, 'appinfo.json'), 'utf8'));
const ID = info.id, VER = info.version;
const MTIME = 1700000000;

function tarHeader(name, size, isDir, exec) {
  const b = Buffer.alloc(512);
  const put = (s, off, len) => b.write(s, off, len, 'latin1');
  const oct = (n, len) => n.toString(8).padStart(len - 1, '0') + '\0';
  if (Buffer.byteLength(name) > 100) throw new Error('nome longo demais: ' + name);
  put(name, 0, 100);
  put(oct(isDir || exec ? 0o755 : 0o644, 8), 100, 8);
  put(oct(0, 8), 108, 8); put(oct(0, 8), 116, 8);
  put(oct(isDir ? 0 : size, 12), 124, 12);
  put(oct(MTIME, 12), 136, 12);
  put('        ', 148, 8); // checksum com espaços
  put(isDir ? '5' : '0', 156, 1);
  put('ustar\0', 257, 6); put('00', 263, 2);
  put('root', 265, 32); put('root', 297, 32);
  let sum = 0; for (const x of b) sum += x;
  put(sum.toString(8).padStart(6, '0') + '\0 ', 148, 8);
  return b;
}

function tarGz(entries) { // entries: [{name, data|null}] (data null = diretório)
  const parts = [];
  for (const e of entries) {
    const dir = e.data === null;
    parts.push(tarHeader(dir ? e.name.replace(/\/?$/, '/') : e.name, dir ? 0 : e.data.length, dir, !!e.exec));
    if (!dir) {
      parts.push(e.data);
      const pad = (512 - (e.data.length % 512)) % 512;
      if (pad) parts.push(Buffer.alloc(pad));
    }
  }
  parts.push(Buffer.alloc(1024));
  return zlib.gzipSync(Buffer.concat(parts), { level: 9 });
}

function arArchive(files) {
  const parts = [Buffer.from('!<arch>\n')];
  for (const f of files) {
    const hdr = Buffer.alloc(60, 0x20);
    const put = (s, off) => hdr.write(s, off, 'latin1');
    put(f.name, 0); put(String(0), 16); put('0', 28); put('0', 34); put('100644', 40);
    put(String(f.data.length), 48); put('`\n', 58);
    parts.push(hdr, f.data);
    if (f.data.length % 2) parts.push(Buffer.from('\n'));
  }
  return Buffer.concat(parts);
}

// ---- data.tar.gz
const entries = [];
const dirs = new Set();
const addDir = (d) => { if (!dirs.has(d)) { dirs.add(d); entries.push({ name: d, data: null }); } };
function walk(dir, rel) {
  for (const n of fs.readdirSync(dir).sort()) {
    const full = path.join(dir, n), r = `${rel}/${n}`;
    if (fs.statSync(full).isDirectory()) { addDir(r); walk(full, r); }
    else entries.push({ name: r, data: fs.readFileSync(full) });
  }
}
addDir('.'); addDir('./usr'); addDir('./usr/palm'); addDir('./usr/palm/packages'); addDir(`./usr/palm/packages/${ID}`);
entries.push({ name: `./usr/palm/packages/${ID}/packageinfo.json`,
  data: Buffer.from(JSON.stringify({ app: ID, id: ID, loadable: true, version: VER }) + '\n') });
addDir('./usr/palm/applications'); addDir(`./usr/palm/applications/${ID}`);
walk(appDir, `./usr/palm/applications/${ID}`);
const installed = Math.ceil(entries.reduce((n, e) => n + (e.data ? e.data.length : 0), 0) / 1024);

const control = [
  `Package: ${ID}`, `Version: ${VER}`, 'Section: misc', 'Priority: optional', 'Architecture: all',
  `Installed-Size: ${installed}`, 'Maintainer: Canais Abertos <noreply@example.com>',
  'Description: Canais Abertos (TV ao vivo)',
  'webOS-Package-Format-Version: 2', 'webOS-Packager-Version: 1.0.0', '',
].join('\n');

// Sem o postinst o webOS extrai os arquivos mas não recarrega a lista de apps: instala "sem erro" e não aparece.
const postinst = `#!/bin/sh
ls-control scan-services >/dev/null 2>&1 || true
exit 0
`;
const prerm = `#!/bin/sh
exit 0
`;

const ipk = arArchive([
  { name: 'debian-binary', data: Buffer.from('2.0\n') },
  { name: 'control.tar.gz', data: tarGz([
    { name: '.', data: null },
    { name: './control', data: Buffer.from(control) },
    { name: './postinst', data: Buffer.from(postinst), exec: true },
    { name: './prerm', data: Buffer.from(prerm), exec: true },
  ]) },
  { name: 'data.tar.gz', data: tarGz(entries) },
]);
const out = path.join(root, 'dist', `${ID}_${VER}_all.ipk`);
fs.writeFileSync(out, ipk);
console.log(out, ipk.length, 'bytes');
