package com.canaisabertos.ui.mobile

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material.ripple.RippleAlpha
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalRippleConfiguration
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RippleConfiguration
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.canaisabertos.player.PlayerViewModel
import com.canaisabertos.ui.common.LastWatched
import com.canaisabertos.ui.common.Mono
import com.canaisabertos.ui.common.Screen
import com.canaisabertos.ui.common.ThemeState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MobileRoot() {
    var screen by rememberSaveable { mutableStateOf(Screen.LIST) }
    val player: PlayerViewModel = viewModel(factory = PlayerViewModel.Factory)
    val playerState by player.state.collectAsState()
    // O player é sempre escuro, em qualquer tema.
    SideEffect { ThemeState.playerOpen = playerState.channel != null }
    val appContext = LocalContext.current
    LaunchedEffect(playerState.channel?.dedupeKey) {
        playerState.channel?.let { LastWatched.set(appContext, it.dedupeKey) }
    }
    // Hoistado: a lista sai da composição enquanto o player está aberto; o scroll sobrevive.
    val gridState = rememberLazyGridState()

    // Stream ao vivo não deve continuar em segundo plano; ao voltar, re-tenta o canal atual.
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { player.onAppStopped() }
    LifecycleEventEffect(Lifecycle.Event.ON_START) { player.onAppStarted() }

    // Estado pressionado: ripple branco a 12% de alpha.
    val ripple = RippleConfiguration(color = Mono.White, rippleAlpha = RippleAlpha(0.12f, 0.12f, 0.12f, 0.12f))

    CompositionLocalProvider(LocalRippleConfiguration provides ripple) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            when {
                playerState.channel != null -> MobilePlayerScreen(player)
                screen == Screen.SOURCES -> MobileSourcesScreen(onBack = { screen = Screen.LIST })
                else -> MobileListScreen(
                    onOpenSources = { screen = Screen.SOURCES },
                    onPlay = { list, index ->
                        ThemeState.playerOpen = true // evita 1 frame claro ao abrir o player
                        player.start(list, index)
                    },
                    gridState = gridState,
                )
            }
        }
    }
}
