package com.canaisabertos.ui.mobile

import android.content.pm.ActivityInfo
import android.os.Build
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.ui.PlayerView
import com.canaisabertos.player.PlaybackStatus
import com.canaisabertos.player.PlayerViewModel
import com.canaisabertos.ui.common.ErrorMark
import com.canaisabertos.ui.common.LiveBadge
import com.canaisabertos.ui.common.Mono
import com.canaisabertos.ui.common.PlayerUi
import kotlinx.coroutines.delay
import kotlin.math.abs

private const val OVERLAY_MS = 3_000L

/**
 * Player mobile imersivo (estilo YouTube): abre 100% vídeo, barras do sistema ocultas (immersive sticky).
 * Toque, ou deslizar de baixo para cima, mostra o cabeçalho por 3 s. Deslizar para a direita ou VOLTAR fecha.
 */
@Composable
fun MobilePlayerScreen(vm: PlayerViewModel) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val activity = runCatching { context.findActivity() }.getOrNull()

    BackHandler { vm.stop() }

    // Começa só com o vídeo; o cabeçalho aparece por gesto.
    var overlayVisivel by remember { mutableStateOf(false) }
    var mostrarCast by remember { mutableStateOf(false) }
    var menuSono by remember { mutableStateOf(false) }
    var sonoMinutos by remember { mutableStateOf<Int?>(null) }

    // Esconde o cabeçalho sozinho (não enquanto um diálogo/menu está aberto).
    LaunchedEffect(overlayVisivel, mostrarCast, menuSono) {
        if (overlayVisivel && !mostrarCast && !menuSono) {
            delay(OVERLAY_MS)
            overlayVisivel = false
        }
    }

    // Temporizador de dormir: ao vencer, fecha o player (para o stream).
    LaunchedEffect(sonoMinutos) {
        val min = sonoMinutos ?: return@LaunchedEffect
        delay(min * 60_000L)
        sonoMinutos = null
        vm.stop()
    }

    // Landscape automático + tela cheia imersiva; ao sair, volta tudo ao normal.
    DisposableEffect(activity) {
        if (activity != null) {
            val window = activity.window
            val controller = WindowCompat.getInsetsController(window, window.decorView)
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) { // vídeo também sob o notch
                val lp = window.attributes
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                window.attributes = lp
            }
        }
        onDispose {
            if (activity != null) {
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                val window = activity.window
                val controller = WindowCompat.getInsetsController(window, window.decorView)
                controller.show(WindowInsetsCompat.Type.systemBars())
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                    val lp = window.attributes
                    lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                    window.attributes = lp
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Mono.Black)
            // O PlayerView (AndroidView) consome o toque; observamos no passe Initial, antes dos filhos, sem consumir.
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    val up = waitForUpOrCancellation(pass = PointerEventPass.Initial) ?: return@awaitEachGesture
                    val dx = up.position.x - down.position.x
                    val dy = up.position.y - down.position.y
                    val far = 96.dp.toPx()
                    when {
                        // deslizar para a direita: sai do player
                        dx > far && abs(dy) < dx / 2 -> vm.stop()
                        // deslizar de baixo para cima: mostra o cabeçalho
                        -dy > far && abs(dx) < -dy / 2 -> overlayVisivel = true
                        // toque simples (fora do cabeçalho visível, que é dos botões): alterna
                        abs(dx) < viewConfiguration.touchSlop && abs(dy) < viewConfiguration.touchSlop -> {
                            val inHeader = overlayVisivel && down.position.y < 80.dp.toPx()
                            if (!inHeader) overlayVisivel = !overlayVisivel
                        }
                    }
                }
            },
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                val view = LayoutInflater.from(ctx).inflate(R.layout.mono_player_view, null) as PlayerView
                view.player = vm.player
                view.keepScreenOn = true
                // Os controles (anterior/próximo) seguem o nosso estado, não os gestos próprios do PlayerView.
                view.controllerAutoShow = false
                view.controllerHideOnTouch = false
                view.controllerShowTimeoutMs = 0
                view.findViewById<View>(R.id.mono_prev)?.setOnClickListener { vm.previous() }
                view.findViewById<View>(R.id.mono_next)?.setOnClickListener { vm.next() }
                view
            },
            update = { view -> if (overlayVisivel) view.showController() else view.hideController() },
            onRelease = { it.player = null },
        )

        if (overlayVisivel && !PlayerUi.inPip) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(Color(0xB3000000))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                TextButton(onClick = { vm.stop() }) {
                    Text("VOLTAR", color = Mono.White, style = MaterialTheme.typography.titleMedium)
                }

                Column(Modifier.weight(1f)) {
                    Text(
                        state.channel?.name.orEmpty(),
                        style = MaterialTheme.typography.titleLarge,
                        color = Mono.White,
                        maxLines = 1,
                    )
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        LiveBadge()
                        sonoMinutos?.let {
                            Text("SONO EM $it MIN", style = MaterialTheme.typography.labelSmall, color = Mono.Gray200)
                        }
                    }
                }

                // Temporizador de dormir
                Box {
                    TextButton(onClick = { menuSono = true }) { ClockIcon(Mono.White) }
                    DropdownMenu(expanded = menuSono, onDismissRequest = { menuSono = false }) {
                        listOf(30, 60, 90).forEach { min ->
                            DropdownMenuItem(
                                text = { Text("PARAR EM $min MIN") },
                                onClick = { sonoMinutos = min; menuSono = false },
                            )
                        }
                        if (sonoMinutos != null) {
                            DropdownMenuItem(
                                text = { Text("DESATIVAR TEMPORIZADOR") },
                                onClick = { sonoMinutos = null; menuSono = false },
                            )
                        }
                    }
                }

                TextButton(onClick = { mostrarCast = true }) {
                    Text("TV", color = Mono.White, style = MaterialTheme.typography.titleMedium)
                }
            }
        }

        val atual = state.channel
        if (mostrarCast && atual != null) {
            CastDialog(
                channel = atual,
                onDismiss = { mostrarCast = false },
                onSent = {
                    mostrarCast = false
                    vm.stop() // a TV assume; o celular volta para a lista
                },
            )
        }

        when (state.status) {
            PlaybackStatus.PLAYING -> Unit
            PlaybackStatus.LOADING -> Box(
                Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    "CARREGANDO...",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Mono.White,
                )
            }
            PlaybackStatus.UNAVAILABLE -> Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xB3000000)),
                contentAlignment = Alignment.Center,
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    ErrorMark()
                    Text(
                        "CANAL INDISPONÍVEL",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Mono.White,
                        textAlign = TextAlign.Center,
                    )
                    state.suggestedNext?.let {
                        Button(onClick = { vm.next() }) {
                            Text("PRÓXIMO: ${it.name.uppercase()}")
                        }
                    }
                    OutlinedButton(onClick = { vm.stop() }) {
                        Text("VOLTAR À LISTA", color = Mono.White)
                    }
                }
            }
        }
    }
}

/** Ícone de relógio desenhado (evita a dependência material-icons-extended). */
@Composable
private fun ClockIcon(color: Color) {
    Canvas(Modifier.size(24.dp)) {
        val stroke = Stroke(width = 2.dp.toPx())
        drawCircle(color = color, style = stroke)
        val c = center
        drawLine(color, c, Offset(c.x, c.y - size.height * 0.30f), strokeWidth = stroke.width)
        drawLine(color, c, Offset(c.x + size.width * 0.22f, c.y), strokeWidth = stroke.width)
    }
}
