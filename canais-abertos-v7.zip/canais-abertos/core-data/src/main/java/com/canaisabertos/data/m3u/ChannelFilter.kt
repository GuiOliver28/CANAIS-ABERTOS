package com.canaisabertos.data.m3u

import com.canaisabertos.data.model.Channel

object ChannelFilter {
    const val NO_CATEGORY = "SEM CATEGORIA"
    private val IGNORED_GROUPS = setOf("undefined", "undefinied")

    /** Categorias do M3U (iptv-org) em inglês -> PT-BR. O que não está aqui aparece em maiúsculas, como veio. */
    private val PT = mapOf(
        "general" to "GERAL", "entertainment" to "ENTRETENIMENTO", "news" to "NOTÍCIAS", "sports" to "ESPORTES",
        "movies" to "FILMES", "kids" to "INFANTIL", "animation" to "ANIMAÇÃO", "auto" to "AUTOMOTIVO",
        "business" to "NEGÓCIOS", "classic" to "CLÁSSICOS", "comedy" to "COMÉDIA", "cooking" to "CULINÁRIA",
        "culture" to "CULTURA", "documentary" to "DOCUMENTÁRIOS", "education" to "EDUCAÇÃO", "family" to "FAMÍLIA",
        "legislative" to "LEGISLATIVO", "lifestyle" to "ESTILO DE VIDA", "music" to "MÚSICA",
        "outdoor" to "AO AR LIVRE", "public" to "PÚBLICO", "relax" to "RELAXAMENTO", "religious" to "RELIGIOSO",
        "science" to "CIÊNCIA", "series" to "SÉRIES", "shop" to "COMPRAS", "travel" to "VIAGENS", "weather" to "CLIMA",
    )

    /** Nome de exibição de uma categoria crua ("News" -> "NOTÍCIAS"). */
    fun label(raw: String): String = PT[raw.trim().lowercase()] ?: raw.trim().uppercase()

    /** Categorias já traduzidas; canal sem categoria (ou "Undefined") vira ["SEM CATEGORIA"]. "News;Sports" -> 2. */
    fun groupsOf(channel: Channel): List<String> {
        val raw = channel.groupTitle.orEmpty().split(';').map { it.trim() }
            .filter { it.isNotEmpty() && it.lowercase() !in IGNORED_GROUPS }
        return if (raw.isEmpty()) listOf(NO_CATEGORY) else raw.map { label(it) }.distinct()
    }

    /** Categorias para os chips: mais canais primeiro, no máximo [limit]; SEM CATEGORIA sempre por último. */
    fun availableGroups(channels: List<Channel>, limit: Int = 40): List<String> =
        channels.flatMap { groupsOf(it) }
            .groupingBy { it }.eachCount()
            .entries.sortedWith(
                compareBy<Map.Entry<String, Int>> { it.key == NO_CATEGORY }
                    .thenByDescending { it.value }.thenBy { it.key },
            )
            .take(limit).map { it.key }

    /**
     * Busca por nome (sem acento, sem caixa, ignorando "HD" etc.), filtro opcional só de favoritos
     * e, na lista completa, favoritos fixados no topo (ordem original preservada dentro de cada grupo).
     */
    fun apply(
        channels: List<Channel>,
        query: String,
        favorites: Set<String>,
        onlyFavorites: Boolean,
        group: String? = null,
    ): List<Channel> {
        val q = query.trim().takeIf { it.isNotEmpty() }?.let { ChannelKeys.normalize(it) }
        var out = channels
        if (onlyFavorites) out = out.filter { it.dedupeKey in favorites }
        if (group != null) out = out.filter { group in groupsOf(it) }
        if (q != null) out = out.filter { it.normalizedName.contains(q) }
        if (!onlyFavorites && favorites.isNotEmpty()) out = out.sortedByDescending { it.dedupeKey in favorites }
        return out
    }
}
